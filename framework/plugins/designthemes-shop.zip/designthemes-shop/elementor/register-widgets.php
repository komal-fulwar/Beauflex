<?php
namespace DTElementor\widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DTShopElementorWidgets {

	/**
	 * A Reference to an instance of this class
	 */
	private static $_instance = null;

	/**
	 * Instance
	 * 
	 * Ensures only one instance of the class is loaded or can be loaded.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		add_action( 'elementor/widgets/widgets_registered', array( $this, 'dtshop_register_widgets' ) );

		add_action( 'elementor/frontend/after_register_styles', array( $this, 'dtshop_register_widget_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'dtshop_register_widget_scripts' ) );

		add_action( 'elementor/preview/enqueue_styles', array( $this, 'dtshop_preview_styles') );

	}

	/**
	 * Register designthemes widgets
	 */
	public function dtshop_register_widgets( $widgets_manager ) {

		require dtshop_instance()->plugin_path( 'elementor/widgets/images-default/class-product-images-default.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Images_Default() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/images-carousel/class-product-images-carousel.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Images_Carousel() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/images-list/class-product-images-list.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Images_List() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/360-image-viewer/class-product-360-image-viewer.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_360_Image_Viewer() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/summary-nav-bar/class-product-summary-nav-bar.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Summary_Nav_bar() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/summary/class-product-summary.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Summary() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/product-tabs/class-product-tabs.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Tabs() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/product-tabs-exploded/class-product-tabs-exploded.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Tabs_Exploded() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/upsell-products/class-upsell-products.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Upsell_Products() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/related-products/class-related-products.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Related_Products() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/products/class-widget-products.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Products() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/product-cat/class-product-cat.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Cat() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/product-cat-single/class-product-cat-single.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Product_Cat_Single() );

		require dtshop_instance()->plugin_path( 'elementor/widgets/menu-icon/class-widget-menu-icon.php' );
		$widgets_manager->register_widget_type( new DTShop_Widget_Menu_Icon() );

	}

	/**
	 * Register designthemes widgets styles
	 */
	public function dtshop_register_widget_styles() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries

			wp_register_style( 'swiper',
				dtshop_instance()->plugin_url('css/swiper.min.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

		# WooCommerce

			# Images Carousel
			wp_register_style( 'dtshop-product-single-images-carousel',
				dtshop_instance()->plugin_url('elementor/widgets/images-carousel/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# Images List
			wp_register_style( 'dtshop-product-single-images-list',
				dtshop_instance()->plugin_url('elementor/widgets/images-list/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# 360 Image Viewer
			wp_register_style( 'dtshop-product-single-images-360-viewer',
				dtshop_instance()->plugin_url('elementor/widgets/360-image-viewer/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);				

			# Summary Nav Bar
			wp_register_style( 'dtshop-product-single-summary-nav-bar',
				dtshop_instance()->plugin_url('elementor/widgets/summary-nav-bar/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);				

			# Summary
			wp_register_style( 'dtshop-product-single-summary',
				dtshop_instance()->plugin_url('elementor/widgets/summary/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);				

			# Product Tabs
			wp_register_style( 'dtshop-product-single-tabs',
				dtshop_instance()->plugin_url('elementor/widgets/product-tabs/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);				

			# Product Tabs Exploded
			wp_register_style( 'dtshop-product-single-tabs-exploded',
				dtshop_instance()->plugin_url('elementor/widgets/product-tabs-exploded/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# Upsell Products
			wp_register_style( 'dtshop-product-single-upsell-products',
				dtshop_instance()->plugin_url('elementor/widgets/upsell-products/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# Related Products
			wp_register_style( 'dtshop-product-single-related-products',
				dtshop_instance()->plugin_url('elementor/widgets/related-products/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# Products
			wp_register_style( 'dtshop-products',
				dtshop_instance()->plugin_url('elementor/widgets/products/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

			# Menu Icon
			wp_register_style( 'dtshop-shop-menu-icon',
				dtshop_instance()->plugin_url('elementor/widgets/products/style'.$suffix.'.css'),
				array(),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION
			);

	}

	/**
	 * Register designthemes widgets scripts
	 */
	public function dtshop_register_widget_scripts() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries

			wp_register_script( 'jquery.swiper',
				dtshop_instance()->plugin_url('js/swiper.min.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery-nicescroll',
				dtshop_instance()->plugin_url('js/jquery.nicescroll.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.360viewer',
				dtshop_instance()->plugin_url('js/360-viewer.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true );

		# WooCommerce

			# Images Carousel
			wp_register_script( 'dtshop-product-single-images-carousel',
				dtshop_instance()->plugin_url('elementor/widgets/images-carousel/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

			# Images List
			wp_register_script( 'dtshop-product-single-images-list',
				dtshop_instance()->plugin_url('elementor/widgets/images-list/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

			# 360 Image Viewer
			wp_register_script( 'dtshop-product-single-images-360-viewer',
				dtshop_instance()->plugin_url('elementor/widgets/360-image-viewer/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

			# Product Tabs - Exploded
			wp_register_script( 'dtshop-product-single-tabs-exploded',
				dtshop_instance()->plugin_url('elementor/widgets/product-tabs-exploded/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

			# Products
			wp_register_script( 'dtshop-products',
				dtshop_instance()->plugin_url('elementor/widgets/products/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

			# Menu Icon
			wp_register_script( 'dtshop-shop-menu-icon',
				dtshop_instance()->plugin_url('elementor/widgets/menu-icon/script'.$suffix.'.js'),
				array( 'jquery' ),
				dtshop_instance()::DTSHOP_ELEMENTOR_VERSION,
				true
			);

	}
	
	/**
	 * Editor Preview Style
	 */
	public function dtshop_preview_styles() {

		# swiper
		wp_enqueue_style( 'swiper' );

		# WooCommerce

			# Images Carousel
			wp_enqueue_style( 'dtshop-product-single-images-carousel' );
						
			# Images List
			wp_enqueue_style( 'dtshop-product-single-images-list' );

			# 360 Image Viewer
			wp_enqueue_style( 'dtshop-product-single-images-360-viewer' );

			# Summary Nav Bar
			wp_enqueue_style( 'dtshop-product-single-summary-nav-bar' );

			# Summary
			wp_enqueue_style( 'dtshop-product-single-summary' );

			# Product Tabs
			wp_enqueue_style( 'dtshop-product-single-tabs' );

			# Product Tabs Exploded
			wp_enqueue_style( 'dtshop-product-single-tabs-exploded' );

			# Upsell Products
			wp_enqueue_style( 'dtshop-product-single-upsell-products' );

			# Related Products
			wp_enqueue_style( 'dtshop-product-single-related-products' );

			# Products
			wp_enqueue_style( 'dtshop-products' );

			# Menu Icon
			wp_enqueue_style( 'dtshop-shop-menu-icon' );

	}

}

DTShopElementorWidgets::instance();