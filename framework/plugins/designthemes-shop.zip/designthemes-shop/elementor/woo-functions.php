<?php

/* Product Tabs Exploaded - Shortcodes */

if(!function_exists('dtshop_product_tabs_exploded_html')) {
	function dtshop_product_tabs_exploded_html($attrs, $content = null) {

		extract ( shortcode_atts ( array (
			'product_id'    => '',
			'tab'           => '',
			'hide_title'    => '',
			'apply_scroll'  => '',
			'scroll_height' => '',
			'class'         => ''
		), $attrs ) );

		$out = dtshop_product_tabs_exploded_render_html($attrs);

		return $out;

	}
	add_shortcode( 'dtshop_product_tabs_exploded', 'dtshop_product_tabs_exploded_html' );
}


if(!function_exists('dtshop_product_tabs_exploded_render_html')) {
	function dtshop_product_tabs_exploded_render_html($settings) {

		$output = '';

		if($settings['product_id'] == '' && is_singular('product')) {
			global $post;
			$settings['product_id'] = $post->ID;
		}

		if($settings['product_id'] != '') {

			$hide_title_class = '';
			if($settings['hide_title'] == 'true') {
				$hide_title_class = 'dt-sc-product-hide-tab-title';
			}

			$scroll_class = $scroll_height_style_attr = '';
			if($settings['apply_scroll'] == 'true') {
				$scroll_class             = 'dt-sc-content-scroll';
				$scroll_height            = ($settings['scroll_height'] != '') ? $settings['scroll_height'] : 400;
				$scroll_height_style_attr = 'style = "height:'.esc_attr($scroll_height).'px"';
			}

			$output .= '<div class="dt-sc-product-tabs dt-sc-product-tabs-exploded '.$settings['class'].' '.$hide_title_class.' '.$scroll_class.'" '.$scroll_height_style_attr.'>';

				if($settings['tab'] == 'description') {

					ob_start();
					woocommerce_product_description_tab();
					$output .= ob_get_clean();

				}

				if($settings['tab'] == 'review') {

					ob_start();
					comments_template();
					$output .= ob_get_clean();

				}

				if($settings['tab'] == 'additional_information') {

					ob_start();
					woocommerce_product_additional_information_tab();
					$output .= ob_get_clean();

				}

				// Custom Tabs

				if($settings['tab'] == 'custom_tab_1' || $settings['tab'] == 'custom_tab_2' || $settings['tab'] == 'custom_tab_3' || $settings['tab'] == 'custom_tab_4') {

					$custom_settings = get_post_meta( $settings['product_id'], '_custom_settings', true );
					$product_additional_tabs = (is_array($custom_settings['product-additional-tabs']) && !empty($custom_settings['product-additional-tabs'])) ? $custom_settings['product-additional-tabs'] : array ();

					// Tab 1
					if($settings['tab'] == 'custom_tab_1' && isset($product_additional_tabs[1])) {

						ob_start();
						$tab_title = $product_additional_tabs[1]['tab_title'];
						$tab_title = preg_replace('/[^A-Za-z0-9\-]/', '', $tab_title);
						$tab_key = 'dt_'.strtolower(str_replace(' ', '', $tab_title));
						dtshop_woo_additional_product_tabs_content( $tab_key );
						$output .= ob_get_clean();

					}

					// Tab 2
					if($settings['tab'] == 'custom_tab_2' && isset($product_additional_tabs[2])) {

						ob_start();
						$tab_title = $product_additional_tabs[2]['tab_title'];
						$tab_title = preg_replace('/[^A-Za-z0-9\-]/', '', $tab_title);
						$tab_key = 'dt_'.strtolower(str_replace(' ', '', $tab_title));
						dtshop_woo_additional_product_tabs_content( $tab_key );
						$output .= ob_get_clean();

					}

					// Tab 3
					if($settings['tab'] == 'custom_tab_3' && isset($product_additional_tabs[3])) {

						ob_start();
						$tab_title = $product_additional_tabs[3]['tab_title'];
						$tab_title = preg_replace('/[^A-Za-z0-9\-]/', '', $tab_title);
						$tab_key = 'dt_'.strtolower(str_replace(' ', '', $tab_title));
						dtshop_woo_additional_product_tabs_content( $tab_key );
						$output .= ob_get_clean();

					}

					// Tab 4
					if($settings['tab'] == 'custom_tab_4' && isset($product_additional_tabs[4])) {

						ob_start();
						$tab_title = $product_additional_tabs[4]['tab_title'];
						$tab_title = preg_replace('/[^A-Za-z0-9\-]/', '', $tab_title);
						$tab_key = 'dt_'.strtolower(str_replace(' ', '', $tab_title));
						dtshop_woo_additional_product_tabs_content( $tab_key );
						$output .= ob_get_clean();

					}

				}

			$output .= '</div>';

		} else {

			$output .= esc_html__('Please provide product id to display corresponding data!', 'dtshop');

		}

		return $output;

	}
}


/* Product Listing - Shortcodes */

if(!function_exists('dtshop_product_listing_html')) {
	function dtshop_product_listing_html($attrs, $content = null) {

		extract ( shortcode_atts ( array (
			'data_source'                   => '',
			'show_pagination'               => '',
			'enable_carousel'               => '',
			'post_per_page'                 => 12,
			'display_mode'                  => 'grid',
			'columns'                       => 4,
			'list_options'                  => 'left-thumb',
			'product_style_template'        => -1,

			'current_page'                  => 1,
			'offset'                        => 0,
			'categories'                    => '',
			'tags'                          => '',
			'include'                       => '',
			'exclude'                       => '',

			'carousel_effect'               => '',
			'carousel_slidesperview'        => 2,
			'carousel_loopmode'             => '',
			'carousel_mousewheelcontrol'    => '',
			'carousel_bulletpagination'     => '',
			'carousel_arrowpagination'      => '',
			'carousel_arrowpagination_type' => '',
			'carousel_scrollbar'            => '',
			'carousel_spacebetween'         => '',

			'class'                         => ''
		), $attrs ) );

		$out = dtshop_products_render_html($attrs);

		return $out;

	}
	add_shortcode( 'dtshop_product_listing', 'dtshop_product_listing_html' );
}

if(!function_exists('dtshop_products_render_html')) {
	function dtshop_products_render_html($settings) {

		$output = '';

		$woo_product_style_template = $settings['product_style_template'];

		if($settings['display_mode'] == 'list') {
			$settings['columns'] = 1;
			$settings['carousel_slidesperview'] = 1;
		}


		$media_carousel_attributes_string = $container_class = $wrapper_class = $item_class = '';

		if($settings['enable_carousel'] == 'true') {

			$media_carousel_attributes = array ();

			array_push($media_carousel_attributes, 'data-carouseleffect="'.$settings['carousel_effect'].'"');
			array_push($media_carousel_attributes, 'data-carouselslidesperview="'.$settings['carousel_slidesperview'].'"');
			array_push($media_carousel_attributes, 'data-carouselloopmode="'.$settings['carousel_loopmode'].'"');
			array_push($media_carousel_attributes, 'data-carouselmousewheelcontrol="'.$settings['carousel_mousewheelcontrol'].'"');
			array_push($media_carousel_attributes, 'data-carouselbulletpagination="'.$settings['carousel_bulletpagination'].'"');
			array_push($media_carousel_attributes, 'data-carouselarrowpagination="'.$settings['carousel_arrowpagination'].'"');
			array_push($media_carousel_attributes, 'data-carouselscrollbar="'.$settings['carousel_scrollbar'].'"');
			array_push($media_carousel_attributes, 'data-carouselspacebetween="'.$settings['carousel_spacebetween'].'"');

			if(!empty($media_carousel_attributes)) {
				$media_carousel_attributes_string = implode(' ', $media_carousel_attributes);
			}


			$container_class = 'swiper-container';
			$wrapper_class = 'swiper-wrapper';
			$item_class = 'swiper-slide';

			$output .= '<div class="dt-sc-products-carousel-container">';

		}

		// Loop variables setup
		wc_set_loop_prop('is_shortcode', 1);
		wc_set_loop_prop('product_style_template', $settings['product_style_template']);
		wc_set_loop_prop('item_class', $item_class);
		wc_set_loop_prop('columns', $settings['columns']);
		wc_set_loop_prop('display_mode', $settings['display_mode']);
		wc_set_loop_prop('display_mode_list_options', $settings['list_options']);

		dtshop_product_style_setup_template_prop($woo_product_style_template); // Call Product Style Variables Setup

		$output .= '<div class="dt-sc-products-container woocommerce '.$settings['class'].' '.$container_class.'" '.$media_carousel_attributes_string.'>';

			$output .= '<ul class="products '.$wrapper_class.' '.dtshop_products_list_class().'">';

				ob_start();

					if( empty( $settings['post_per_page'] ) ) {
						$settings['post_per_page'] = -1;
					}

					$args = array(
						'post_type'      => 'product',
						'post_status'    => 'publish',
						'posts_per_page' => $settings['post_per_page'],
						'meta_query'     => array (),
						'tax_query'      => array (),
						'offset'         => $settings['offset'],
						'paged'          => $settings['current_page'],
					);


					// Exclude hidden products
					$args['tax_query'][] = array(
						'taxonomy'         => 'product_visibility',
						'terms'            => array( 'exclude-from-catalog', 'exclude-from-search' ),
						'field'            => 'name',
						'operator'         => 'NOT IN',
						'include_children' => false,
					);


					// Categories
					$categories = ($settings['categories'] != '') ? $settings['categories'] : array ();
					if(!empty($categories)) {
						$args['tax_query'][] = array (
													'taxonomy' => 'product_cat',
													'field'    => 'id',
													'terms'    => $categories,
													'operator' => 'IN'
												);
					}

					// Tags
					$tags = ($settings['tags'] != '') ? $settings['tags'] : array ();
					if(!empty($tags)) {
						$args['tax_query'][] = array (
													'taxonomy' => 'product_tag',
													'field'    => 'id',
													'terms'    => $tags,
													'operator' => 'IN'
												);
					}

					// Include
					$include = ($settings['include'] != '') ? $settings['include'] : array ();
					if(!empty($include)) {
						$args['post__in'] = $include;
					}

					// Exclude
					$exclude = ($settings['exclude'] != '') ? $settings['exclude'] : array ();
					if(!empty($exclude)) {
						$args['post__not_in'] = $exclude;
					}

					// Data Source

					# Featured
					if ( $settings['data_source'] == 'featured' ) {
						$args['tax_query'][] = array (
													'taxonomy' => 'product_visibility',
													'field'    => 'name',
													'terms'    => 'featured',
													'operator' => 'IN',
												);
					}

					# Sale
					if ( $settings['data_source'] == 'sale' ) {
						if(!empty($include)) {
							$args['post__in'] = array_merge( $include, wc_get_product_ids_on_sale() );
						} else {
							$args['post__in'] = wc_get_product_ids_on_sale();
						}
					}

					# Best Seller
					if ( $settings['data_source'] == 'bestseller' ) {
						$args['orderby'] = 'meta_value_num';
						$args['meta_key'] = 'total_sales';
					}

					# Recent
					if ( $settings['data_source'] == 'recent' ) {
						$args['orderby'] = 'date';
						$args['order'] = 'DESC';
					}

					// Loop

					$products = new WP_Query( $args );

					if ( $products->have_posts() ) :
						while ( $products->have_posts() ) :
							$products->the_post();
							wc_get_template_part( 'content', 'product' );
						endwhile;
					endif;

					wp_reset_postdata();

				$output .= ob_get_clean();

			$output .= '</ul>';

			$max_num_pages = $products->max_num_pages;

			// For pagination
			if($settings['show_pagination'] == 'true') {
				$shortcode_settings = json_encode($settings);
				$output .= dtshop_products_ajax_pagination($max_num_pages, $settings['current_page'], $settings['post_per_page'], 'dtshop_products_ajax_call', 'dt-sc-products-container', $shortcode_settings);
			}

			if($settings['enable_carousel'] == 'true') {

				$output .= '<div class="dt-sc-products-pagination-holder">';

					if($settings['carousel_bulletpagination'] == 'true') {
						$output .= '<div class="dt-sc-products-bullet-pagination"></div>';
					}

					if($settings['carousel_scrollbar'] == 'true') {
						$output .= '<div class="dt-sc-products-scrollbar"></div>';
					}

					if($settings['carousel_arrowpagination'] == 'true') {
						$output .= '<div class="dt-sc-products-arrow-pagination '.$settings['carousel_arrowpagination_type'].'">';
							$output .= '<a href="#" class="dt-sc-products-arrow-prev">'.esc_html__('Prev', 'dtshop').'</a>';
							$output .= '<a href="#" class="dt-sc-products-arrow-next">'.esc_html__('Next', 'dtshop').'</a>';
						$output .= '</div>';
					}

				$output .= '</div>';

			}

		$output .= '</div>';

		// Reset the loop.
		wc_reset_loop();

		if($settings['enable_carousel'] == 'true') {
			$output .= '</div>';
		}

		return $output;

	}
}


/* Product 360 Image Viewer - Shortcodes */

if(!function_exists('dtshop_product_images_360viewer_html')) {
	function dtshop_product_images_360viewer_html($attrs, $content = null) {

		extract ( shortcode_atts ( array (
			'product_id'          => '',
			'enable_popup_viewer' => '',
			'source'              => '',
			'class'               => ''
		), $attrs ) );

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';
		wp_enqueue_style( 'dtshop-product-single-images-360-viewer', dtshop_instance()->plugin_url('elementor/widgets/360-image-viewer/style'.$suffix.'.css'), array (), false, 'all' );

		wp_enqueue_script('jquery.360viewer', dtshop_instance()->plugin_url('js/360-viewer.js'), array ('jquery'), false, true);
		wp_enqueue_script('dtshop-product-single-images-360-viewer', dtshop_instance()->plugin_url('elementor/widgets/360-image-viewer/script'.$suffix.'.js'), array ('jquery'), false, true);

		$output = dtshop_product_images_360viewer_render_html($attrs);

		return $output;

	}
	add_shortcode( 'dtshop_product_images_360viewer', 'dtshop_product_images_360viewer_html' );
}

if(!function_exists('dtshop_product_images_360viewer_render_html')) {
	function dtshop_product_images_360viewer_render_html($settings) {

		$output = '';

		if($settings['product_id'] == '' && is_singular('product')) {
			global $post;
			$settings['product_id'] = $post->ID;
		}

		if($settings['product_id'] != '') {

			if($settings['enable_popup_viewer'] == 'true') {

				$viewer360_gallery_ids = get_post_meta ( $settings['product_id'], '_360viewer_gallery', true );
				$viewer360_gallery_ids = (isset($viewer360_gallery_ids['product-360view-gallery']) && $viewer360_gallery_ids['product-360view-gallery'] != '') ? explode(',', $viewer360_gallery_ids['product-360view-gallery']) : array ();

				if(isset($viewer360_gallery_ids[0])) {

					$output .= '<div class="dt-sc-product-image-360-viewer-holder dt-sc-product-image-360-popup-viewer-holder '.$settings['class'].'">';

						$output .= '<div class="dt-sc-product-image-360-viewer-enlarger">A</div>';

						if($settings['source'] != 'single-product') {

							$image = wp_get_attachment_image( $viewer360_gallery_ids[0], 'full', false );
							$output .= $image;

						}

						$output .= '<div class="dt-sc-product-image-360-viewer-container">';

							$output .= '<div class="dt-sc-product-image-360-viewer" data-count="'.count($viewer360_gallery_ids).'">';

			                    if(is_array($viewer360_gallery_ids) && !empty($viewer360_gallery_ids)) {
			                    	$i = 1;
			                        foreach($viewer360_gallery_ids as $viewer360_gallery_id) {

										$image = wp_get_attachment_image( $viewer360_gallery_id, 'full', false, array (
													'data-index' => $i,
												) );

										$output .= $image;

										$i++;

			                        }
			                    }

					   		$output .= '</div>';

					   		$output .= '<div class="dt-sc-product-image-360-viewer-close">'.esc_html__( 'Close', 'dtshop' ).'</div>';

					   	$output .= '</div>';

					$output .= '</div>';

				}

			} else {

				$output .= '<div class="dt-sc-product-image-360-viewer-holder '.$settings['class'].'">';

					$output .= '<div class="dt-sc-product-image-360-viewer-container">';

						$viewer360_gallery_ids = get_post_meta ( $settings['product_id'], '_360viewer_gallery', true );
						$viewer360_gallery_ids = (isset($viewer360_gallery_ids['product-360view-gallery']) && $viewer360_gallery_ids['product-360view-gallery'] != '') ? explode(',', $viewer360_gallery_ids['product-360view-gallery']) : array ();

						$output .= '<div class="dt-sc-product-image-360-viewer" id="dt-sc-product-image-360-viewer" data-count="'.count($viewer360_gallery_ids).'">';

		                    if(is_array($viewer360_gallery_ids) && !empty($viewer360_gallery_ids)) {
		                    	$i = 1;
		                        foreach($viewer360_gallery_ids as $viewer360_gallery_id) {

									$image = wp_get_attachment_image( $viewer360_gallery_id, 'full', false, array (
												'data-index' => $i,
											) );

									$output .= $image;

									$i++;

		                        }
		                    }

				   		$output .= '</div>';

				   	$output .= '</div>';

			   	$output .= '</div>';

		   }

		} else {

			$output .= esc_html__('Please provide product id to display corresponding data!', 'dtshop');

		}

		return $output;

	}
}