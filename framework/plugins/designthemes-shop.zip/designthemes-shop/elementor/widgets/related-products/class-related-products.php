<?php
namespace DTElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DTShop_Widget_Related_Products extends Widget_Base {

	public function get_categories() {
		return [ 'dtshop-widgets' ];
	}

	public function get_name() {
		return 'dt-shop-related-products';
	}

	public function get_title() {
		return esc_html__( 'Product Single - Related Products', 'dtshop' );
	}

	public function get_style_depends() {
		return array( 'dtshop-product-single-related-products' );
	}

	public function product_style_templates() {

		$shop_product_templates = array();
		$shop_product_templates[-1] = esc_html__('Admin Option', 'dtshop');

		$args = array ( 'post_type' => 'dtshop_list_template', 'post_status' => 'publish' );

		$product_template_pages = get_posts( $args );

		foreach($product_template_pages as $product_template_page) {
			$id = $product_template_page->ID;
			$shop_product_templates[$id] = get_the_title($id);
		}

		return $shop_product_templates;
	}

	protected function _register_controls() {

		$this->start_controls_section( 'product_featured_image_section', array(
			'label' => esc_html__( 'General', 'dtshop' ),
		) );

			$this->add_control( 'product_id', array(
				'label'       => esc_html__( 'Product Id', 'dtshop' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__('Provide product id for which you have to display product summary items. No need to provide ID if it is used in Product single page.', 'dtshop'),				
			) );

			$this->add_control( 'columns', array(
				'label'       => __( 'Columns', 'dtshop' ),
				'type'        => Controls_Manager::SELECT,
				'description' => esc_html__( 'Choose column that you like to display upsell products.', 'dtshop' ),
				'options'     => array( 1 => 1, 2 => 2, 3 => 3, 4 => 4 ),
				'default'     => 4,
	        ) );

			$this->add_control( 'limit', array(
				'label'       => __( 'Limit', 'dtshop' ),
				'type'        => Controls_Manager::SELECT,
				'description' => esc_html__( 'Choose number of products that you like to display.', 'dtshop' ),
				'options'     => array( 1 => 1, 2 => 2, 3 => 3, 4 => 4, 5 => 5, 6 => 6, 7 => 7, 8 => 8, 9 => 9, 10 => 10 ),
				'default'     => 4,
	        ) );

			$this->add_control( 'product_style_template', array(
				'label'       => __( 'Product Style Template', 'dtshop' ),
				'type'        => Controls_Manager::SELECT,
				'description' => esc_html__( 'Choose number of products that you like to display.', 'dtshop' ),
				'options'     => $this->product_style_templates(),
				'default'     => '-1',
	        ) );

			$this->add_control( 'hide_title', array(
				'label'        => esc_html__( 'Hide Title', 'dtshop' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => esc_html__('If you wish to hide title you can do it here', 'dtshop'),
				'label_on'     => __( 'yes', 'dtshop' ),
				'label_off'    => __( 'no', 'dtshop' ),
				'default'      => '',
				'return_value' => 'true',
			) );	
			
			$this->add_control(
				'class',
				array (
					'label' => __( 'Class', 'dtshop' ),
					'type'  => Controls_Manager::TEXT
				)
			);

		$this->end_controls_section();
		
	}

	protected function render() {

		$settings = $this->get_settings();

		$output = '';
	
		if($settings['product_id'] == '' && is_singular('product')) {
			global $post;
			$settings['product_id'] = $post->ID;
		}

		if($settings['product_id'] != '') {

			$output .= '<div class="dt-sc-product-related-products '.$settings['class'].'">';

				if($settings['product_style_template'] == 'admin-option') {
					$product_style_template = dtshop_get_option( 'dt-single-product-related-style-template' );
				} else {
					$product_style_template = $settings['product_style_template'];
				}

				$display_mode = dtshop_woo_post_display_mode_from_location($product_style_template);
				if($display_mode == 'list') {
					$settings['columns'] = 1;	
				}

				// Hide Title
				wc_set_loop_prop('product_related_hide_title', $settings['hide_title']);
				wc_set_loop_prop('is_shortcode', 1);
				wc_set_loop_prop('product_style_template', $product_style_template);

				$output .= dtshop_product_style_setup_template_prop($product_style_template); /* Call Product Style Variables Setup */

				ob_start();
				woocommerce_related_products( array ( 'posts_per_page' => $settings['limit'], 'columns' => $settings['columns'], 'orderby' => 'rand' ) );
				$output .= ob_get_clean();

				dtshop_product_style_reset_template_prop(); /* Reset Product Style Variables Setup */

			$output .= '</div>';
			
		} else {
		
			$output .= esc_html__('Please provide product id to display corresponding data!', 'dtshop');
			
		}

		echo $output;

	}

}