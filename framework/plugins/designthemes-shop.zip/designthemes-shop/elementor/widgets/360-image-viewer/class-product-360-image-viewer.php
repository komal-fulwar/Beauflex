<?php
namespace DTElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DTShop_Widget_Product_360_Image_Viewer extends Widget_Base {

	public function get_categories() {
		return [ 'dtshop-widgets' ];
	}

	public function get_name() {
		return 'dt-shop-product-single-images-360-viewer';
	}

	public function get_title() {
		return esc_html__( 'Product Single - Images 360 Viewer', 'dtshop' );
	}

	public function get_style_depends() {
		return array( 'dtshop-product-single-images-360-viewer' );
	}

	public function get_script_depends() {
		return array( 'jquery.360viewer', 'dtshop-product-single-images-360-viewer' );
	}

	protected function _register_controls() {

		$this->start_controls_section( 'product_images_360viewer_section', array(
			'label' => esc_html__( 'Product', 'dtshop' ),
		) );

			$this->add_control( 'product_id', array(
				'label'       => esc_html__( 'Product Id', 'dtshop' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__('Provide product id for which you have to display product images in list format. No need to provide ID if it is used in Product single page.', 'dtshop'),				
			) );

			$this->add_control( 'enable_popup_viewer', array(
				'label'        => esc_html__( 'Enable PopUp Viewer', 'dtshop' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => esc_html__('If you wish, you can show 360 viewer in popup.', 'dtshop'),
				'label_on'     => __( 'yes', 'dtshop' ),
				'label_off'    => __( 'no', 'dtshop' ),
				'default'      => '',
				'return_value' => 'true',
			) );

			$this->add_control(
				'source',
				array (
					'label' => __( 'Source', 'dtshop' ),
					'type'  => Controls_Manager::TEXT
				)
			);

			$this->add_control(
				'class',
				array (
					'label' => __( 'Class', 'dtshop' ),
					'type'  => Controls_Manager::TEXT
				)
			);

		$this->end_controls_section();		
	}

	protected function render() {

		$settings = $this->get_settings();

		$output = dtshop_product_images_360viewer_render_html($settings);

		echo $output;

	}


}