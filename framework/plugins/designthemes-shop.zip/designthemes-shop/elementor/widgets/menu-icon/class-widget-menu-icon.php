<?php
namespace DTElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class DTShop_Widget_Menu_Icon extends Widget_Base {

	public function get_categories() {
		return [ 'dtshop-widgets' ];
	}

	public function get_name() {
		return 'dt-shop-menu-icon';
	}

	public function get_title() {
		return esc_html__( 'Menu Icon', 'dtshop' );
	}

	public function get_style_depends() {
		return array( 'dtshop-shop-menu-icon' );
	}

	public function get_script_depends() {
		return array( 'jquery-nicescroll', 'dtshop-shop-menu-icon' );
	}

	protected function _register_controls() {

		$this->start_controls_section( 'cart_icon_section', array(
			'label' => esc_html__( 'Cart Icon', 'dtshop' ),
		) );

			$this->add_control( 'cart_action', array(
				'label'       => __( 'Cart Action', 'dtshop' ),
				'type'        => Controls_Manager::SELECT,
				'description' => __( 'Choose how you want to display the cart content.', 'dtshop'),
				'default'     => '',
				'options'     => array(
					''                    => __( 'None', 'dtshop'),
					'notification_widget' => __( 'Notification Widget', 'dtshop' ),
					'sidebar_widget'      => __( 'Sidebar Widget', 'dtshop' ),
	            ),
	        ) );

			$this->add_control(
				'class',
				array (
					'label' => __( 'Class', 'dtshop' ),
					'type'  => Controls_Manager::TEXT
				)
			);

		$this->end_controls_section();

	}

	protected function render() {

		$output = '';

		if( function_exists( 'is_woocommerce' ) ) {

			$settings = $this->get_settings();

			$output .= '<div class="dt-sc-shop-menu-icon '.$settings['class'].'">';

				$output .= '<a href="'.esc_url( wc_get_cart_url() ).'">';
					$output .= '<span class="dt-sc-shop-menu-icon-wrapper">';
						$output .= '<span class="dt-sc-shop-menu-cart-inner">';
							$output .= '<span class="dt-sc-shop-menu-cart-icon"></span>';
							$output .= '<span class="dt-sc-shop-menu-cart-number">0</span>';
						$output .= '</span>';
						$output .= '<span class="dt-sc-shop-menu-cart-totals"></span>';
					$output .= '</span>';
				$output .= '</a>';

				if($settings['cart_action'] == 'notification_widget') {

					$output .= '<div class="dt-sc-shop-menu-cart-content-wrapper">';
						$output .= '<div class="dt-sc-shop-menu-cart-content">'.esc_html__('No products added!', 'dtshop').'</div>';
					$output .= '</div>';

					set_site_transient( 'cart_action', 'notification_widget', 12 * HOUR_IN_SECONDS );

				} else if($settings['cart_action'] == 'sidebar_widget') {

					set_site_transient( 'cart_action', 'sidebar_widget', 12 * HOUR_IN_SECONDS );

				} else {
					
					set_site_transient( 'cart_action', 'none', 12 * HOUR_IN_SECONDS );

				}

			$output .= '</div>';

		}

		echo $output;

	}

}