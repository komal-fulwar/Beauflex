<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sociable Share Settings
 */
$wp_customize->add_section( 
	new IVA_WP_Customize_Section(
		$wp_customize,
		'woocommerce-product-single-page-sociables-share-section',
		array(
			'title'    => esc_html__('Sociable Share Settings', 'dtshop'),
			'panel'    => 'woocommerce-product-single-page-section',
			'priority' => 40,
		)
	)
);
	
	/**
	* Option : Sharer Description
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-description]', array(
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-description]', array(
				'type'    => 'dt-description',
				'label'   => esc_html__( 'Note :', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'description'   => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'dtshop'),
			)
		)
	);

	/**
	* Option : Show Facebook Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-facebook]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-facebook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-facebook]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Facebook Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Delicious Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-delicious]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-delicious' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-delicious]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Delicious Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Digg Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-digg]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-digg' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-digg]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Digg Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Stumble Upon Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-stumbleupon]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-stumbleupon' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-stumbleupon]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Stumble Upon Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Twitter Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-twitter]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-twitter' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-twitter]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Twitter Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Google Plus Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-googleplus]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-googleplus' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-googleplus]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Google Plus Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show LinkedIn Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-linkedin]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-linkedin' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-linkedin]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show LinkedIn Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);
	
	/**
	* Option : Show Pinterest Sharer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-pinterest]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-sharer-pinterest' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-sharer-pinterest]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Pinterest Sharer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-share-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);