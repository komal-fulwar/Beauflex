<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sociable Follow Settings
 */
$wp_customize->add_section( 
	new IVA_WP_Customize_Section(
		$wp_customize,
		'woocommerce-product-single-page-sociables-follow-section',
		array(
			'title'    => esc_html__('Sociable Follow Settings', 'dtshop'),
			'panel'    => 'woocommerce-product-single-page-section',
			'priority' => 45,
		)
	)
);
	
	/**
	* Option : Follow Description
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-follow-description]', array(
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-follow-description]', array(
				'type'    => 'dt-description',
				'label'   => esc_html__( 'Note :', 'dtshop'),
				'section' => 'woocommerce-product-single-page-sociables-follow-section',
				'description'   => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'dtshop'),
			)
		)
	);

$social_follow = array (
	'delicious' 	 => esc_html__('Delicious', 'dtshop'),
	'deviantart'  => esc_html__('Deviantart', 'dtshop'),
	'digg' 	  	   => esc_html__('Digg', 'dtshop'),
	'dribbble' 	  => esc_html__('Dribbble', 'dtshop'),
	'envelope' 	  => esc_html__('Envelope', 'dtshop'),
	'facebook' 	  => esc_html__('Facebook', 'dtshop'),
	'flickr' 		   => esc_html__('Flickr', 'dtshop'),
	'google-plus' => esc_html__('Google Plus', 'dtshop'),
	'gtalk'  		   => esc_html__('GTalk', 'dtshop'),
	'instagram'	  => esc_html__('Instagram', 'dtshop'),
	'lastfm'	 	   => esc_html__('Lastfm', 'dtshop'),
	'linkedin'	   => esc_html__('Linkedin', 'dtshop'),
	'myspace'		   => esc_html__('Myspace', 'dtshop'),
	'picasa'		    => esc_html__('Picasa', 'dtshop'),
	'pinterest'	  => esc_html__('Pinterest', 'dtshop'),
	'reddit'		    => esc_html__('Reddit', 'dtshop'),
	'rss'		 	     => esc_html__('RSS', 'dtshop'),
	'skype'		     => esc_html__('Skype', 'dtshop'),
	'stumbleupon' => esc_html__('Stumbleupon', 'dtshop'),
	'technorati'	 => esc_html__('Technorati', 'dtshop'),
	'tumblr'		    => esc_html__('Tumblr', 'dtshop'),
	'twitter'		   => esc_html__('Twitter', 'dtshop'),
	'viadeo'		    => esc_html__('Viadeo', 'dtshop'),
	'vimeo'		     => esc_html__('Vimeo', 'dtshop'),
	'yahoo'		     => esc_html__('Yahoo', 'dtshop'),
	'youtube'		   => esc_html__('Youtube', 'dtshop')
);

foreach($social_follow as $socialfollow_key => $socialfollow) {

	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-follow-'.$socialfollow_key.']', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-follow-'.$socialfollow_key ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-follow-'.$socialfollow_key.']', array(
				'type'    => 'dt-switch',
				'label'   => sprintf(esc_html__('Show %1$s Follow', 'dtshop'), $socialfollow),
				'section' => 'woocommerce-product-single-page-sociables-follow-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

}