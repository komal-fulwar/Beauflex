<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default Settings
 */
$wp_customize->add_section( 
	new IVA_WP_Customize_Section(
		$wp_customize,
		'woocommerce-product-single-page-default-section',
		array(
			'title'    => esc_html__('Default Settings', 'dtshop'),
			'panel'    => 'woocommerce-product-single-page-section',
			'priority' => 25,
		)
	)
);
	
	/**
	 * Option : Product Template
	 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-default-template]', array(
			'default'           => dtshop_get_option( 'dt-single-product-default-template' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[dt-single-product-default-template]', array(
			'type'     => 'select',
			'label'    => esc_html__( 'Product Template', 'dtshop'),
			'section'  => 'woocommerce-product-single-page-default-section',
			'choices'  => apply_filters( 'dtshop_single_product_default_template', array(
							'woo-default'     => esc_html__( 'WooCommerce Default', 'dtshop' ),
							'custom-template' => esc_html__( 'Custom Template', 'dtshop' )
						) )
		)
	);

	/**
	* Option : Enable Sale Countdown Timer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-sale-countdown-timer]', array(
			'default'           => dtshop_get_option( 'dt-single-product-sale-countdown-timer' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-sale-countdown-timer]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Sale Countdown Timer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	* Option : Enable Size Guide Button
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-enable-size-guide]', array(
			'default'           => dtshop_get_option( 'dt-single-product-enable-size-guide' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-enable-size-guide]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Size Guide Button', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	* Option : Enable Ajax Add To Cart
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-enable-ajax-addtocart]', array(
			'default'           => dtshop_get_option( 'dt-single-product-enable-ajax-addtocart' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-enable-ajax-addtocart]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Ajax Add To Cart', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	* Option : Enable Breadcrumb
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-enable-breadcrumb]', array(
			'default'           => dtshop_get_option( 'dt-single-product-enable-breadcrumb' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-enable-breadcrumb]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Breadcrumb', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	* Option : Sticky Add to Cart
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-addtocart-sticky]', array(
			'default'           => dtshop_get_option( 'dt-single-product-addtocart-sticky' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-addtocart-sticky]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Sticky Add to Cart', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	* Option : Show Product 360 Viewer
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-show-360-viewer]', array(
			'default'           => dtshop_get_option( 'dt-single-product-show-360-viewer' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-show-360-viewer]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Product 360 Viewer', 'dtshop'),
				'section' => 'woocommerce-product-single-page-default-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				),
				'description'   => esc_html__('This option is applicable only for "WooCommerce Default" single page.', 'dtshop'),
			)
		)
	);