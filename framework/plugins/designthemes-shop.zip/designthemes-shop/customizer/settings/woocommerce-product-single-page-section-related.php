<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Related Settings
 */
$wp_customize->add_section( 
	new IVA_WP_Customize_Section(
		$wp_customize,
		'woocommerce-product-single-page-related-section',
		array(
			'title'    => esc_html__('Related Settings', 'dtshop'),
			'panel'    => 'woocommerce-product-single-page-section',
			'priority' => 35,
		)
	)
);
	

	/**
	* Option : Show Related Products
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-default-show-related]', array(
			'default'           => dtshop_get_option( 'dt-single-product-default-show-related' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-default-show-related]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Related Products', 'dtshop'),
				'section' => 'woocommerce-product-single-page-related-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);

	/**
	 * Option : Related Title
	 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-related-title]', array(
			'default'           => dtshop_get_option( 'dt-single-product-related-title' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[dt-single-product-related-title]', array(
			'type'       => 'text',
			'section'    => 'woocommerce-product-single-page-related-section',
			'label'      => esc_html__( 'Related Title', 'dtshop' )
		)
	);

	/**
	 * Option : Related Column
	 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-related-column]', array(
			'default'           => dtshop_get_option( 'dt-single-product-related-column' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-related-column]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Related Column', 'dtshop'),
				'section'  => 'woocommerce-product-single-page-related-section',
				'choices'  => apply_filters( 'dtshop_single_product_related_column_options',  dtshop_customizer_instance()->dtshop_product_column_options(true) )
			)
		)
	);

	/**
	* Option : Related Limit
	*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-related-limit]', array(
			'default'           => dtshop_get_option( 'dt-single-product-related-limit' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-related-limit]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Related Limit', 'dtshop'),
				'section'  => 'woocommerce-product-single-page-related-section',
				'choices'  => array (
					1 => esc_html__( '1', 'dtshop' ),
					2 => esc_html__( '2', 'dtshop' ),
					3 => esc_html__( '3', 'dtshop' ),
					4 => esc_html__( '4', 'dtshop' ),
					5 => esc_html__( '5', 'dtshop' ),
					6 => esc_html__( '6', 'dtshop' ),
					7 => esc_html__( '7', 'dtshop' ),
					8 => esc_html__( '8', 'dtshop' ),	
					9 => esc_html__( '9', 'dtshop' ),
					10 => esc_html__( '10', 'dtshop' ),	
				)
			)
		)
	);

	
	/**
	 * Option : Product Style Template
	 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-single-product-related-style-template]', array(
			'default'           => dtshop_get_option( 'dt-single-product-related-style-template' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-single-product-related-style-template]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Product Style Template', 'dtshop'),
				'section'  => 'woocommerce-product-single-page-related-section',
				'choices'  => apply_filters( 'dtshop_product_templates', dtshop_customizer_instance()->dtshop_product_templates_list() )
			)
		)
	);