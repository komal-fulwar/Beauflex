<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Option : Page Layout
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-layout]', array(
			'default'           => dtshop_get_option( 'shop-page-layout' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-layout]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Layout', 'dtshop'),
				'section'  => 'woocommerce-shop-page-section',
				'choices'  => apply_filters( 'dtshop_page_layout_options', dtshop_customizer_instance()->dtshop_page_layout_options() )
			)
		)
	);

/**
 * Option : Show Standard Sidebar
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-show-standard-sidebar]', array(
			'default'           => dtshop_get_option( 'shop-page-show-standard-sidebar' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-show-standard-sidebar]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Standard Sidebar', 'dtshop'),
				'section' => 'woocommerce-shop-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				),
				'dependency' => array( 'shop-page-layout', 'any', 'with-left-sidebar,with-right-sidebar' )
			)
		)
	);

/**
 * Option : Widget Areas
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-widgetareas]', array(
			'default'           => dtshop_get_option( 'shop-page-widgetareas' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[shop-page-widgetareas]', array(
			'type'     => 'select',
			'label'    => esc_html__( 'Choose Custom Widget Area', 'dtshop'),
			'section'  => 'woocommerce-shop-page-section',
			'choices'  => apply_filters( 'dtshop_page_widgetareas', iva_customizer_custom_widgets() ),
			'dependency' => array( 'shop-page-layout', 'any', 'with-left-sidebar,with-right-sidebar' )
		)
	);

/**
 * Option : Products Per Page
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-product-per-page]', array(
			'default'           => dtshop_get_option( 'shop-page-product-per-page' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_number_n_blank' ),
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[shop-page-product-per-page]', array(
			'type'       => 'number',
			'section'    => 'woocommerce-shop-page-section',
			'label'      => esc_html__( 'Products Per Page', 'dtshop' )
		)
	);


/**
 * Option : Product Layout
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-product-layout]', array(
			'default'           => dtshop_get_option( 'shop-page-product-layout' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-product-layout]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Product Layout', 'dtshop'),
				'section'  => 'woocommerce-shop-page-section',
				'choices'  => apply_filters( 'dtshop_product_layout_options',  dtshop_customizer_instance()->dtshop_product_column_options(true) )
			)
		)
	);


/**
 * Option : Product Style Template
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-product-style-template]', array(
			'default'           => dtshop_get_option( 'shop-page-product-style-template' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-product-style-template]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Product Style Template', 'dtshop'),
				'section'  => 'woocommerce-shop-page-section',
				'choices'  => apply_filters( 'dtshop_product_templates', dtshop_customizer_instance()->dtshop_product_templates_list() )
			)
		)
	);


/**
 * Option : Enable Breadcrumb
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-enable-breadcrumb]', array(
			'default'           => dtshop_get_option( 'shop-page-enable-breadcrumb' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-enable-breadcrumb]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Breadcrumb', 'dtshop'),
				'section' => 'woocommerce-shop-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);


/**
 * Option : Bottom Hook
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-bottom-hook]', array(
			'default'           => dtshop_get_option( 'shop-page-bottom-hook' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[shop-page-bottom-hook]', array(
			'type'    => 'textarea',
			'label'   => esc_html__( 'Bottom Hook', 'dtshop'),
			'section' => 'woocommerce-shop-page-section'
		)
	);


/**
 * Divider : Separator
 */
	$wp_customize->add_control(
		new IVA_Customize_Control_Separator(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-separator1]', array(
				'type'     => 'dt-separator',
				'section'  => 'woocommerce-shop-page-section',
				'settings' => array()
			)
		)
	);


/**
 * Option : Show Sorter On Header
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-show-sorter-on-header]', array(
			'default'           => dtshop_get_option( 'shop-page-show-sorter-on-header' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-show-sorter-on-header]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Sorter On Header', 'dtshop'),
				'section' => 'woocommerce-shop-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);


/**
 * Option : Sorter Header Elements
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-sorter-header-elements]', array(
			'default'           => dtshop_get_option( 'shop-page-sorter-header-elements' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_multi_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Sortable(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-sorter-header-elements]', array(
				'type'     => 'dt-sortable',
				'section'  => 'woocommerce-shop-page-section',
				'label'    => esc_html__( 'Sorter Header Elements', 'dtshop' ),
				'choices'  => array(
					'filter'               => esc_html__( 'Filter', 'dtshop' ),
					'result_count'         => esc_html__( 'Result Count', 'dtshop' ),
					'pagination'           => esc_html__( 'Pagination', 'dtshop' ),
					'display_mode'         => esc_html__( 'Display Mode', 'dtshop' ),
					'display_mode_options' => esc_html__( 'Display Mode Options', 'dtshop' ),
				)
			)
		)
	);


/**
 * Option : Show Sorter On Footer
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-show-sorter-on-footer]', array(
			'default'           => dtshop_get_option( 'shop-page-show-sorter-on-footer' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-show-sorter-on-footer]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Sorter On Footer', 'dtshop'),
				'section' => 'woocommerce-shop-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtshop' ),
					'off' => esc_attr__( 'No', 'dtshop' )
				)
			)
		)
	);


/**
 * Option : Sorter Footer Elements
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[shop-page-sorter-footer-elements]', array(
			'default'           => dtshop_get_option( 'shop-page-sorter-footer-elements' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_multi_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Sortable(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-sorter-footer-elements]', array(
				'type'     => 'dt-sortable',
				'section'  => 'woocommerce-shop-page-section',
				'label'    => esc_html__( 'Sorter Footer Elements', 'dtshop' ),
				'choices'  => array(
					'filter'               => esc_html__( 'Filter', 'dtshop' ),
					'result_count'         => esc_html__( 'Result Count', 'dtshop' ),
					'pagination'           => esc_html__( 'Pagination', 'dtshop' ),
					'display_mode'         => esc_html__( 'Display Mode', 'dtshop' ),
					'display_mode_options' => esc_html__( 'Display Mode Options', 'dtshop' ),
				)
			)
		)
	);