<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
* Option : Enable Plus / Minus Button - Quantity
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-woo-quantity-plusnminus]', array(
			'default'           => dtshop_get_option( 'dt-woo-quantity-plusnminus' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-woo-quantity-plusnminus]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Plus / Minus Button - Quantity', 'dtshop'),
				'section' => 'woocommerce-others-section',
				'choices' => array(
					'on'  => esc_html__( 'Yes', 'dtshop' ),
					'off' => esc_html__( 'No', 'dtshop' )
				)
			)
		)
	);

/**
 * Divider : Separator
 */
	$wp_customize->add_control(
		new IVA_Customize_Control_Separator(
			$wp_customize, IVA_THEME_SETTINGS . '[shop-page-separator1]', array(
				'type'     => 'dt-separator',
				'section'  => 'woocommerce-others-section',
				'settings' => array()
			)
		)
	);

/**
 * Option : Add To Cart Custom Action
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-woo-addtocart-custom-action]', array(
			'default'           => dtshop_get_option( 'dt-woo-addtocart-custom-action' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-woo-addtocart-custom-action]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Add To Cart Custom Action', 'dtshop'),
				'section'  => 'woocommerce-others-section',
				'choices'  => apply_filters( 'dtshop_others_addtocart_custom_action', 
					array(
						''                    => esc_html__('None', 'dtshop'),
						'sidebar_widget'      => esc_html__('Sidebar Widget', 'dtshop'),
						'notification_widget' => esc_html__('Notification Widget', 'dtshop'),
					)
				)
			)
		)
	);

/**
 * Option : Cross Sell Product Column
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-woo-cross-sell-column]', array(
			'default'           => dtshop_get_option( 'dt-woo-cross-sell-column' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-woo-cross-sell-column]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Cross Sell Product Column', 'dtshop'),
				'section'  => 'woocommerce-others-section',
				'choices'  => apply_filters( 'dtshop_cross_sell_column_options', dtshop_customizer_instance()->dtshop_product_column_options(false) )
			)
		)
	);

/**
 * Option : Cross Sell Title
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-woo-cross-sell-title]', array(
			'default'           => dtshop_get_option( 'dt-woo-cross-sell-title' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		IVA_THEME_SETTINGS . '[dt-woo-cross-sell-title]', array(
			'type'       => 'text',
			'section'    => 'woocommerce-others-section',
			'label'      => esc_html__( 'Cross Sell Title', 'dtshop' )
		)
	);

/**
 * Option : Product Style Template
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dt-woo-cross-sell-style-template]', array(
			'default'           => dtshop_get_option( 'dt-woo-cross-sell-style-template' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[dt-woo-cross-sell-style-template]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Product Style Template', 'dtshop'),
				'section'  => 'woocommerce-others-section',
				'choices'  => apply_filters( 'dtshop_product_templates', dtshop_customizer_instance()->dtshop_product_templates_list() )
			)
		)
	);	