<?php
if( !class_exists('DTShopCustomizerSettings') ) {

	class DTShopCustomizerSettings {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action( 'customize_register',array( $this, 'dtshop_register_settings' ), 20 );
			add_filter( 'dttheme_default_settings', array( $this, 'dtshop_default_settings' ) );
		}

		public function dtshop_register_settings( $wp_customize ) {

			require dtshop_instance()->plugin_path( 'customizer/settings/index.php' );

		}

		public function dtshop_default_settings( $defaults ) {

			$modified_defaults = array_merge (

						$defaults,

						array (

							// Shop Page Section 
								'shop-page-layout'                 => 'with-left-sidebar',
								'shop-page-show-standard-sidebar'  => '',
								'shop-page-widgetareas'            => '',
								'shop-page-product-per-page'       => 12,
								'shop-page-product-layout'         => 4,
								'shop-page-product-style-template' => -1,
								'shop-page-enable-breadcrumb'      => 1,
								'shop-page-bottom-hook'            => '',
								'shop-page-show-sorter-on-header'  => 1,
								'shop-page-sorter-header-elements' => array(
									'filter',
									'display_mode',
									'display_mode_options',
									'result_count'
								),
								'shop-page-show-sorter-on-footer'  => 1,
								'shop-page-sorter-footer-elements' => array(
									'pagination'
								),

							// Category Archive Page Section 
								'dt-woo-category-archive-layout'                => 'with-left-sidebar',
								'dt-woo-category-archive-show-standard-sidebar' => '',
								'dt-woo-category-archive-widgetareas'           => '',
								'dt-woo-category-archive-product-per-page'      => 12,
								'dt-woo-category-archive-product-layout'        => 4,
								'dt-woo-category-product-style-template'        => -1,
								'dt-woo-category-archive-enable-breadcrumb'     => 1,

							// Tag Archive Page Section 
								'dt-woo-tag-archive-layout'                     => 'with-left-sidebar',
								'dt-woo-tag-archive-show-standard-sidebar'      => '',
								'dt-woo-tag-archive-widgetareas'                => '',
								'dt-woo-tag-archive-product-per-page'           => 12,
								'dt-woo-tag-archive-product-layout'             => 4,
								'dt-woo-tag-product-style-template'             => -1,
								'dt-woo-tag-archive-enable-breadcrumb'          => 1,

							// Product Single Page Section 
								'dt-single-product-default-template'        => 'woo-default',
								'dt-single-product-sale-countdown-timer'    => '',
								'dt-single-product-enable-size-guide'       => '',
								'dt-single-product-enable-ajax-addtocart'   => '',
								'dt-single-product-enable-breadcrumb'       => '',
								'dt-single-product-addtocart-sticky'        => '',
								'dt-single-product-show-360-viewer'         => '',
								'dt-single-product-default-show-upsell'     => 1,
								'dt-single-product-upsell-title'            => '',
								'dt-single-product-upsell-column'           => 4,
								'dt-single-product-upsell-limit'            => 4,
								'dt-single-product-upsell-style-template'   => -1,
								'dt-single-product-default-show-related'    => 1,
								'dt-single-product-related-title'           => '',
								'dt-single-product-related-column'          => 4,
								'dt-single-product-related-limit'           => 4,
								'dt-single-product-related-style-template'  => -1,
								'dt-single-product-show-sharer-facebook'    => '',
								'dt-single-product-show-sharer-delicious'   => '',
								'dt-single-product-show-sharer-digg'        => '',
								'dt-single-product-show-sharer-stumbleupon' => '',
								'dt-single-product-show-sharer-twitter'     => '',
								'dt-single-product-show-sharer-googleplus'  => '',
								'dt-single-product-show-sharer-linkedin'    => '',
								'dt-single-product-show-sharer-pinterest'    => '',

							// Others Section
								'dt-woo-quantity-plusnminus'       => '',
								'dt-woo-addtocart-custom-action'   => '',
								'dt-woo-cross-sell-column'         => 2,
								'dt-woo-cross-sell-title'          => '',
								'dt-woo-cross-sell-style-template' => -1,

							// Size Guide Section
								'dt-woo-size-guide-title-1'   => '',
								'dt-woo-size-guide-content-1' => '',
								'dt-woo-size-guide-title-2'   => '',
								'dt-woo-size-guide-content-2' => '',
								'dt-woo-size-guide-title-3'   => '',
								'dt-woo-size-guide-content-3' => '',
								'dt-woo-size-guide-title-4'   => '',
								'dt-woo-size-guide-content-4' => '',
								'dt-woo-size-guide-title-5'   => '',
								'dt-woo-size-guide-content-5' => '',

						)

					);

			return $modified_defaults;

		}

		public function dtshop_page_layout_options() {

			$layout_options = array (
				'content-full-width'  => array ( 
					'label' => esc_html__( 'Without Sidebar', 'dtshop' ), 
					'path' => dtshop_instance()->plugin_url( 'images/customizer/without-sidebar.png' ) 
				),
				'with-left-sidebar' => array ( 
					'label' => esc_html__( 'Left Sidebar', 'dtshop' ),
					'path' => dtshop_instance()->plugin_url( 'images/customizer/left-sidebar.png' )
				),
				'with-right-sidebar' => array ( 
					'label' => esc_html__( 'Right Sidebar', 'dtshop' ),
					'path' => dtshop_instance()->plugin_url( 'images/customizer/right-sidebar.png' ) 
				),
			);

			return $layout_options;

		}

		public function dtshop_product_column_options($one_column = true) {

			$column_options = array ();

			if($one_column) {

				$column_options[1] = array ( 
										'label' => esc_html__( 'One Column', 'dtshop' ), 
										'path' => dtshop_instance()->plugin_url( 'images/customizer/one-column.png' )
									);

			}

			$column_options[2] = array ( 
									'label' => esc_html__( 'One Half Column', 'dtshop' ), 
									'path' => dtshop_instance()->plugin_url( 'images/customizer/one-half-column.png' )
								);

			$column_options[3] = array ( 
									'label' => esc_html__( 'One Third Column', 'dtshop' ), 
									'path' => dtshop_instance()->plugin_url( 'images/customizer/one-third-column.png' )
								);

			$column_options[4] = array ( 
									'label' => esc_html__( 'One Fourth Column', 'dtshop' ), 
									'path' => dtshop_instance()->plugin_url( 'images/customizer/one-fourth-column.png' )
								);

			return $column_options;

		}

		public function dtshop_product_templates_list() {

			$shop_product_templates[-1] = esc_html__('Default', 'dtshop');

			$args = array (
						'post_type'   => 'dtshop_list_template',
						'post_status' => 'publish'
					);
		
			$product_template_pages = get_posts( $args );
		
			foreach($product_template_pages as $product_template_page) {
				$id = $product_template_page->ID;
				$shop_product_templates[$id] = get_the_title($id);
			}
		
			return $shop_product_templates;

		}


	}
}

if( !function_exists('dtshop_customizer_instance') ) {
	function dtshop_customizer_instance() {
		return DTShopCustomizerSettings::instance();
	}
}

dtshop_customizer_instance();