<?php
/*
 * Plugin Name:	DesignThemes Shop
 * URI: 		http://wedesignthemes.com/plugins/designthemes-shop
 * Description: A simple wordpress plugin designed to implement <strong>Shop</strong> by designthemes
 * Version: 	1.8
 * Author: 		DesignThemes
 * Text Domain: dtshop
 * Author URI:	http://themeforest.net/user/designthemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * The main class that initiates and runs the plugin.
 */
final class DTShop {

	/**
	 * Plugin Name
	 */
	private $plugin_name = null;

	/**
	 * Theme Name
	 */
	private $theme_name = null;

	/**
	 * Plugin Version
	 */
	const DTSHOP_ELEMENTOR_VERSION = '1.0';

	/**
	 * Minimum PHP Version
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Minimum Elementor version
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.6.8';

	/**
	 * Instance variable
	 */
	private static $_instance = null;

	/**
	 * Base Plugin URL
	 */
	private $plugin_url = null;

	/**
	 * Base Plugin Path
	 */
	private $plugin_path = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'i18n' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Load Textdomain
	 */
	public function i18n() {
		load_plugin_textdomain( 'dtshop', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Initialize the plugin
	 */
	public function init() {

		// Check for WooCommerce plugin
			if( !function_exists( 'is_woocommerce' ) ) {
				add_action( 'admin_notices', array( $this, 'dtshop_woo_plugin_req' ) );
				return;
			}

		// Check for required PHP version
			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', array( $this, 'dtshop_minimum_php_version' ) );
				return;
			}


		// Load WooCommerce Template Files
			add_filter( 'woocommerce_locate_template',  array( $this, 'dtshop_woocommerce_locate_template' ), 10, 3 );

		// Load WooCommerce Comments Template
			add_filter( 'comments_template',  array( $this, 'dtshop_comments_template' ), 20, 1 );

		// Load Wishlist Template File
			add_filter( 'yith_wcwl_locate_template',  array( $this, 'dtshop_yith_wcwl_locate_template' ), 10, 2 );
			add_filter( 'yith_wcwl_wishlist_page_options', array( $this, 'dtshop_yith_wcwl_wishlist_page_options' ) );



		// Enqueue CSS and JS Files
			add_action ( 'admin_enqueue_scripts', array ( $this, 'dtshop_admin_enqueue_scripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'dtshop_enqueue_scripts' ) );
			require_once $this->plugin_path( 'css/custom-colors.php' ); // Theme Custom Colors Script

		// Include WooCommerce Custom Functions
			require_once $this->plugin_path( 'includes/register-woocommerce.php' );

		// Elementor Widgets
			add_action( 'elementor/elements/categories_registered', array( $this, 'dtshop_register_category' ) );
			require_once $this->plugin_path( 'elementor/woo-functions.php' );
			require_once $this->plugin_path( 'elementor/register-widgets.php' );

		// Customizer Settings
			require_once $this->plugin_path( 'customizer/register-settings.php' );

		// Post Type & Metaboxes
			require_once $this->plugin_path( 'post-and-metabox/register-post-and-metabox.php' );

	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have WooCommerce plugin.
	 */
	public function dtshop_woo_plugin_req() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Required plugin name */
			esc_html__( '"%1$s" requires "%2$s" plugin to be installed and activated.', 'dtshop' ),
			'<strong>' . esc_html__( 'DesignThemes Shop', 'dtshop' ) . '</strong>',
			'<strong>' . esc_html__( 'WooCommerce - excelling eCommerce', 'dtshop' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required PHP version.
	 */
	public function dtshop_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'dtshop' ),
			'<strong>' . esc_html__( 'DesignThemes Shop', 'dtshop' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'dtshop' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have Elementor installed or activated.
	 */
	public function dtshop_missing_elementor_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'dtshop' ),
			'<strong>' . esc_html__( 'DesignThemes Shop', 'dtshop' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'dtshop' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required Elementor version.
	 */
	public function dtshop_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'dtshop' ),
			'<strong>' . esc_html__( 'DesignThemes Shop', 'dtshop' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'dtshop' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Override WooCommerce default template files
	 */
	public function dtshop_woocommerce_locate_template( $template, $template_name, $template_path ) {

		global $woocommerce;

		$_template = $template;

		if ( ! $template_path ) $template_path = $woocommerce->template_url;

		$plugin_path  = $this->plugin_path() . '/templates/';

		// Look within passed path within the theme - this is priority
		$template = locate_template(

		  array(
			$template_path . $template_name,
			$template_name
		  )
		);

		// Modification: Get the template from this plugin, if it exists
		if ( ! $template && file_exists( $plugin_path . $template_name ) )
		  $template = $plugin_path . $template_name;

		// Use default template
		if ( ! $template )
		  $template = $_template;

		// Return what we found
		return $template;

	}

	/**
	 * Override WooCommerce comments template file
	 */
	public function dtshop_comments_template( $template ) {

		if ( get_post_type() !== 'product' ) {
			return $template;
		}

		$plugin_path  = $this->plugin_path() . '/templates/';

		if ( file_exists( $plugin_path . 'single-product-reviews.php' ) ) {
			return $plugin_path . 'single-product-reviews.php';
		}

		return $template;

	}

	/**
	 * Override Wishlist default template files
	 */
	public function dtshop_yith_wcwl_locate_template( $template_path, $template_name ) {

		$plugin_path = $this->plugin_path() . '/templates/'.$template_name;

		if( file_exists( $plugin_path ) ){
            return $plugin_path;
        }

		return $template_path;

	}

	/**
	 * Override Wishlist settings
	 */
	public function dtshop_yith_wcwl_wishlist_page_options( $settings ) {

		$wishlist_page = $settings['wishlist_page'];

		unset( $wishlist_page['style_section_start'] );

			unset( $wishlist_page['use_buttons'] );
			unset( $wishlist_page['add_to_cart_colors'] );
			unset( $wishlist_page['rounded_buttons_radius'] );
			unset( $wishlist_page['add_to_cart_icon'] );
			unset( $wishlist_page['add_to_cart_custom_icon'] );
			unset( $wishlist_page['style_1_button_colors'] );
			unset( $wishlist_page['style_2_button_colors'] );
			unset( $wishlist_page['wishlist_table_style'] );
			unset( $wishlist_page['headings_style'] );
			unset( $wishlist_page['share_colors'] );

			unset( $wishlist_page['fb_button_icon'] );
			unset( $wishlist_page['fb_button_custom_icon'] );
			unset( $wishlist_page['fb_button_colors'] );

			unset( $wishlist_page['tw_button_icon'] );
			unset( $wishlist_page['tw_button_custom_icon'] );
			unset( $wishlist_page['tw_button_colors'] );

			unset( $wishlist_page['pr_button_icon'] );
			unset( $wishlist_page['pr_button_custom_icon'] );
			unset( $wishlist_page['pr_button_colors'] );

			unset( $wishlist_page['em_button_icon'] );
			unset( $wishlist_page['em_button_custom_icon'] );
			unset( $wishlist_page['em_button_colors'] );

			unset( $wishlist_page['wa_button_icon'] );
			unset( $wishlist_page['wa_button_custom_icon'] );
			unset( $wishlist_page['wa_button_colors'] );
		unset( $wishlist_page['style_section_end'] );


		$settings = array( 'wishlist_page' => $wishlist_page );

		return $settings;
	}

	/**
	 * Returns path to file or dir inside plugin folder
	 */
	public function plugin_path( $path = null ) {

		if ( ! $this->plugin_path ) {
			$this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
		}

		return $this->plugin_path . $path;
	}

	/**
	 * Returns url to file or dir inside plugin folder
	 */
	public function plugin_url( $path = null ) {

		if ( ! $this->plugin_url ) {
			$this->plugin_url = trailingslashit( plugin_dir_url( __FILE__ ) );
		}

		return $this->plugin_url . $path;
	}

	/**
	 * Returns plugin name
	 */
	public function plugin_name() {

		if( ! function_exists('get_plugin_data') ){
        	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    	}

		$plugin_data = get_plugin_data( __FILE__ );
		$this->plugin_name = $plugin_data['Name'];

		return $this->plugin_name;

	}

	/**
	 * Enqueue styles for shop widget
	 */
	public function dtshop_enqueue_scripts() {

		// CSS files

			wp_enqueue_style( 'dtshop-woo', $this->plugin_url() . 'css/woocommerce.css', array (), false, 'all' );
			wp_enqueue_style( 'dtshop-woo-default', $this->plugin_url() . 'css/woocommerce-default.css', array (), false, 'all' );
			wp_enqueue_style( 'dtshop-woo-hovers', $this->plugin_url() . 'css/woocommerce-hovers.css', array (), false, 'all' );
			wp_enqueue_style( 'dtshop-woo-custom', $this->plugin_url() . 'css/woocommerce-custom.css', array (), false, 'all' );

		// JS files

			wp_enqueue_script('dtshop-toogle-click', $this->plugin_url() . 'js/jquery.toggle.click.js', array ('jquery'), false, true);
			wp_enqueue_script('dtshop-woo', $this->plugin_url() . 'js/woocommerce.js', array (), false, true);

			$enable_ajax_addtocart = dtshop_get_option( 'dt-single-product-enable-ajax-addtocart' );
			$enable_ajax_addtocart = (isset($enable_ajax_addtocart) && $enable_ajax_addtocart == 'true') ? true : false;

			wp_localize_script('dtshop-woo', 'dtshopObjects', array (
				'ajaxurl' => esc_url( admin_url('admin-ajax.php') ),
				'enable_ajax_addtocart' => esc_js($enable_ajax_addtocart)
			));

	}

	/**
	 * Admin enqueue scripts
	 */
	public function dtshop_admin_enqueue_scripts() {

		wp_enqueue_script('dtshop-admin-woo', $this->plugin_url() . 'js/admin.js', array ('jquery'), false, true);

	}

	/**
	 * Register category
	 * Add plugin category in elementor
	 */
	public function dtshop_register_category( $elements_manager ) {

		$elements_manager->add_category(
			'dtshop-widgets',array(
				'title' => $this->plugin_name(),
				'icon'  => 'font'
			)
		);

	}

}

if( !function_exists('dtshop_instance') ) {
	function dtshop_instance() {
		return DTShop::instance();
	}
}

dtshop_instance();