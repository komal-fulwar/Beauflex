<?php
// -----------------------------------------
// Product Template - Metabox Options
// -----------------------------------------

function dtshop_product_template_metabox() {

  $options[] = array (
    'id'	                     => '_dt_shop_product_template_settings',
    'title'	                   => esc_html__('Product Template Settings', 'dtshop'),
    'post_type'                => 'dtshop_list_template',
    'priority'                 => 'high',
    'context'                  => 'normal', 
    'sections'                 => array (
    
      # Default Options
        array (
          'name'                 => 'default_options_section',
          'title'                => esc_html__('Default', 'dtshop'),
          'icon'                 => 'fa fa-angle-double-right',
          'fields'               => array (
          
            array (
              'id'         => 'product-style',
              'type'       => 'select',
              'title'      => esc_html__('Product Style', 'dtshop'),
              'options'    => array (
                        'product-style-default'              => esc_html__('Default', 'dtshop'),
                        'product-style-cornered'             => esc_html__('Cornered', 'dtshop'),
                        'product-style-title-eg-highlighter' => esc_html__('Title & Element Group Highlighter', 'dtshop'),
                        'product-style-content-highlighter'  => esc_html__('Content Highlighter', 'dtshop'),
                        'product-style-egrp-overlap-pc'      => esc_html__('Element Group Overlap Product Content', 'dtshop'),
                        'product-style-egrp-reveal-pc'       => esc_html__('Element Group Reveal Product Content', 'dtshop'),
                        'product-style-igrp-over-pc'         => esc_html__('Icon Group over Product Content', 'dtshop'),
                        'product-style-egrp-over-pc'         => esc_html__('Element Group over Product Content', 'dtshop')
                      ),
              'default'    => 'product-style-default'
            )	

          )
        ),
      # Default Options


      # Hover Options
        array (
          'name'                 => 'hover_options_section',
          'title'                => esc_html__('Hover Options', 'dtshop'),
          'icon'                 => 'fa fa-angle-double-right',
          'fields'               => array (
          
            array(
              'id'         => 'product-hover-styles',
              'type'       => 'select',
              'title'      => esc_html__('Hover Styles', 'dtshop'),
              'options'    => array(
                        ''                                        => esc_html__('None', 'dtshop'),
                        'product-hover-fade-border'               => esc_html__('Fade - Border', 'dtshop'),
                        'product-hover-fade-skinborder'           => esc_html__('Fade - Skin Border', 'dtshop'),
                        'product-hover-fade-gradientborder'       => esc_html__('Fade - Gradient Border', 'dtshop'),
                        'product-hover-fade-shadow'               => esc_html__('Fade - Shadow', 'dtshop'),
                        'product-hover-fade-inshadow'             => esc_html__('Fade - InShadow', 'dtshop'),
                        'product-hover-thumb-fade-border'         => esc_html__('Fade Thumb Border', 'dtshop'),
                        'product-hover-thumb-fade-skinborder'     => esc_html__('Fade Thumb SkinBorder', 'dtshop'),
                        'product-hover-thumb-fade-gradientborder' => esc_html__('Fade Thumb Gradient Border', 'dtshop'),
                        'product-hover-thumb-fade-shadow'         => esc_html__('Fade Thumb Shadow', 'dtshop'),
                        'product-hover-thumb-fade-inshadow'       => esc_html__('Fade Thumb InShadow', 'dtshop')
                      ),
              'default'    => 'product-hover-fade-border'
            ),

            array(
              'id'         => 'product-overlay-bgcolor',
              'type'       => 'color_picker',
              'title'      => esc_html__('Overlay Background Color', 'dtshop')
            ),

            array(
              'id'         => 'product-overlay-dark-bgcolor',
              'type'       => 'switcher',
              'title'      => esc_html__('Overlay Dark Background', 'dtshop'),
            ),

            array(
              'id'         => 'product-overlay-effects',
              'type'       => 'select',
              'title'      => esc_html__('Overlay Effects', 'dtshop'),
              'options'    => array(
                        ''                                    => esc_html__('None', 'dtshop'),
                        'product-overlay-fixed'               => esc_html__('Fixed', 'dtshop'),
                        'product-overlay-toptobottom'         => esc_html__('Top to Bottom', 'dtshop'),
                        'product-overlay-bottomtotop'         => esc_html__('Bottom to Top', 'dtshop'),
                        'product-overlay-righttoleft'         => esc_html__('Right to Left', 'dtshop'),
                        'product-overlay-lefttoright'         => esc_html__('Left to Right', 'dtshop'),
                        'product-overlay-middle'              => esc_html__('Middle', 'dtshop'),
                        'product-overlay-middleradial'        => esc_html__('Middle Radial', 'dtshop'),
                        'product-overlay-gradienttoptobottom' => esc_html__('Gradient - Top to Bottom', 'dtshop'),
                        'product-overlay-gradientbottomtotop' => esc_html__('Gradient - Bottom to Top', 'dtshop'),
                        'product-overlay-gradientrighttoleft' => esc_html__('Gradient - Right to Left', 'dtshop'),
                        'product-overlay-gradientlefttoright' => esc_html__('Gradient - Left to Right', 'dtshop'),
                        'product-overlay-gradientradial'      => esc_html__('Gradient - Radial', 'dtshop'),
                        'product-overlay-flash'               => esc_html__('Flash', 'dtshop'),
                        'product-overlay-scale'               => esc_html__('Scale', 'dtshop'),
                        'product-overlay-horizontalelastic'   => esc_html__('Horizontal - Elastic', 'dtshop'),
                        'product-overlay-verticalelastic'     => esc_html__('Vertical - Elastic', 'dtshop')
                      ),
              'default'    => ''
            ),

            array(
              'id'         => 'product-hover-image-effects',
              'type'       => 'select',
              'title'      => esc_html__('Hover Image Effects', 'dtshop'),
              'options'    => array(
                        ''                                => esc_html__('None', 'dtshop'),
                        'product-hover-image-blur'        => esc_html__('Blur', 'dtshop'),
                        'product-hover-image-blackwhite'  => esc_html__('Black & White', 'dtshop'),
                        'product-hover-image-fadeinleft'  => esc_html__('Fade In Left', 'dtshop'),
                        'product-hover-image-fadeinright' => esc_html__('Fade In Right', 'dtshop'),
                        'product-hover-image-rotate'      => esc_html__('Rotate', 'dtshop'),
                        'product-hover-image-rotatealt'   => esc_html__('Rotate - Alt', 'dtshop'),
                        'product-hover-image-scalein'     => esc_html__('Scale In', 'dtshop'),
                        'product-hover-image-scaleout'    => esc_html__('Scale Out', 'dtshop'),
                        'product-hover-image-floatout'    => esc_html__('Float Up', 'dtshop')
                      ),
              'default'    => ''
            ),

            array(
              'id'         => 'product-hover-secondary-image-effects',
              'type'       => 'select',
              'title'      => esc_html__('Hover Secondary Image Effects', 'dtshop'),
              'options'    => array(
                        'product-hover-secimage-fade'              => esc_html__('Fade', 'dtshop'),
                        'product-hover-secimage-zoomin'            => esc_html__('Zoom In', 'dtshop'),
                        'product-hover-secimage-zoomout'           => esc_html__('Zoom Out', 'dtshop'),
                        'product-hover-secimage-zoomoutup'         => esc_html__('Zoom Out Up', 'dtshop'),
                        'product-hover-secimage-zoomoutdown'       => esc_html__('Zoom Out Down', 'dtshop'),
                        'product-hover-secimage-zoomoutleft'       => esc_html__('Zoom Out Left', 'dtshop'),
                        'product-hover-secimage-zoomoutright'      => esc_html__('Zoom Out Right', 'dtshop'),
                        'product-hover-secimage-pushup'            => esc_html__('Push Up', 'dtshop'),
                        'product-hover-secimage-pushdown'          => esc_html__('Push Down', 'dtshop'),
                        'product-hover-secimage-pushleft'          => esc_html__('Push Left', 'dtshop'),
                        'product-hover-secimage-pushright'         => esc_html__('Push Right', 'dtshop'),
                        'product-hover-secimage-slideup'           => esc_html__('Slide Up', 'dtshop'),
                        'product-hover-secimage-slidedown'         => esc_html__('Slide Down', 'dtshop'),
                        'product-hover-secimage-slideleft'         => esc_html__('Slide Left', 'dtshop'),
                        'product-hover-secimage-slideright'        => esc_html__('Slide Right', 'dtshop'),		
                        'product-hover-secimage-hingeup'           => esc_html__('Hinge Up', 'dtshop'),
                        'product-hover-secimage-hingedown'         => esc_html__('Hinge Down', 'dtshop'),
                        'product-hover-secimage-hingeleft'         => esc_html__('Hinge Left', 'dtshop'),
                        'product-hover-secimage-hingeright'        => esc_html__('Hinge Right', 'dtshop'),		
                        'product-hover-secimage-foldup'            => esc_html__('Fold Up', 'dtshop'),
                        'product-hover-secimage-folddown'          => esc_html__('Fold Down', 'dtshop'),
                        'product-hover-secimage-foldleft'          => esc_html__('Fold Left', 'dtshop'),
                        'product-hover-secimage-foldright'         => esc_html__('Fold Right', 'dtshop'),
                        'product-hover-secimage-fliphoriz'         => esc_html__('Flip Horizontal', 'dtshop'),
                        'product-hover-secimage-flipvert'          => esc_html__('Flip Vertical', 'dtshop')
                      ),
              'default'    => 'product-hover-secimage-fade'
            ),

            array(
              'id'         => 'product-content-hover-effects',
              'type'       => 'select',
              'title'      => esc_html__('Content Hover Effects', 'dtshop'),
              'options'    => array(
                        ''                                   => esc_html__('None', 'dtshop'),
                        'product-content-hover-fade'         => esc_html__('Fade', 'dtshop'),
                        'product-content-hover-zoom'         => esc_html__('Zoom', 'dtshop'),
                        'product-content-hover-slidedefault' => esc_html__('Slide Default', 'dtshop'),
                        'product-content-hover-slideleft'    => esc_html__('Slide From Left', 'dtshop'),
                        'product-content-hover-slideright'   => esc_html__('Slide From Right', 'dtshop'),
                        'product-content-hover-slidetop'     => esc_html__('Slide From Top', 'dtshop'),
                        'product-content-hover-slidebottom'  => esc_html__('Slide From Bottom', 'dtshop')
                      ),
              'default'    => ''
            ),

            array(
              'id'         => 'product-icongroup-hover-effects',
              'type'       => 'select',
              'title'      => esc_html__('Icon Group Hover Effects', 'dtshop'),
              'options'    => array(
                        ''                               => esc_html__('None', 'dtshop'),
                        'product-icongroup-hover-flipx'  => esc_html__('Flip X', 'dtshop'),
                        'product-icongroup-hover-flipy'  => esc_html__('Flip Y', 'dtshop'),
                        'product-icongroup-hover-bounce' => esc_html__('Bounce', 'dtshop')
                      ),
              'default'    => ''
            ),

          )
        ),
      # Hover Options


      # Common Options
        array (
          'name'                 => 'common_options_section',
          'title'                => esc_html__('Common Options', 'dtshop'),
          'icon'                 => 'fa fa-angle-double-right',
          'fields'               => array (
          
            array(
              'id'         => 'product-borderorshadow',
              'type'       => 'select',
              'title'      => esc_html__('Border or Shadow', 'dtshop'),
              'options'    => array(
                        ''                              => esc_html__('None', 'dtshop'),
                        'product-borderorshadow-border' => esc_html__('Border', 'dtshop'),
                        'product-borderorshadow-shadow' => esc_html__('Shadow', 'dtshop')
                      ),
              'default'    => '',
              'desc'      => esc_html__('Choose either Border or Shadow for your product listing.', 'dtshop')
            ),										
            array(
              'id'         => 'product-border-type',
              'type'       => 'select',
              'title'      => esc_html__('Border - Type', 'dtshop'),
              'options'    => array(
                        'product-border-type-default' => esc_html__('Default', 'dtshop'),
                        'product-border-type-thumb'   => esc_html__('Thumb', 'dtshop')
                      ),
              'default'    => 'product-border-type-default',
            ),													
            array(
              'id'         => 'product-border-position',
              'type'       => 'select',
              'title'      => esc_html__('Border - Position', 'dtshop'),
              'options'    => array(
                        'product-border-position-default'      => esc_html__('Default', 'dtshop'),
                        'product-border-position-left'         => esc_html__('Left', 'dtshop'),
                        'product-border-position-right'        => esc_html__('Right', 'dtshop'),
                        'product-border-position-top'          => esc_html__('Top', 'dtshop'),
                        'product-border-position-bottom'       => esc_html__('Bottom', 'dtshop'),
                        'product-border-position-top-left'     => esc_html__('Top Left', 'dtshop'),
                        'product-border-position-top-right'    => esc_html__('Top Right', 'dtshop'),
                        'product-border-position-bottom-left'  => esc_html__('Bottom Left', 'dtshop'),
                        'product-border-position-bottom-right' => esc_html__('Bottom Right', 'dtshop')														
                      ),
              'default'    => 'product-border-position-default',
            ),	
            array(
              'id'         => 'product-shadow-type',
              'type'       => 'select',
              'title'      => esc_html__('Shadow - Type', 'dtshop'),
              'options'    => array(
                        'product-shadow-type-default' => esc_html__('Default', 'dtshop'),
                        'product-shadow-type-thumb'   => esc_html__('Thumb', 'dtshop')
                      ),
              'default'    => 'product-shadow-type-default',
            ),
            array(
              'id'         => 'product-shadow-position',
              'type'       => 'select',
              'title'      => esc_html__('Shadow - Position', 'dtshop'),
              'options'    => array(
                        'product-shadow-position-default'      => esc_html__('Default', 'dtshop'),
                        'product-shadow-position-top-left'     => esc_html__('Top Left', 'dtshop'),
                        'product-shadow-position-top-right'    => esc_html__('Top Right', 'dtshop'),
                        'product-shadow-position-bottom-left'  => esc_html__('Bottom Left', 'dtshop'),
                        'product-shadow-position-bottom-right' => esc_html__('Bottom Right', 'dtshop')
                      ),
              'default'    => 'product-shadow-position-default',
            ),

            array(
              'id'         => 'product-bordershadow-highlight',
              'type'       => 'select',
              'title'      => esc_html__('Border / Shadow - Highlight', 'dtshop'),
              'options'    => array(
                        ''                                       => esc_html__('None', 'dtshop'),
                        'product-bordershadow-highlight-default' => esc_html__('Default', 'dtshop'),
                        'product-bordershadow-highlight-onhover' => esc_html__('On Hover', 'dtshop')
                      ),
              'default'    => '',
            ),

            array(
              'id'         => 'product-background-bgcolor',
              'type'       => 'color_picker',
              'title'      => esc_html__('Background - Background Color', 'dtshop')
            ),

            array(
              'id'         => 'product-background-dark-bgcolor',
              'type'       => 'switcher',
              'title'      => esc_html__('Background - Dark Background', 'dtshop')
            ),
          
            array(
              'id'         => 'product-padding',
              'type'       => 'select',
              'title'      => esc_html__('Padding', 'dtshop'),
              'options'    => array(
                        'product-padding-default' => esc_html__('Default', 'dtshop'),
                        'product-padding-overall' => esc_html__('Product', 'dtshop'),
                        'product-padding-thumb'   => esc_html__('Thumb', 'dtshop'),
                        'product-padding-content' => esc_html__('Content', 'dtshop'),
                      ),
              'default'    => 'product-padding-default'
            ),
            array(
              'id'         => 'product-space',
              'type'       => 'select',
              'title'      => esc_html__('Space', 'dtshop'),
              'options'    => array(
                        'product-without-space' => esc_html__('False', 'dtshop'),
                        'product-with-space'  => esc_html__('True', 'dtshop')
                      ),
              'default'    => 'product-with-space'
            ),
            array(
              'id'         => 'product-display-type',
              'type'       => 'select',
              'title'      => esc_html__('Display Type', 'dtshop'),
              'options'    => array(
                        'grid' => esc_html__('Grid', 'dtshop'),
                        'list'  => esc_html__('List', 'dtshop')
                      ),
              'default'    => 'grid'
            ),
            array(
              'id'         => 'product-display-type-list-options',
              'type'       => 'select',
              'title'      => esc_html__('List Options', 'dtshop'),
              'options'    => array(
                        'left-thumb'  => esc_html__('Left Thumb', 'dtshop'),
                        'right-thumb' => esc_html__('Right Thumb', 'dtshop')
                      ),
              'default'    => 'left-thumb'
            ),	
            array(
              'id'         => 'product-show-labels',
              'type'       => 'select',
              'title'      => esc_html__('Show Product Labels', 'dtshop'),
              'options'    => array(
                        'true'  => esc_html__('True', 'dtshop'),
                        'false' => esc_html__('False', 'dtshop')
                      ),
              'default'    => 'true'
            ),															
            array(
              'id'         => 'product-label-design',
              'type'       => 'select',
              'title'      => esc_html__('Product Label Design', 'dtshop'),
              'options'    => array(
                        'product-label-boxed'      => esc_html__('Boxed', 'dtshop'),
                        'product-label-circle'  => esc_html__('Circle', 'dtshop'),
                        'product-label-rounded'   => esc_html__('Rounded', 'dtshop'),
                        'product-label-angular'   => esc_html__('Angular', 'dtshop'),
                        'product-label-ribbon'   => esc_html__('Ribbon', 'dtshop'),
                      ),
              'default'    => 'product-label-boxed',
            ),

            array(
              'id'         => 'product-custom-class',
              'type'       => 'text',
              'title'      => esc_html__('Custom Class', 'dtshop')
            ),	

          )
        ),
      # Common Options


      # Thumb Options
        array (
          'name'                 => 'thumb_options_section',
          'title'                => esc_html__('Thumb Options', 'dtshop'),
          'icon'                 => 'fa fa-angle-double-right',
          'fields'               => array (

            array(
              'id'         => 'product-thumb-secondary-image-onhover',
              'type'       => 'switcher',
              'title'      => esc_html__('Show Secondary Image On Hover', 'dtshop'),
              'desc'	 => esc_html__('YES! to show secondary image on product hover. First image in the gallery will be used as secondary image.', 'dtshop')
            ),

            array(
              'id'             => 'product-thumb-content',
              'type'           => 'sorter',
              'title'          => esc_html__('Content', 'dtshop'),
              'default'        => array(
                'enabled'      => array(
                  'title'          => esc_html__('Title', 'dtshop'),
                  'category'       => esc_html__('Category', 'dtshop'),
                  'price'          => esc_html__('Price', 'dtshop'),
                  'button_element' => esc_html__('Button Element', 'dtshop'),
                  'icons_group'    => esc_html__('Icons Group', 'dtshop'),
                ),
                'disabled'     => array(
                  'excerpt'       => esc_html__('Excerpt', 'dtshop'),
                  'rating'        => esc_html__('Rating', 'dtshop'),
                  'countdown'     => esc_html__('Count Down', 'dtshop'),
                  'separator'     => esc_html__('Separator', 'dtshop'),
                  'element_group' => esc_html__('Element Group', 'dtshop'),
                  'swatches'      => esc_html__('Swatches', 'dtshop'),
                ),
              ),
              'enabled_title'  => esc_html__('Active Elements', 'dtshop'),
              'disabled_title' => esc_html__('Deatcive Elements', 'dtshop'),
            ),

            array(
              'id'         => 'product-thumb-alignment',
              'type'       => 'select',
              'title'      => esc_html__('Alignment', 'dtshop'),
              'options'    => array(
                        'product-thumb-alignment-top'          => esc_html__('Top', 'dtshop'),
                        'product-thumb-alignment-top-left'     => esc_html__('Top Left', 'dtshop'),
                        'product-thumb-alignment-top-right'    => esc_html__('Top Right', 'dtshop'),
                        'product-thumb-alignment-middle'       => esc_html__('Middle', 'dtshop'),
                        'product-thumb-alignment-bottom'       => esc_html__('Bottom', 'dtshop'),
                        'product-thumb-alignment-bottom-left'  => esc_html__('Bottom Left', 'dtshop'),
                        'product-thumb-alignment-bottom-right' => esc_html__('Bottom Right', 'dtshop')
                      ),
              'default'    => 'product-thumb-alignment-top'
            ),

            array(
              'id'         => 'product-thumb-iconsgroup-icons',
              'type'       => 'select',
              'title'      => esc_html__('Icons Group - Icons', 'dtshop'),
              'options'    => array(
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      ),
              'class'         => 'chosen',
              'attributes'    => array(
                'multiple'    => 'multiple',
              ),							
            ),

            array(
              'id'         => 'product-thumb-iconsgroup-style',
              'type'       => 'select',
              'title'      => esc_html__('Icons Group - Style', 'dtshop'),
              'options'    => array(
                        'product-thumb-iconsgroup-style-simple'  => esc_html__('Simple', 'dtshop'),
                        'product-thumb-iconsgroup-style-bgfill-square'  => esc_html__('Background Fill Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-bgfill-rounded-square' => esc_html__('Background Fill Rounded Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-bgfill-rounded'  => esc_html__('Background Fill Rounded', 'dtshop'),
                        'product-thumb-iconsgroup-style-brdrfill-square'  => esc_html__('Border Fill Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-brdrfill-rounded-square' => esc_html__('Border Fill Rounded Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-brdrfill-rounded'  => esc_html__('Border Fill Rounded', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbgfill-square'  => esc_html__('Skin Background Fill Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbgfill-rounded-square' => esc_html__('Skin Background Fill Rounded Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbgfill-rounded'  => esc_html__('Skin Background Fill Rounded', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbrdrfill-square'  => esc_html__('Skin Border Fill Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbrdrfill-rounded-square' => esc_html__('Skin Border Fill Rounded Square', 'dtshop'),
                        'product-thumb-iconsgroup-style-skinbrdrfill-rounded'  => esc_html__('Skin Border Fill Rounded', 'dtshop')																											
                      ),
              'default'    => 'product-thumb-iconsgroup-style-simple'
            ),

            array(
              'id'         => 'product-thumb-iconsgroup-position',
              'type'       => 'select',
              'title'      => esc_html__('Icons Group - Position', 'dtshop'),
              'options'    => array(

                      ''                                                                              => esc_html__('Default', 'dtshop'),

                      'product-thumb-iconsgroup-position-horizontal horizontal-position-top'          => esc_html__('Horizontal Top', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-top-left'     => esc_html__('Horizontal Top Left', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-top-right'    => esc_html__('Horizontal Top Right', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-middle'       => esc_html__('Horizontal Middle', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-bottom'       => esc_html__('Horizontal Bottom', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-bottom-left'  => esc_html__('Horizontal Bottom Left', 'dtshop'),
                      'product-thumb-iconsgroup-position-horizontal horizontal-position-bottom-right' => esc_html__('Horizontal Bottom Right', 'dtshop'),

                      'product-thumb-iconsgroup-position-vertical vertical-position-top-left'         => esc_html__('Vertical Top Left', 'dtshop'),
                      'product-thumb-iconsgroup-position-vertical vertical-position-top-right'        => esc_html__('Vertical Top Right', 'dtshop'),
                      'product-thumb-iconsgroup-position-vertical vertical-position-middle-left'      => esc_html__('Vertical Middle Left', 'dtshop'),
                      'product-thumb-iconsgroup-position-vertical vertical-position-middle-right'     => esc_html__('Vertical Middle Right', 'dtshop'),
                      'product-thumb-iconsgroup-position-vertical vertical-position-bottom-left'      => esc_html__('Vertical Bottom Left', 'dtshop'),
                      'product-thumb-iconsgroup-position-vertical vertical-position-bottom-right'     => esc_html__('Vertical Bottom Right', 'dtshop')

                    ),
              'default'    => ''
            ),

            array(
              'id'         => 'product-thumb-buttonelement-button',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Button', 'dtshop'),
              'options'    => array(
                        ''          => esc_html__('None', 'dtshop'),
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      )
            ),	

            array(
              'id'         => 'product-thumb-buttonelement-secondary-button',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Secondary Button', 'dtshop'),
              'options'    => array(
                        ''          => esc_html__('None', 'dtshop'),
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      )
            ),

            array(
              'id'         => 'product-thumb-buttonelement-style',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Style', 'dtshop'),
              'options'    => array(
                        'product-thumb-buttonelement-style-simple'  => esc_html__('Simple', 'dtshop'),
                        'product-thumb-buttonelement-style-bgfill-square'  => esc_html__('Background Fill Square', 'dtshop'),
                        'product-thumb-buttonelement-style-bgfill-rounded-square' => esc_html__('Background Fill Rounded Square', 'dtshop'),
                        'product-thumb-buttonelement-style-bgfill-rounded'  => esc_html__('Background Fill Rounded', 'dtshop'),
                        'product-thumb-buttonelement-style-brdrfill-square'  => esc_html__('Border Fill Square', 'dtshop'),
                        'product-thumb-buttonelement-style-brdrfill-rounded-square' => esc_html__('Border Fill Rounded Square', 'dtshop'),
                        'product-thumb-buttonelement-style-brdrfill-rounded'  => esc_html__('Border Fill Rounded', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbgfill-square'  => esc_html__('Skin Background Fill Square', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbgfill-rounded-square' => esc_html__('Skin Background Fill Rounded Square', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbgfill-rounded'  => esc_html__('Skin Background Fill Rounded', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbrdrfill-square'  => esc_html__('Skin Border Fill Square', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbrdrfill-rounded-square' => esc_html__('Skin Border Fill Rounded Square', 'dtshop'),
                        'product-thumb-buttonelement-style-skinbrdrfill-rounded'  => esc_html__('Skin Border Fill Rounded', 'dtshop')																
                      ),
              'default'    => 'product-thumb-buttonelement-style-simple'
            ),

            array(
              'id'         => 'product-thumb-buttonelement-stretch',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Stretch', 'dtshop'),
              'options'    => array(
                        ''                                    => esc_html__('False', 'dtshop'),
                        'product-thumb-buttonelement-stretch' => esc_html__('True', 'dtshop')
                      )
            ),

            array(
              'id'             => 'product-thumb-element-group',
              'type'           => 'sorter',
              'title'          => esc_html__('Element Group Content', 'dtshop'),
              'default'        => array(
                'enabled'      => array(
                  'title' => esc_html__('Title', 'dtshop'),
                  'price' => esc_html__('Price', 'dtshop')
                ),
                'disabled'     => array(
                  'cart'           => esc_html__('Cart', 'dtshop'),
                  'wishlist'       => esc_html__('Wishlist', 'dtshop'),
                  'compare'        => esc_html__('Compare', 'dtshop'),
                  'quickview'      => esc_html__('Quick View', 'dtshop'),
                  'category'       => esc_html__('Category', 'dtshop'),
                  'button_element' => esc_html__('Button Element', 'dtshop'),
                  'icons_group'    => esc_html__('Icons Group', 'dtshop'),
                  'excerpt'        => esc_html__('Excerpt', 'dtshop'),
                  'rating'         => esc_html__('Rating', 'dtshop'),
                  'separator'      => esc_html__('Separator', 'dtshop'),
                  'swatches'       => esc_html__('Swatches', 'dtshop')
                ),
              ),
              'enabled_title'  => esc_html__('Active Elements', 'dtshop'),
              'disabled_title' => esc_html__('Deatcive Elements', 'dtshop'),
            ),


          )
        ),
      # Thumb Options

      
      # Content Options
        array (
          'name'                 => 'content_options_section',
          'title'                => esc_html__('Content Options', 'dtshop'),
          'icon'                 => 'fa fa-angle-double-right',
          'fields'               => array (

            array(
              'id'         => 'product-content-enable',
              'type'       => 'switcher',
              'title'      => esc_html__('Enable Content Section', 'dtshop'),
              'desc'	 => esc_html__('YES! to enable content section.', 'dtshop')
            ),

            array(
              'id'             => 'product-content-content',
              'type'           => 'sorter',
              'title'          => esc_html__('Content', 'dtshop'),
              'default'        => array(
                'enabled'      => array(
                  'title'          => esc_html__('Title', 'dtshop'),
                  'category'       => esc_html__('Category', 'dtshop'),
                  'price'          => esc_html__('Price', 'dtshop'),
                  'button_element' => esc_html__('Button Element', 'dtshop'),
                  'icons_group'    => esc_html__('Icons Group', 'dtshop'),
                ),
                'disabled'     => array(
                  'excerpt'       => esc_html__('Excerpt', 'dtshop'),
                  'rating'        => esc_html__('Rating', 'dtshop'),
                  'countdown'     => esc_html__('Count Down', 'dtshop'),
                  'separator'     => esc_html__('Separator', 'dtshop'),
                  'element_group' => esc_html__('Element Group', 'dtshop'),
                  'swatches'      => esc_html__('Swatches', 'dtshop'),
                ),
              ),
              'enabled_title'  => esc_html__('Active Elements', 'dtshop'),
              'disabled_title' => esc_html__('Deatcive Elements', 'dtshop'),
            ),

            array(
              'id'         => 'product-content-alignment',
              'type'       => 'select',
              'title'      => esc_html__('Alignment', 'dtshop'),
              'options'    => array(
                        'product-content-alignment-left'   => esc_html__('Left', 'dtshop'),
                        'product-content-alignment-right'  => esc_html__('Right', 'dtshop'),
                        'product-content-alignment-center' => esc_html__('Center', 'dtshop')
                      ),
              'default'    => 'product-content-alignment-left'
            ),

            array(
              'id'         => 'product-content-iconsgroup-icons',
              'type'       => 'select',
              'title'      => esc_html__('Icons Group - Icons', 'dtshop'),
              'options'    => array(
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      ),
              'class'         => 'chosen',
              'attributes'    => array(
                'multiple'    => 'multiple',
              ),							
            ),

            array(
              'id'         => 'product-content-iconsgroup-style',
              'type'       => 'select',
              'title'      => esc_html__('Icons Group - Style', 'dtshop'),
              'options'    => array(
                        'product-content-iconsgroup-style-simple'  => esc_html__('Simple', 'dtshop'),
                        'product-content-iconsgroup-style-bgfill-square'  => esc_html__('Background Fill Square', 'dtshop'),
                        'product-content-iconsgroup-style-bgfill-rounded-square' => esc_html__('Background Fill Rounded Square', 'dtshop'),
                        'product-content-iconsgroup-style-bgfill-rounded'  => esc_html__('Background Fill Rounded', 'dtshop'),
                        'product-content-iconsgroup-style-brdrfill-square'  => esc_html__('Border Fill Square', 'dtshop'),
                        'product-content-iconsgroup-style-brdrfill-rounded-square' => esc_html__('Border Fill Rounded Square', 'dtshop'),
                        'product-content-iconsgroup-style-brdrfill-rounded'  => esc_html__('Border Fill Rounded', 'dtshop'),
                        'product-content-iconsgroup-style-skinbgfill-square'  => esc_html__('Skin Background Fill Square', 'dtshop'),
                        'product-content-iconsgroup-style-skinbgfill-rounded-square' => esc_html__('Skin Background Fill Rounded Square', 'dtshop'),
                        'product-content-iconsgroup-style-skinbgfill-rounded'  => esc_html__('Skin Background Fill Rounded', 'dtshop'),
                        'product-content-iconsgroup-style-skinbrdrfill-square'  => esc_html__('Skin Border Fill Square', 'dtshop'),
                        'product-content-iconsgroup-style-skinbrdrfill-rounded-square' => esc_html__('Skin Border Fill Rounded Square', 'dtshop'),
                        'product-content-iconsgroup-style-skinbrdrfill-rounded'  => esc_html__('Skin Border Fill Rounded', 'dtshop')																													
                      ),
              'default'    => 'product-content-iconsgroup-style-simple'
            ),

            array(
              'id'         => 'product-content-buttonelement-button',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Button', 'dtshop'),
              'options'    => array(
                        ''          => esc_html__('None', 'dtshop'),
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      )
            ),	

            array(
              'id'         => 'product-content-buttonelement-secondary-button',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Secondary Button', 'dtshop'),
              'options'    => array(
                        ''          => esc_html__('None', 'dtshop'),
                        'cart'      => esc_html__('Cart', 'dtshop'),
                        'wishlist'  => esc_html__('Wishlist', 'dtshop'),
                        'compare'   => esc_html__('Compare', 'dtshop'),
                        'quickview' => esc_html__('Quick View', 'dtshop')
                      )
            ),

            array(
              'id'         => 'product-content-buttonelement-style',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Style', 'dtshop'),
              'options'    => array(
                        'product-content-buttonelement-style-simple'  => esc_html__('Simple', 'dtshop'),
                        'product-content-buttonelement-style-bgfill-square'  => esc_html__('Background Fill Square', 'dtshop'),
                        'product-content-buttonelement-style-bgfill-rounded-square' => esc_html__('Background Fill Rounded Square', 'dtshop'),
                        'product-content-buttonelement-style-bgfill-rounded'  => esc_html__('Background Fill Rounded', 'dtshop'),
                        'product-content-buttonelement-style-brdrfill-square'  => esc_html__('Border Fill Square', 'dtshop'),
                        'product-content-buttonelement-style-brdrfill-rounded-square' => esc_html__('Border Fill Rounded Square', 'dtshop'),
                        'product-content-buttonelement-style-brdrfill-rounded'  => esc_html__('Border Fill Rounded', 'dtshop'),
                        'product-content-buttonelement-style-skinbgfill-square'  => esc_html__('Skin Background Fill Square', 'dtshop'),
                        'product-content-buttonelement-style-skinbgfill-rounded-square' => esc_html__('Skin Background Fill Rounded Square', 'dtshop'),
                        'product-content-buttonelement-style-skinbgfill-rounded'  => esc_html__('Skin Background Fill Rounded', 'dtshop'),
                        'product-content-buttonelement-style-skinbrdrfill-square'  => esc_html__('Skin Border Fill Square', 'dtshop'),
                        'product-content-buttonelement-style-skinbrdrfill-rounded-square' => esc_html__('Skin Border Fill Rounded Square', 'dtshop'),
                        'product-content-buttonelement-style-skinbrdrfill-rounded'  => esc_html__('Skin Border Fill Rounded', 'dtshop')																													
                      ),
              'default'    => 'product-content-buttonelement-style-simple'
            ),

            array(
              'id'         => 'product-content-buttonelement-stretch',
              'type'       => 'select',
              'title'      => esc_html__('Button Element - Stretch', 'dtshop'),
              'options'    => array(
                        ''                                    => esc_html__('False', 'dtshop'),
                        'product-content-buttonelement-stretch' => esc_html__('True', 'dtshop')
                      )
            ),

            array(
              'id'             => 'product-content-element-group',
              'type'           => 'sorter',
              'title'          => esc_html__('Element Group Content', 'dtshop'),
              'default'        => array(
                'enabled'      => array(
                  'title'          => esc_html__('Title', 'dtshop'),
                  'price'          => esc_html__('Price', 'dtshop')
                ),
                'disabled'     => array(
                  'cart'           => esc_html__('Cart', 'dtshop'),
                  'wishlist'       => esc_html__('Wishlist', 'dtshop'),
                  'compare'        => esc_html__('Compare', 'dtshop'),
                  'quickview'      => esc_html__('Quick View', 'dtshop'),
                  'category'       => esc_html__('Category', 'dtshop'),
                  'button_element' => esc_html__('Button Element', 'dtshop'),
                  'icons_group'    => esc_html__('Icons Group', 'dtshop'),
                  'excerpt'        => esc_html__('Excerpt', 'dtshop'),
                  'rating'         => esc_html__('Rating', 'dtshop'),
                  'separator'      => esc_html__('Separator', 'dtshop'),
                  'swatches'       => esc_html__('Swatches', 'dtshop')
                ),
              ),
              'enabled_title'  => esc_html__('Active Elements', 'dtshop'),
              'disabled_title' => esc_html__('Deactive Elements', 'dtshop')
            ),


          )
        ),
      # Content Options

    )
  );

  return $options;

}