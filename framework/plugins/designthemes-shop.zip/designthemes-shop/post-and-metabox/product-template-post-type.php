<?php
if( !class_exists('DTShopProductTemplate') ) {

	class DTShopProductTemplate {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action ( 'init', array( $this, 'dtshop_register_producttemplate' ) );

		}

		function dtshop_register_producttemplate() {

			$labels = array (
				'name'				 => esc_html__( 'Product Templates', 'dtshop' ),
				'singular_name'		 => esc_html__( 'Product Template', 'dtshop' ),
				'menu_name'			 => esc_html__( 'Product Templates', 'dtshop' ),
				'add_new'			 => esc_html__( 'Add Product Template', 'dtshop' ),
				'add_new_item'		 => esc_html__( 'Add New Product Template', 'dtshop' ),
				'edit'				 => esc_html__( 'Edit Product Template', 'dtshop' ),
				'edit_item'			 => esc_html__( 'Edit Product Template', 'dtshop' ),
				'new_item'			 => esc_html__( 'New Product Template', 'dtshop' ),
				'view'				 => esc_html__( 'View Product Template', 'dtshop' ),
				'view_item' 		 => esc_html__( 'View Product Template', 'dtshop' ),
				'search_items' 		 => esc_html__( 'Search Product Templates', 'dtshop' ),
				'not_found' 		 => esc_html__( 'No Product Templates found', 'dtshop' ),
				'not_found_in_trash' => esc_html__( 'No Product Templates found in Trash', 'dtshop' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 26,
				'menu_icon' 			=> 'dashicons-tagcloud',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'revisions' ),
			);

			register_post_type ( 'dtshop_list_template', $args );
				
		}

	}
}

if( !function_exists('dtshop_producttemplate_instance') ) {
	function dtshop_producttemplate_instance() {
		return DTShopProductTemplate::instance();
	}
}

dtshop_producttemplate_instance();