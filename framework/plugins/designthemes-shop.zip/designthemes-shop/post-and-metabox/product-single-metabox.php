<?php
// -----------------------------------------
// Header And Footer Options Metabox
// -----------------------------------------

function dtshop_single_product_metabox() {

  $size_guides = array (
                      ''             => esc_html__('None', 'dtshop'),
                      'size-guide-1' => esc_html__('Size Guide 1', 'dtshop'), 
                      'size-guide-2' => esc_html__('Size Guide 2', 'dtshop'), 
                      'size-guide-3' => esc_html__('Size Guide 3', 'dtshop'), 
                      'size-guide-4' => esc_html__('Size Guide 4', 'dtshop'), 
                      'size-guide-5' => esc_html__('Size Guide 5', 'dtshop')
                    );

  $elementor_template_args = array (
    'numberposts' => -1,
    'post_type' => 'elementor_library',
    'fields' =>  'ids'
  );

  $elementor_templates_arr = get_posts ($elementor_template_args);

  $elementor_templates = array ( '' => esc_html__('None', 'dtshop'), 'custom-description' => esc_html__('Custom Description', 'dtshop') );
  foreach($elementor_templates_arr as $elementor_template) {
    $elementor_templates[$elementor_template] = get_the_title($elementor_template);
  }
  
  $product_meta_layout_section = array(
    'name'   => 'general_section',
    'title'  => esc_html__('General', 'dtshop'),
    'icon'   => 'fa fa-angle-double-right',
    'fields' =>  array(
        array(
            'id'         => 'page-layout',
            'type'       => 'image_select',
            'title'      => esc_html__('Page Layout', 'dtshop'),
            'options'    => array(
                'admin-option'         => DTM_URL . 'images/admin-option.png',
                'content-full-width'   => DTM_URL . 'images/without-sidebar.png',
                'with-left-sidebar'    => DTM_URL . 'images/left-sidebar.png',
                'with-right-sidebar'   => DTM_URL . 'images/right-sidebar.png',
            ),
            'default'    => 'admin-option',
            'attributes' => array( 'data-depend-id' => 'page-layout' )
        ),
        array(
            'id'         => 'show-standard-sidebar',
            'type'       => 'switcher',
            'title'      => esc_html__('Show Standard Sidebar', 'dtshop'),
            'dependency' => array( 'page-layout', 'any', 'with-left-sidebar,with-right-sidebar' )
        ),
        array(
            'id'         => 'product-widgetareas',
            'type'       => 'select',
            'title'      => esc_html__('Choose Custom Widget Area', 'dtshop'),
            'class'      => 'chosen',
            'options'    => iva_customizer_custom_widgets(),
            'dependency' => array( 'page-layout', 'any', 'with-left-sidebar,with-right-sidebar' ),
            'attributes' => array(
                'multiple'         => 'multiple',
                'data-placeholder' => esc_attr__('Select Widget Areas', 'dtshop'),
                'style'            => 'width: 400px;'
            ),
        ),

        # Product Template
        array(
            'id'      => 'product-template',
            'type'    => 'select',
            'title'   => esc_html__('Product Template', 'dtshop'),
            'class'   => 'chosen',
            'options' => array(
                'admin-option'    => esc_html__( 'Admin Option', 'dtshop' ),
                'woo-default'     => esc_html__( 'WooCommerce Default', 'dtshop' ),
                'custom-template' => esc_html__( 'Custom Template', 'dtshop' )
            ),
            'default'    => 'admin-option',
            'info'       => esc_html__('Don\'t use product shortcodes in content area when "WooCommerce Default" template is chosen.', 'dtshop')
        ),
               
        array(
            'id'         => 'show-upsell',
            'type'       => 'select',
            'title'      => esc_html__('Show Upsell Products', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 'admin-option',
            'attributes' => array( 'data-depend-id' => 'show-upsell' ),
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                'true'         => esc_html__( 'Show', 'dtshop'),
                null           => esc_html__( 'Hide', 'dtshop'),
            ),
            'dependency' => array( 'product-template', '!=', 'custom-template')
        ),
        array(
            'id'         => 'upsell-column',
            'type'       => 'select',
            'title'      => esc_html__('Choose Upsell Column', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 4,
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                1              => esc_html__( 'One Column', 'dtshop' ),
                2              => esc_html__( 'Two Columns', 'dtshop' ),
                3              => esc_html__( 'Three Columns', 'dtshop' ),
                4              => esc_html__( 'Four Columns', 'dtshop' ),
            ),
            'dependency' => array( 'product-template|show-upsell', '!=|==', 'custom-template|true')
        ),
        array(
            'id'         => 'upsell-limit',
            'type'       => 'select',
            'title'      => esc_html__('Choose Upsell Limit', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 4,
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                1              => esc_html__( 'One', 'dtshop' ),
                2              => esc_html__( 'Two', 'dtshop' ),
                3              => esc_html__( 'Three', 'dtshop' ),
                4              => esc_html__( 'Four', 'dtshop' ),
                5              => esc_html__( 'Five', 'dtshop' ),
                6              => esc_html__( 'Six', 'dtshop' ),
                7              => esc_html__( 'Seven', 'dtshop' ),
                8              => esc_html__( 'Eight', 'dtshop' ),
                9              => esc_html__( 'Nine', 'dtshop' ),
                10              => esc_html__( 'Ten', 'dtshop' ),                                                
            ),
            'dependency' => array( 'product-template|show-upsell', '!=|==', 'custom-template|true')
        ),        
        array(
            'id'         => 'show-related',
            'type'       => 'select',
            'title'      => esc_html__('Show Related Products', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 'admin-option',
            'attributes' => array( 'data-depend-id' => 'show-related' ),
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                'true'         => esc_html__( 'Show', 'dtshop'),
                null           => esc_html__( 'Hide', 'dtshop'),
            ),
            'dependency' => array( 'product-template', '!=', 'custom-template')
        ),
        array(
            'id'         => 'related-column',
            'type'       => 'select',
            'title'      => esc_html__('Choose Related Column', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 4,
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                2              => esc_html__( 'Two Columns', 'dtshop' ),
                3              => esc_html__( 'Three Columns', 'dtshop' ),
                4              => esc_html__( 'Four Columns', 'dtshop' ),
            ),
            'dependency' => array( 'product-template|show-related', '!=|==', 'custom-template|true')
        ),
        array(
            'id'         => 'related-limit',
            'type'       => 'select',
            'title'      => esc_html__('Choose Related Limit', 'dtshop'),
            'class'      => 'chosen',
            'default'    => 4,
            'options'    => array(
                'admin-option' => esc_html__( 'Admin Option', 'dtshop' ),
                1              => esc_html__( 'One', 'dtshop' ),
                2              => esc_html__( 'Two', 'dtshop' ),
                3              => esc_html__( 'Three', 'dtshop' ),
                4              => esc_html__( 'Four', 'dtshop' ),
                5              => esc_html__( 'Five', 'dtshop' ),
                6              => esc_html__( 'Six', 'dtshop' ),
                7              => esc_html__( 'Seven', 'dtshop' ),
                8              => esc_html__( 'Eight', 'dtshop' ),
                9              => esc_html__( 'Nine', 'dtshop' ),
                10              => esc_html__( 'Ten', 'dtshop' ),                                                
            ),
            'dependency' => array( 'product-template|show-related', '!=|==', 'custom-template|true')
        ),

        # Product Additional Tabs
        array(
          'id'              => 'product-additional-tabs',
          'type'            => 'group',
          'title'           => esc_html__('Additional Tabs', 'dtshop'),
          'info'            => esc_html__('Click button to add title and description.', 'dtshop'),
          'button_title'    => esc_html__('Add New Tab', 'dtshop'),
          'accordion_title' => esc_html__('Adding New Tab Field', 'dtshop'),
          'fields'          => array(
            array(
            'id'          => 'tab_title',
            'type'        => 'text',
            'title'       => esc_html__('Title', 'dtshop'),
            ),

            array(
              'id'         => 'tab_description',
              'type'       => 'select',
              'title'      => esc_html__('Description', 'dtshop'),
              'options'    => $elementor_templates,
              'info'       => esc_html__('Choose "Elementor Templates" here to use for "Description", if you choose "Custom Description" option you can provide your own content below.', 'dtshop'),
              'attributes' => array( 'data-depend-id' => 'tab_description' )
            ),

            array(
              'id'         => 'tab_custom_description',
              'type'       => 'textarea',
              'title'      => esc_html__('Custom Description', 'dtshop'),
              'dependency' => array( 'tab_description', '==', 'custom-description' )
            ),

          )
        ),

        # Product New Label
         array(
            'id'         => 'product-new-label',
            'type'       => 'switcher',
            'title'      => esc_html__('Add "New" label', 'dtshop'),
        ), 

        array(
          'id'         => 'dt-single-product-size-guides',
          'type'       => 'select',
          'title'      => esc_html__('Product Size Guides', 'dtshop'),
          'options'    => $size_guides,
        ),              

        array(
          'id'         => 'description',
          'type'       => 'select',
          'title'      => esc_html__('Description', 'dtshop'),
          'options'    => $elementor_templates,
          'info'       => esc_html__('Choose "Elementor Templates" here to use for "Description", if you choose "Custom Description" option you can provide your own content below. This content will be used when "Custom Template" is chosen in "Product Template" option.', 'dtshop'),
          'attributes' => array( 'data-depend-id' => 'description' )
        ),

        array(
          'id'         => 'custom-description',
          'type'       => 'textarea',
          'title'      => esc_html__('Custom Description', 'dtshop'),
          'dependency' => array( 'description', '==', 'custom-description' )
        ),

    )
  );

  $options[] = array(
    'id'        => '_custom_settings',
    'title'     => esc_html__('Product Settings','dtshop'),
    'post_type' => 'product',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
      $product_meta_layout_section
    )
  );

  $options[] = array(
    'id'        => '_360viewer_gallery',
    'title'     => esc_html__('Product 360 View Gallery','dtshop'),
    'post_type' => 'product',
    'context'   => 'side',
    'priority'  => 'low',
    'sections'  => array(
                    array(
                    'name'   => '360view_section',
                    'fields' =>  array(
                                    array (
                                      'id'          => 'product-360view-gallery',
                                      'type'        => 'gallery',
                                      'title'       => esc_html__('Gallery Images', 'dtshop'),
                                      'desc'        => esc_html__('Simply add images to gallery items.', 'dtshop'),
                                      'add_title'   => esc_html__('Add Images', 'dtshop'),
                                      'edit_title'  => esc_html__('Edit Images', 'dtshop'),
                                      'clear_title' => esc_html__('Remove Images', 'dtshop'),
                                    )
                                )
                    )
                  )
    );

  return $options;

}