<?php
if( !class_exists('DTShopPostAndMetabox') ) {

	class DTShopPostAndMetabox {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			// Product Template Post Type
			require_once dtshop_instance()->plugin_path( 'post-and-metabox/product-template-post-type.php' );

			// Metabox Options
			require_once dtshop_instance()->plugin_path( 'post-and-metabox/product-template-metabox.php' );
			require_once dtshop_instance()->plugin_path( 'post-and-metabox/product-single-metabox.php' );

			add_filter ( 'dtm_metabox_options', array( $this, 'dtshop_producttemplate_metabox_options' ) );

		}

		function dtshop_producttemplate_metabox_options( $options ) {

			// Product Template Metabox
			$product_template_options = dtshop_product_template_metabox();
			$options = array_merge($product_template_options, $options);

			// Single Product Metabox
			$single_product_options = dtshop_single_product_metabox();
			$options = array_merge($single_product_options, $options);

			return $options;

		}

	}
}

if( !function_exists('dtshop_postnmetabox_instance') ) {
	function dtshop_postnmetabox_instance() {
		return DTShopPostAndMetabox::instance();
	}
}

dtshop_postnmetabox_instance();