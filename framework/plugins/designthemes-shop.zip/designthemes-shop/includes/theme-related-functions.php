<?php

/**
 * Functions related with theme name
 */


// Theme Options

if ( ! function_exists( 'dtshop_get_option' ) ) {

	function dtshop_get_option( $option_key, $default_value = '' ) {

		if( function_exists('iva_get_option') ) {
			return iva_get_option( $option_key, $default_value );
		}

		return;

	}

}

// Theme Breadcrumb Output

if ( ! function_exists( 'dtshop_breadcrumb_output' ) ) {

	function dtshop_breadcrumb_output( $title, $breadcrumbs, $class, $inline_css ) {

		if( function_exists('iva_breadcrumb_output') ) {
			return iva_breadcrumb_output( $title, $breadcrumbs, $class, $inline_css );
		}

		return;

	}

}

// Hexadecimal to RGB color conversion

if ( ! function_exists( 'dtshop_hex2rgb' ) ) {

	function dtshop_hex2rgb( $hex ) {

		if( function_exists('iva_hex2rgb') ) {
			return iva_hex2rgb( $hex );
		}

		return;

	}

}



/**
 * Other functions
 */


// Body Class Filter

if ( ! function_exists( 'dtshop_body_classes' ) ) {

	function dtshop_body_classes( $classes ) {
		
		if( is_shop() ) {
			$shop_breadcrumb = dtshop_get_option( 'shop-page-enable-breadcrumb' );
			$shop_breadcrumb = ( isset($shop_breadcrumb ) && !empty( $shop_breadcrumb ) ) ? true : false;
			if( !$shop_breadcrumb ) {
				$classes[] = 'no-breadcrumb';
			}
		} elseif( is_singular('product') ) {
			$product_breadcrumb = dtshop_get_option( 'dt-single-product-enable-breadcrumb' );
			$product_breadcrumb = ( isset($product_breadcrumb ) && !empty( $product_breadcrumb ) ) ? true : false;
			if( !$product_breadcrumb ) {
				$classes[] = 'no-breadcrumb';
			}
		} elseif( is_product_category() ) {
			$pcategory_breadcrumb = dtshop_get_option( 'dt-woo-category-archive-enable-breadcrumb' );
			$pcategory_breadcrumb = ( isset($pcategory_breadcrumb ) && !empty( $pcategory_breadcrumb ) ) ? true : false;
			if( !$pcategory_breadcrumb ) {
				$classes[] = 'no-breadcrumb';
			}
		} elseif( is_product_tag() ) {
			$ptag_breadcrumb = dtshop_get_option( 'dt-woo-tag-archive-enable-breadcrumb' );
			$ptag_breadcrumb = ( isset($ptag_breadcrumb ) && !empty( $ptag_breadcrumb ) ) ? true : false;
			if( !$ptag_breadcrumb ) {
				$classes[] = 'no-breadcrumb';
			}
		} else {
			$show_breadcrump = dtshop_get_option('show-breadcrumb');
			if( is_null( $show_breadcrump ) ) {
				$classes[] = 'no-breadcrumb';
			}
		}

		return $classes;

	}
	add_filter( 'body_class', 'dtshop_body_classes' );

}

// Custom Footer Filter

if ( ! function_exists( 'dtshop_custom_footer_id' ) ) {

	function dtshop_custom_footer_id( $id ) {
		
		if( is_shop() ) {

            $shop_page_id = get_option('woocommerce_shop_page_id');

            $settings = get_post_meta( $shop_page_id, '_dt_custom_settings', true );
			$settings = is_array( $settings ) ? $settings  : array();

			if( array_key_exists( 'show-footer', $settings ) && !$settings['show-footer'] ) {
				return -1;
			}

            $id = isset( $settings['footer'] ) ? $settings['footer'] : '';
            $id = ( $id == '' ) ? dtshop_get_option( 'site-custom-footer' ) : $id;

		}

		return $id;

	}
	add_filter( 'iva_footer_id', 'dtshop_custom_footer_id' );

}

// Header Footer Custom Post

if ( ! function_exists( 'dtshop_header_footer_cpt' ) ) {

	function dtshop_header_footer_cpt( $custom_posts ) {
		
		$custom_posts[] = 'product';

		return $custom_posts;

	}
	add_filter( 'iva_header_footer_default_cpt', 'dtshop_header_footer_cpt' );

}

// Page Layout Options

if ( ! function_exists( 'dtshop_page_layout_options' ) ) {

	function dtshop_page_layout_options( $page_layout_options ) {
		
		$cart_page_id = get_option('woocommerce_cart_page_id');
		$checkout_page_id = get_option('woocommerce_checkout_page_id');
		$myaccount_page_id = get_option('woocommerce_myaccount_page_id');
		$wishlist_page_id = get_option( 'yith_wcwl_wishlist_page_id' );
		
		if( isset( $_GET['post'] ) && ( $_GET['post'] == $cart_page_id || $_GET['post'] == $checkout_page_id || $_GET['post'] == $myaccount_page_id || $_GET['post'] == $wishlist_page_id ) ) {	
		
		  $page_layout_options = array (
			  'global-site-layout' 	 => DTM_URL . 'images/admin-option.png',
			  'content-full-width'   => DTM_URL . 'images/without-sidebar.png',
			  'with-left-sidebar'    => DTM_URL . 'images/left-sidebar.png',
			  'with-right-sidebar'   => DTM_URL . 'images/right-sidebar.png'
		  );
		
		}

		return $page_layout_options;

	}
	add_filter( 'iva_custom_page_layout_options', 'dtshop_page_layout_options' );

}

// Disable Page Settings for Shop page

if ( ! function_exists( 'dtshop_page_settings_cpt' ) ) {

	function dtshop_page_settings_cpt( $default = true ) {
		
		$shop_page_id = get_option('woocommerce_shop_page_id');
		if( isset( $_GET['post'] ) && ( $_GET['post'] == $shop_page_id ) ) {
			return false;
		}

		return $default;

	}
	add_filter( 'iva_page_settings_cpt', 'dtshop_page_settings_cpt' );

}

// Disable both sidebar filter for shop pages

if ( ! function_exists( 'dtshop_is_shop_pages_check' ) ) {

	function dtshop_is_shop_pages_check( $default = false ) {
		
		if((is_cart() || is_checkout() || is_account_page() || (function_exists( 'yith_wcwl_is_wishlist_page' ) && yith_wcwl_is_wishlist_page()) )) {
			return true;
		}	

		return $default;

	}
	add_filter( 'iva_is_shop_pages_check', 'dtshop_is_shop_pages_check' );

}