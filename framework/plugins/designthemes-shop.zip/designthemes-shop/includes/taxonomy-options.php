<?php

//Product Cat Create page
if(!function_exists('dtshop_taxonomy_add_new_meta_field')) {
	function dtshop_taxonomy_add_new_meta_field() {
		?>
		<div class="form-field">
			<label for="dtshop_cat_color"><?php esc_html_e('Color', 'dtshop'); ?></label>
			<input type="text" name="dtshop_cat_color" id="dtshop_cat_color" class="dtshop-color-picker-alpha">
			<p class="description"><?php esc_html_e('If you wish choose specific color for your category.', 'dtshop'); ?></p>
		</div>
		<?php
	}
	add_action('product_cat_add_form_fields', 'dtshop_taxonomy_add_new_meta_field', 20, 1);
}

//Product Cat Edit page
if(!function_exists('dtshop_taxonomy_edit_meta_field')) {
	function dtshop_taxonomy_edit_meta_field($term) {

		//getting term ID
		$term_id = $term->term_id;

		// retrieve the existing value(s) for this meta field.
		$dtshop_cat_color = get_term_meta($term_id, 'dtshop_cat_color', true);
		?>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="dtshop_cat_color"><?php esc_html_e('Color', 'dtshop'); ?></label></th>
			<td>
				<input type="text" name="dtshop_cat_color" id="dtshop_cat_color" class="dtshop-color-picker-alpha" value="<?php echo esc_attr($dtshop_cat_color) ? esc_attr($dtshop_cat_color) : ''; ?>">
				<p class="description"><?php esc_html_e('If you wish choose specific color for your category.', 'dtshop'); ?></p>
			</td>
		</tr>
		<?php
	}
	add_action('product_cat_edit_form_fields', 'dtshop_taxonomy_edit_meta_field', 20, 1);
}



// Save extra taxonomy fields callback function.
if(!function_exists('dtshop_save_taxonomy_custom_meta')) {
	function dtshop_save_taxonomy_custom_meta($term_id) {

		$dtshop_cat_color = filter_input(INPUT_POST, 'dtshop_cat_color');
		update_term_meta($term_id, 'dtshop_cat_color', $dtshop_cat_color);

	}
	add_action('edited_product_cat', 'dtshop_save_taxonomy_custom_meta', 20, 1);
	add_action('create_product_cat', 'dtshop_save_taxonomy_custom_meta', 20, 1);
}