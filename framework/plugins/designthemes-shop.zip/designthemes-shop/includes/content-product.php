<?php

// Add required files

require_once $this->plugin_path( 'includes/content-product/utils.php' ); // Util functions
require_once $this->plugin_path( 'includes/content-product/sorter.php' ); // Sorter - Header & Footer
require_once $this->plugin_path( 'includes/content-product/loop-start-end.php' ); // Product Loop - Start & End
require_once $this->plugin_path( 'includes/content-product/content-utils.php' ); // Product Content Utils
require_once $this->plugin_path( 'includes/content-product/content-thumb.php' ); // Product Content Thumb
require_once $this->plugin_path( 'includes/content-product/content-content.php' ); // Product Content Content

?>