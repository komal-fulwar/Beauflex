<?php

/**
 * Functions related with theme name
 */


// Theme Options

if ( ! function_exists( 'dtportfolio_get_option' ) ) {

	function dtportfolio_get_option( $option_key, $default_value = '' ) {

		if( function_exists('iva_get_option') ) {
			return iva_get_option( $option_key, $default_value );
		}

		return;

	}

}

// Hexadecimal to RGB color conversion

if ( ! function_exists( 'dtportfolio_hex2rgb' ) ) {

	function dtportfolio_hex2rgb( $hex ) {

		if( function_exists('iva_hex2rgb') ) {
			return iva_hex2rgb( $hex );
		}

		return;

	}

}


/**
 * Other functions
 */


// Image Size

if (!function_exists('dtportfolio_features')) {

	function dtportfolio_features() {

		if ( function_exists( 'add_theme_support' ) ) {
			add_image_size( 'dtportfolio-635x1100', 635, 1100, true  );
			add_image_size( 'dtportfolio-750x650', 750, 650, true  );
			add_image_size( 'dtportfolio-450x450', 450, 450, true  );
			add_image_size( 'dtportfolio-420x420', 420, 420, true  );
		}

	}

	add_action('after_setup_theme', 'dtportfolio_features');
}


// Register widgetarea

if( !function_exists('dtportfolio_register_sidebars_array') ) {
	function dtportfolio_register_sidebars_array( $sidebars ) {

		$layout = dtportfolio_get_option( 'portfolio-archives-page-layout' );
		$layout = !empty($layout) ? $layout : 'content-full-width';

		if($layout == 'with-left-sidebar') {
			$sidebars['custom-post-portfolio-archives-sidebar-left'] = esc_html__('Portfolio Archives | Left Sidebar', 'dtportfolio');
		} else if($layout == 'with-right-sidebar') {
			$sidebars['custom-post-portfolio-archives-sidebar-right'] = esc_html__('Portfolio Archives | Right Sidebar', 'dtportfolio');
		}
		
		return $sidebars;

	}
	
	add_filter('dttheme_register_sidebars_array', 'dtportfolio_register_sidebars_array');
}



// Before, After widget Filter

function dtportfolio_before_after_widget ( $content ) {
	$allowed_html = array(
		'aside' => array(
			'id'    => array(),
			'class' => array()
		),
		'div' => array(
			'id'    => array(),
			'class' => array(),
		)
	);

	$data = wp_kses( $content, $allowed_html );

	return $data;
}

// Before, After widget Title

function dtportfolio_widget_title( $content ) {

	$allowed_html = array(
		'div' => array(
			'id'    => array(),
			'class' => array()
		),
		'h2' => array(
			'class' => array()
		),
		'h3' => array(
			'class' => array()
		),				
	);

	$data = wp_kses( $content, $allowed_html );

	return $data;
}