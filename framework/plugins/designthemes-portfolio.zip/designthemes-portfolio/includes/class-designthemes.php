<?php

if ( ! class_exists( 'DTPortfolioDesignThemes' ) ) {

	class DTPortfolioDesignThemes {
		
		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		function __construct() {

			add_filter( 'body_class', array( $this, 'dtportfolio_dt_body_class' ), 20 );
			add_filter( 'iva_header_footer_default_cpt', array( $this, 'dtportfolio_header_footer_default_cpt' ) );

			add_action( 'wp_enqueue_scripts', array( $this, 'dtportfolio_dt_enqueue_styles' ), 104 );

			add_action( 'dtportfolio_before_main_content', array( $this, 'dtportfolio_dt_before_main_content' ), 10 );
			add_action( 'dtportfolio_after_main_content', array( $this, 'dtportfolio_dt_after_main_content' ), 10 );

			add_action( 'dtportfolio_before_content', array( $this, 'dtportfolio_dt_before_content' ), 10 );
			add_action( 'dtportfolio_after_content', array( $this, 'dtportfolio_dt_after_content' ), 10 );

		}
	
		function dtportfolio_dt_body_class( $classes ) {

			global $post;

			if(is_page()) {
		
				$dtportfolio_template_settings = get_post_meta($post->ID, 'dtportfolio_template_settings', true);
				$dtportfolio_template_settings = is_array($dtportfolio_template_settings) ? $dtportfolio_template_settings : array ();
		
				$dtportfolio_transparent_header = (array_key_exists('dtportfolio-transparent-header', $dtportfolio_template_settings) && $dtportfolio_template_settings['dtportfolio-transparent-header']) ? true : false;
		
				if($dtportfolio_transparent_header) {
					$classes[] = 'dtportfolio-transparent-header';
				}
							
				$dtportfolio_remove_spaces = (array_key_exists('dtportfolio-remove-spaces', $dtportfolio_template_settings) && $dtportfolio_template_settings['dtportfolio-remove-spaces']) ? true : false;
		
				if($dtportfolio_remove_spaces) {
					$classes[] = 'dtportfolio-fixed-items-page';
				}

			}

			if (is_singular( 'dt_portfolios' )) {

				$portfolio_settings = get_post_meta($post->ID, '_portfolio_settings', true);
				$portfolio_settings = is_array($portfolio_settings) ? $portfolio_settings : array ();

				$dtportfolio_transparent_header = (array_key_exists('dtportfolio-transparent-header', $portfolio_settings) && $portfolio_settings['dtportfolio-transparent-header']) ? true : false;

				if($dtportfolio_transparent_header) {
					$classes[] = 'dtportfolio-transparent-header';
				}

				$portfolio_layout = array_key_exists('portfolio-layout', $portfolio_settings) ? $portfolio_settings['portfolio-layout'] : '';

				if($portfolio_layout == 'fixed-gallery' || $portfolio_layout == 'fixed-feature-image' || $portfolio_layout == 'gallery-list') {
					$classes[] = 'dtportfolio-fixed-items-page';
				}

				if( array_key_exists( 'breadcrumb-option', $portfolio_settings ) && $portfolio_settings['breadcrumb-option'] == 'global-option' ) {
					$show_breadcrump = dtportfolio_get_option('show-breadcrumb');
					if( empty( $show_breadcrump ) ) {
						$classes[] = 'no-breadcrumb';
					}
				} elseif ( array_key_exists( 'enable-sub-title', $portfolio_settings ) && !($portfolio_settings['enable-sub-title']) ) {
					$classes[] = 'no-breadcrumb';
				}

			}

			if(is_post_type_archive('dt_portfolios') || is_tax ( 'portfolio_entries' ) || is_tax ( 'portfolio_tags' ) ) {

				$show_breadcrump = dtportfolio_get_option( 'show-breadcrumb' );
				if( empty( $show_breadcrump ) ) {
					$classes[] = 'no-breadcrumb';
				}

			}
			
			return $classes;

		}	

		function dtportfolio_header_footer_default_cpt( $custom_posts ) {

			$custom_posts[] = 'dt_portfolios';

			return $custom_posts;

		}	

		function dtportfolio_dt_enqueue_styles() {

			wp_enqueue_style ( 'dtportfolio-designthemes', dtportfolio_instance()->plugin_url('css/designthemes.css'), array (), false, 'all' );	

		}

		function dtportfolio_dt_before_main_content() {


			if (is_singular( 'dt_portfolios' )) {	

				global $post;

				$global_breadcrumb = dtportfolio_get_option( 'show-breadcrumb' );

			    $settings = get_post_meta($post->ID,'_portfolio_settings',TRUE);
			    $settings = is_array( $settings ) ?  array_filter( $settings )  : array();

				$portfolio_layout = array_key_exists("portfolio-layout",$settings) ? $settings['portfolio-layout'] : '';
				
				if( empty($settings) || !isset($settings['breadcrumb-option']) ) { 
					$settings['breadcrumb-option'] = 'global-option';
				}

				$darkbg = '';
				if( $settings['breadcrumb-option'] == 'global-option' ) {
					$darkbg = dtportfolio_get_option( 'apply-dark-bg-breadcrumb' );
					$darkbg = $darkbg ? "dark-bg-breadcrumb" : "";
		        }else if( $settings['breadcrumb-option'] == 'individual-option' ) {
		        	if( isset( $settings['enable-dark-bg'] ) && $settings['enable-dark-bg'] ) {
		        		$darkbg = "dark-bg-breadcrumb";
		            }
		        }				

				$header_class = '';
				$breadcrumb_disabled = false;
			    if($portfolio_layout != 'media-on-top' && $portfolio_layout != 'fixed-gallery' && $portfolio_layout != 'fixed-feature-image' && $portfolio_layout != 'gallery-list') {

					if( $settings['breadcrumb-option'] == 'global-option' ) {
						$global_breadcrumb = dtportfolio_get_option( 'show-breadcrumb' );
						if( !empty( $global_breadcrumb ) ) {
							$header_class = dtportfolio_get_option( 'breadcrumb-position' );
						} else {
							$breadcrumb_disabled = true;
						}
					} else if( $settings['breadcrumb-option'] == 'individual-option' ) {
						if( isset( $settings['enable-sub-title'] ) && $settings['enable-sub-title'] ) {
							$header_class = isset( $settings['breadcrumb_position'] ) ? $settings['breadcrumb_position'] : '';
						} else {
							$breadcrumb_disabled = true;
						}
					}

				}

				?>

				<div id="header-wrapper" class="<?php echo esc_attr($header_class); ?>">

				    <header id="header">

				        <div class="container">
				        	<?php do_action( 'iva_header' ); ?>
				        </div>
				    </header>

				    <?php
					if($portfolio_layout != 'media-on-top' && $portfolio_layout != 'fixed-gallery' && $portfolio_layout != 'fixed-feature-image' && $portfolio_layout != 'gallery-list') {

						if(!$breadcrumb_disabled) {

							$breadcrumbs = array();
							$bstyle = dtportfolio_get_option( 'breadcrumb-style', 'default' );							

							$separator = '<span class="'.dtportfolio_get_option( 'breadcrumb-delimiter', 'fa default' ).'"></span>';

							$change_delimiter = dtportfolio_get_option( 'change-breadcrumb-delimiter' );
							if( !$change_delimiter ) {
								$separator = '<span class="breadcrumb-default-delimiter"></span>';
							}						

							$cat = get_the_category();
							$cat = isset($cat[0]) ? $cat[0] : '';
							$breadcrumbs[] = get_category_parents( $cat, true, $separator );
							$breadcrumbs[] = the_title( '<span class="current">', '</span>', false );

							iva_breadcrumb_output ( the_title( '<h1>', '</h1>',false ), $breadcrumbs, $bstyle .' '. $darkbg, array () );
				
						}

				    }

			    	do_action( 'dtportfolio_mediaontop_hook' );
				    ?>

				</div>

				<?php

			}

			if(is_post_type_archive('dt_portfolios') || is_tax ( 'portfolio_entries' ) || is_tax ( 'portfolio_tags' ) ) {

				$global_breadcrumb = dtportfolio_get_option( 'show-breadcrumb' );
				$header_class	   = dtportfolio_get_option( 'breadcrumb-position' );

				$darkbg = dtportfolio_get_option( 'apply-dark-bg-breadcrumb' );
				$darkbg = $darkbg ? "dark-bg-breadcrumb" : "";?>

				<div id="header-wrapper" class="<?php echo esc_attr($header_class); ?>">

					<header id="header">
						<div class="container">
							<?php do_action( 'iva_header' ); ?>
					    </div>
					</header>

				    <?php
			        if( !empty( $global_breadcrumb ) ) {

			        	$bstyle = dtportfolio_get_option( 'breadcrumb-style', 'default' );

			            $title = '<h1>'.get_the_archive_title().'</h1>';
			            $breadcrumbs = array();

			            if ( is_category() ) {
			                $breadcrumbs[] = '<a href="'. get_category_link( get_query_var('cat') ) .'">' . single_cat_title('', false) . '</a>';
			            } elseif ( is_tag() ) {
			                $breadcrumbs[] = '<a href="'. get_tag_link( get_query_var('tag_id') ) .'">' . single_tag_title('', false) . '</a>';
			            } elseif( is_author() ){
			                $breadcrumbs[] = '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'">' . get_the_author() . '</a>';
			            } elseif( is_day() || is_time() ){
			                $breadcrumbs[] = '<a href="'. get_year_link( get_the_time('Y') ) . '">'. get_the_time('Y') .'</a>';
			                $breadcrumbs[] = '<a href="'. get_month_link( get_the_time('Y'), get_the_time('m') ) .'">'. get_the_time('F') .'</a>';
			                $breadcrumbs[] = '<a href="'. get_day_link( get_the_time('Y'), get_the_time('m'), get_the_time('d') ) .'">'. get_the_time('d') .'</a>';
			            } elseif( is_month() ){
			                $breadcrumbs[] = '<a href="'. get_year_link( get_the_time('Y') ) . '">' . get_the_time('Y') . '</a>';
			                $breadcrumbs[] = '<a href="'. get_month_link( get_the_time('Y'), get_the_time('m') ) .'">'. get_the_time('F') .'</a>';
			            } elseif( is_year() ){
			                $breadcrumbs[] = '<a href="'. get_year_link( get_the_time('Y') ) .'">'. get_the_time('Y') .'</a>';
			            }

			            iva_breadcrumb_output ( $title, $breadcrumbs, $bstyle .' '. $darkbg, array () );
			        }
				    ?>

				</div>

				<?php

			}

		}

		function dtportfolio_dt_after_main_content() {
			
		}

		function dtportfolio_dt_before_content() {

			if (is_singular( 'dt_portfolios' )) {

				echo '<div id="main">';
 
				    	global $post;

					    $settings = get_post_meta($post->ID,'_portfolio_settings',TRUE);
					    $settings = is_array( $settings ) ?  array_filter( $settings )  : array();

					    $portfolio_layout = array_key_exists('portfolio-layout', $settings) ? $settings['portfolio-layout'] : '';

					    if($portfolio_layout != 'fixed-gallery' && $portfolio_layout != 'fixed-feature-image' && $portfolio_layout != 'gallery-list') {

							echo '<div class="container">';

					        $page_layout  = array_key_exists( "layout", $settings ) ? $settings['layout'] : "content-full-width";
					        $layout = iva_page_layout( $page_layout );
					        extract( $layout );

					        if ( $show_sidebar ) {
					            if ( $show_left_sidebar ) {
					                $sticky_class = ( array_key_exists('enable-sticky-sidebar', $settings) && $settings['enable-sticky-sidebar'] == 'true' ) ? ' sidebar-as-sticky' : '';
					                ?>
					                <section id="secondary-left" class="secondary-sidebar <?php echo esc_attr( $sidebar_class.$sticky_class );?>"><?php
					                    iva_show_sidebar( 'dt_portfolios', $post->ID, 'left' ); ?>
					                </section>
					                <?php
					            }
					        }

				        } else {
				        	$page_layout = 'content-full-width';
				        }
				        ?>

				        <section id="primary" class="<?php echo esc_attr( $page_layout );?>">

				        <?php	


			}

			if(is_post_type_archive('dt_portfolios') || is_tax ( 'portfolio_entries' ) || is_tax ( 'portfolio_tags' ) ) {

				echo '<div id="main">';
				    echo '<div class="container">';

					$allow_fullwidth = dtportfolio_get_option('portfolio-allow-full-width');

					if($allow_fullwidth != 'true') {

				    	$page_layout  = dtportfolio_get_option( 'portfolio-archives-page-layout' );
				    	$page_layout  = !empty( $page_layout ) ? $page_layout : "content-full-width";

				    	if($page_layout != 'fullwidth') {
							
							$theme_page_layout = 'content-full-width';
							$show_sidebar = $show_left_sidebar = $show_right_sidebar = false;
							$sidebar_enable = dtportfolio_get_option( 'portfolio-archives-page-show-standard-sidebar' );

							if($page_layout == 'with-left-sidebar') {
								if( is_active_sidebar('custom-post-portfolio-archives-sidebar-left') || (!empty( $sidebar_enable ) && is_active_sidebar('standard-sidebar-left')) ) {
									$show_sidebar = $show_left_sidebar = true;	
									$theme_page_layout = 'page-with-sidebar with-left-sidebar';
								}
							}
							if($page_layout == 'with-right-sidebar') {
								if( is_active_sidebar('custom-post-portfolio-archives-sidebar-right') || (!empty( $sidebar_enable ) && is_active_sidebar('standard-sidebar-right')) ) {
									$show_sidebar = $show_right_sidebar = true;	
									$theme_page_layout = 'page-with-sidebar with-right-sidebar';
								}
							}

					    	if ( $show_sidebar ) {
					    		if ( $show_left_sidebar ) {
					    			?>
					    			<section id="secondary-left" class="secondary-sidebar secondary-has-left-sidebar">
					    				<?php

					    				$wtstyle = dtportfolio_get_option( 'widget-title-style' );

										if(!empty($wtstyle)):
											echo "<div class='{$wtstyle}'>";
										endif;

											if( is_active_sidebar('custom-post-portfolio-archives-sidebar-left') ):
												dynamic_sidebar('custom-post-portfolio-archives-sidebar-left');
											endif;
											
											if( !empty( $sidebar_enable )):
												if( is_active_sidebar('standard-sidebar-left') ):
													dynamic_sidebar('standard-sidebar-left');
												endif;
											endif;

										if(!empty($wtstyle)):
											echo "</div>";
										endif;

					    				?>
					    			</section>
					    			<?php
					    		}
					    	}
					    	?>

					        <section id="primary" class="<?php echo esc_attr( $theme_page_layout );?>">
					        <?php

					    }

					}

			}

		}

		function dtportfolio_dt_after_content() {

			if (is_singular( 'dt_portfolios' )) {

					echo '</section>';

			    	global $post;

				    $settings = get_post_meta($post->ID,'_portfolio_settings',TRUE);
				    $settings = is_array( $settings ) ?  array_filter( $settings )  : array();

				    $portfolio_layout = array_key_exists('portfolio-layout', $settings) ? $settings['portfolio-layout'] : '';
				    if($portfolio_layout != 'fixed-gallery' && $portfolio_layout != 'fixed-feature-image' && $portfolio_layout != 'gallery-list') {

				        $page_layout  = array_key_exists( "layout", $settings ) ? $settings['layout'] : "content-full-width";
				        $layout = iva_page_layout( $page_layout );
				        extract( $layout );

				        if ( $show_sidebar ) {
				            if ( $show_right_sidebar ) {
				                $sticky_class = ( array_key_exists('enable-sticky-sidebar', $settings) && $settings['enable-sticky-sidebar'] == 'true' ) ? ' sidebar-as-sticky' : '';
				                ?>
				                <section id="secondary-right" class="secondary-sidebar <?php echo esc_attr( $sidebar_class.$sticky_class );?>"><?php
				                    iva_show_sidebar( 'dt_portfolios', $post->ID, 'right' ); ?>
				                </section>
				                <?php
				            }
				        }

						echo '</div>';
						
				    }

				echo '</div>';

			}

			if(is_post_type_archive('dt_portfolios') || is_tax ( 'portfolio_entries' ) || is_tax ( 'portfolio_tags' ) ) {

					$allow_fullwidth = dtportfolio_get_option('portfolio-allow-full-width');

					if($allow_fullwidth != 'true') {

				    	$page_layout  = dtportfolio_get_option( 'portfolio-archives-page-layout' );
				    	$page_layout  = !empty( $page_layout ) ? $page_layout : "content-full-width";

						if($page_layout != 'fullwidth') {

								echo '</section>';
								
								$show_sidebar = $show_right_sidebar = false;
								$sidebar_enable = dtportfolio_get_option( 'portfolio-archives-page-show-standard-sidebar' );
								if( is_active_sidebar('custom-post-portfolio-archives-sidebar-right') || (!empty( $sidebar_enable ) && is_active_sidebar('standard-sidebar-right')) ) {
									$show_sidebar = $show_right_sidebar = true;	
								}

						    	if ( $show_sidebar ) {
						    		if ( $show_right_sidebar ) {
						    			?>
						    			<section id="secondary-right" class="secondary-sidebar secondary-has-right-sidebar">
						    				<?php

						    				$wtstyle = dtportfolio_get_option( 'widget-title-style' );

											if(!empty($wtstyle)):
												echo "<div class='{$wtstyle}'>";
											endif;

												if( is_active_sidebar('custom-post-portfolio-archives-sidebar-right') ):
													dynamic_sidebar('custom-post-portfolio-archives-sidebar-right');
												endif;
												
												if( !empty( $sidebar_enable )):
													if( is_active_sidebar('standard-sidebar-right') ):
														dynamic_sidebar('standard-sidebar-right');
													endif;
												endif;

											if(!empty($wtstyle)):
												echo "</div>";
											endif;

						    				?>
						    			</section>
						    			<?php
						    		}
						    	}

						}

					}	    	

				    echo '</div>';
				echo '</div>';

		    }


		}

	}

}

if( !function_exists('dtportfolio_designthemes_instance') ) {
	function dtportfolio_designthemes_instance() {
		return DTPortfolioDesignThemes::instance();
	}
}

dtportfolio_designthemes_instance();

?>