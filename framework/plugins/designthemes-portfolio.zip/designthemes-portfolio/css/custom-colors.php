<?php

/* ---------------------------------------------------------------------------
 * Custom Color Styles
 * --------------------------------------------------------------------------- */

 if(!function_exists('dtportfolio_theme_custom_colors_styles')) {
	function dtportfolio_theme_custom_colors_styles() {

		$primary_color = dtportfolio_get_option( 'primary-color' );
		$primary_color_rgba = dtportfolio_hex2rgb( $primary_color );
		$primary_color_rgba = implode(',', $primary_color_rgba);

		$secondary_color = dtportfolio_get_option( 'secondary-color' );
		$secondary_color_rgba = dtportfolio_hex2rgb( $secondary_color );
		$secondary_color_rgba = implode(',', $secondary_color_rgba);

		$tertiary_color = dtportfolio_get_option( 'tertiary-color' );
		$tertiary_color_rgba = dtportfolio_hex2rgb( $tertiary_color );
		$tertiary_color_rgba = implode(',', $tertiary_color_rgba);

		
		$css = '';

		if( !empty( $primary_color ) ) {

			$css .= '.dtportfolio-item .dtportfolio-image-overlay .links a:hover, .dtportfolio-item .dtportfolio-image-overlay a:hover, .dtportfolio-fullpage-carousel .dtportfolio-fullpage-carousel-content a:hover, .dtportfolio-item.dtportfolio-hover-modern-title .dtportfolio-image-overlay .links a:hover, .dtportfolio-swiper-pagination-holder .dtportfolio-swiper-playpause:hover, .dtportfolio-categories a:hover { color:'.$primary_color.'; }';

			$css .= '.dtportfolio-swiper-pagination-holder .swiper-pagination-bullet-active { background:'.$primary_color.'; }';

		}

		if( !empty( $secondary_color ) ) {


		}

		if( !empty( $tertiary_color ) ) {


		}

		wp_add_inline_style( 'dtportfolio-frontend', $css );

	}
	add_action( 'wp_enqueue_scripts', 'dtportfolio_theme_custom_colors_styles', 105 );
}