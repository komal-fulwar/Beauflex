<?php
// -----------------------------------------
// Page - Metabox Options
// -----------------------------------------

function dtportfolio_page_metabox() {

  $options[] = array (
    'id'        => 'dtportfolio_template_settings',
    'title'     => sprintf( esc_html__('%1$s Options', 'dtportfolio'), dtportfolio_instance()->plugin_name()),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array (
      array (
        'name'  => 'dtportfolio_footer_section',
        'fields' => array (
          array (
            'type' 	=> 'switcher',
            'id' 	=> 'dtportfolio-transparent-header',
            'title' => esc_html__('Enable Transparent Header', 'dtportfolio'),
            'desc'  => esc_html__('If you wish you can enable transparent header for your theme.', 'dtportfolio'),
          ),
          array (
            'type' 	=> 'switcher',
            'id' 	=> 'dtportfolio-remove-spaces',
            'title' => esc_html__('Remove Additional Spaces', 'dtportfolio'),
            'desc'  => esc_html__('This option is usefull if u like to keep any item in fullscreen.', 'dtportfolio'),
          ),							
        )
      )
    )
  );

  return $options;

}