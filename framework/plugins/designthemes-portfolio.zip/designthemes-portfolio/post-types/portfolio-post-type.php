<?php
if( !class_exists('DTPortfolioPostType') ) {

	class DTPortfolioPostType {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action ( 'init', array ( $this, 'dtportfolio_register_portfolio_posttype' ) );
			add_filter ( 'cs_taxonomy_options', array ( $this, 'dtportfolio_category_options') );
			add_filter ( 'cs_save_taxonomy', array ( $this, 'dtportfolio_category_save_options'), 10, 3);

			add_action ( 'admin_init', array ( $this, 'dtportfolio_admin_init'  ) );

			add_filter ( 'template_include', array ( $this, 'dtportfolio_template_include' ) );

		}

		function dtportfolio_register_portfolio_posttype() {

			$portfolio_slug    = dtportfolio_get_option( 'single-portfolio-slug', 'portfolios' );
			$taxonomy_slug     = dtportfolio_get_option( 'portfolio-category-slug', 'portfolio-categories' );
			$tag_taxonomy_slug = dtportfolio_get_option( 'portfolio-tag-slug', 'portfolio-tags' );
	
			$labels = array (
				'name'               => esc_html__( 'Portfolios', 'dtportfolio' ),
				'all_items'          => esc_html__( 'All Portfolios', 'dtportfolio' ),
				'singular_name'      => esc_html__( 'Portfolio', 'dtportfolio' ),
				'add_new'            => esc_html__( 'Add New', 'dtportfolio' ),
				'add_new_item'       => esc_html__( 'Add New Portfolio', 'dtportfolio' ),
				'edit_item'          => esc_html__( 'Edit Portfolio', 'dtportfolio' ),
				'new_item'           => esc_html__( 'New Portfolio', 'dtportfolio' ),
				'view_item'          => esc_html__( 'View Portfolio', 'dtportfolio' ),
				'search_items'       => esc_html__( 'Search Portfolios', 'dtportfolio' ),
				'not_found'          => esc_html__( 'No Portfolios found', 'dtportfolio' ),
				'not_found_in_trash' => esc_html__( 'No Portfolios found in Trash', 'dtportfolio' ),
				'parent_item_colon'  => esc_html__( 'Parent Portfolio:', 'dtportfolio' ),
				'menu_name'          => esc_html__( 'Portfolios', 'dtportfolio' ) ,					
			);
			
			$args = array (
				'labels'              => $labels,
				'hierarchical'        => false,
				'description'         => esc_html__( 'This is custom post type portfolios', 'dtportfolio' ),
				'supports'            => array ( 'title', 'editor', 'comments', 'thumbnail', 'excerpt', 'revisions' ),
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'menu_position'       => 5,
				'menu_icon'           => 'dashicons-format-image',
				'show_in_nav_menus'   => true,
				'show_in_rest'        => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => false,
				'has_archive'         => true,
				'query_var'           => true,
				'can_export'          => true,
				'rewrite'             => array ( 'slug' => $portfolio_slug ),
				'capability_type'     => 'post'
			);
	
			register_post_type ( 'dt_portfolios', $args );
	
			register_taxonomy ( 'portfolio_entries', array (
				'dt_portfolios' 
			), array (
				'hierarchical'      => true,
				'label'             => esc_html__( 'Categories', 'dtportfolio' ),
				'singular_label'    => esc_html__( 'Category', 'dtportfolio' ),
				'show_admin_column' => true,
				'rewrite'           => array ( 'slug' => $taxonomy_slug ),
				'query_var'         => true,
				'show_in_rest'      => true
			) );
	
			register_taxonomy ( 'portfolio_tags', array (
				'dt_portfolios'
			), array (
				'label'             => esc_html__( 'Tags', 'dtportfolio' ),
				'singular_label'    => esc_html__( 'Tag', 'dtportfolio' ),
				'show_admin_column' => true,
				'rewrite'           => array ( 'slug' => $tag_taxonomy_slug ),
				'show_in_rest'      => true,
				'query_var'         => true 
			) );
				
		}

		function dtportfolio_category_options( $options ) {

			$options[] = array (
				'id'       => 'dtportfolio_category_settings',
				'taxonomy' => 'portfolio_entries',
				'fields'   => array (
	
					// Featured Image
					array (
						'id'        => 'category-image-id',
						'type'      => 'image',
						'title'     => esc_html__( 'Featured Image', 'dtportfolio'),
						'add_title' => esc_html__( 'Add Image', 'dtportfolio' ),
					),
	
					// Enable Album Gallery
					array (
						'id'      => 'category-enable-album',
						'type'    => 'select',
						'title'   => esc_html__('Enable Album Gallery', 'dtportfolio'),
						'default' => 'false',
						'options' => array (
							'true'  => esc_html__('Yes', 'dtportfolio'),
							'false' => esc_html__('No', 'dtportfolio'),
						)
					),
				)
			);
	
			return $options;

		}
	
		function dtportfolio_category_save_options( $request, $request_key, $term_id ) {
	
			if( $request_key == 'dtportfolio_category_settings' ) {
	
				if( isset( $request['category-image-id'] ) && !empty( $request['category-image-id'] ) ) {
	
					update_term_meta( $term_id, 'category-image-id', $request['category-image-id'] );
				} else {
					delete_term_meta( $term_id, 'category-image-id' );
				}
	
				if( isset( $request['category-enable-album'] ) ) {
	
					update_term_meta( $term_id, 'category-enable-album', $request['category-enable-album'] );
				} else {
	
					delete_term_meta( $term_id, 'category-enable-album' );
				}		
			}
	
			return $request;
		}


		function dtportfolio_admin_init() {

			add_filter ( 'manage_edit-dt_portfolios_columns', array ( $this, 'dtportfolio_portfolios_edit_columns'  ) );		
			add_action ( 'manage_posts_custom_column', array ( $this, 'dtportfolio_portfolios_columns_display' ), 10, 2 );
	
		}
	
		function dtportfolio_portfolios_edit_columns($columns) {
	
			$newcolumns = array (
				'cb'                 => '<input type="checkbox" />',
				'dt_portfolio_thumb' => esc_html__('Image', 'dtportfolio'),
				'title'              => esc_html__('Title', 'dtportfolio'),
				'author'             => esc_html__('Author', 'dtportfolio')
			);
			$columns = array_merge ( $newcolumns, $columns );

			return $columns;
	
		}
	
		function dtportfolio_portfolios_columns_display($columns, $id) {
	
			global $post;
	
			switch ($columns) {
	
				case 'dt_portfolio_thumb' :
	
					$image = wp_get_attachment_image(get_post_thumbnail_id($id), array (75,75));
					if(!empty($image)):
						  echo ($image);
					else:
						$portfolio_settings = get_post_meta ( $post->ID, '_portfolio_settings', TRUE );
						$portfolio_settings = is_array ( $portfolio_settings ) ? $portfolio_settings : array ();
	
						if( array_key_exists('portfolio-gallery', $portfolio_settings)) {
							$items = explode(',', $portfolio_settings['portfolio-gallery']);
							echo wp_get_attachment_image( $items[0], array (75, 75) );
						}
					endif;
	
				break;
			}
	
		}


		function dtportfolio_template_include($template) {

			if (is_singular( 'dt_portfolios' )) {
				if (! file_exists ( get_stylesheet_directory () . '/single-dt_portfolios.php' )) {
					$template = dtportfolio_instance()->plugin_path( 'post-types/templates/single-dt_portfolios.php' );
				}			
			} elseif (is_tax ( 'portfolio_entries' )) {
				if (! file_exists ( get_stylesheet_directory () . '/taxonomy-portfolio_entries.php' )) {
					$template = dtportfolio_instance()->plugin_path( 'post-types/templates/taxonomy-portfolio_entries.php' );
				}
			} elseif (is_tax ( 'portfolio_tags' )) {
				if (! file_exists ( get_stylesheet_directory () . '/taxonomy-portfolio_tags.php' )) {
					$template = dtportfolio_instance()->plugin_path( 'post-types/templates/taxonomy-portfolio_tags.php' );
				}
			} elseif (is_post_type_archive ( 'dt_portfolios' )) {
				if (! file_exists ( get_stylesheet_directory () . '/archive-dt_portfolios.php' )) {
					$template = dtportfolio_instance()->plugin_path( 'post-types/templates/archive-dt_portfolios.php' );
				}					
			}

			return $template;

		}

	}
}

if( !function_exists('dtportfolio_producttemplate_instance') ) {
	function dtportfolio_producttemplate_instance() {
		return DTPortfolioPostType::instance();
	}
}

dtportfolio_producttemplate_instance();