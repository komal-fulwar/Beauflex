<?php
if( !class_exists('DTPortfolioPostAndMetabox') ) {

	class DTPortfolioPostAndMetabox {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			// Portfolio Post Type
			require_once dtportfolio_instance()->plugin_path( 'post-types/portfolio-post-type.php' );

			// Metabox Options
			require_once dtportfolio_instance()->plugin_path( 'post-types/portfolio-metabox.php' );
			require_once dtportfolio_instance()->plugin_path( 'post-types/page-metabox.php' );

			add_filter ( 'dtm_metabox_options', array( $this, 'dtportfolio_cs_metabox_options' ) );

		}

		function dtportfolio_cs_metabox_options( $options ) {

			// Portfolio Metabox
			$portfolio_options = dtportfolio_posttype_metabox();
			$options = array_merge($portfolio_options, $options);

			// Page Metabox
			$page_options = dtportfolio_page_metabox();
			$options = array_merge($page_options, $options);

			return $options;

		}

	}
}

if( !function_exists('dtportfolio_postnmetabox_instance') ) {
	function dtportfolio_postnmetabox_instance() {
		return DTPortfolioPostAndMetabox::instance();
	}
}

dtportfolio_postnmetabox_instance();