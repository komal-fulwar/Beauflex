<?php

if(!function_exists('dtportfolio_portfolios_html')) {

	function dtportfolio_portfolios_html($attrs, $content = null) {

		$attrs = shortcode_atts ( array (

			'portfolioid' => '',
			'portfolio-post-per-page' => -1,
			'portfolio-post-style' => 'default',
			'portfolio-details-below-image' => '',
			'portfolio-multiscroll-enable-arrows' => '',
			'portfolio-fullpage-navigation' => '',
			'portfolio-fullpage-type' => '',
			'portfolio-disable-auto-scrolling' => '',
			'portfolio-fullpage-splittedsections' => 'leftside-image',
			'portfolio-parallax-effects' => '',
			'portfolio-post-layout' => 'dtportfolio-one-fourth-column',
			'portfolio-grid-space' => '',
			'filter' => '',
			'portfolio-filterdesign-type' => '',
			'portfolio-categories' => '',					
			'portfolio-pagination-type' => '',
			'class' => '',
			'enable-fullwidth' => '',
			'paged' => '1',
			'ajax-call' => '0',			
			
			'portfolio-disable-item-options' => '',
			'portfolio-hover-style' => 'modern-title',
			'portfolio-cursor-hover-style' => '',	
			'animationeffect' => '',
			'animationdelay' => '',
			'repeat-animation' => '',
			'hover-background-color' => '',
			'hover-content-color' => '',
			'hover-gradient-color' => '',
			'hover-gradient-direction' => 'lefttoright',
			'hover-state' => '',
			
			'portfolio-displaystyle' => '',
			'portfolio-carousel-effect' => '',
			'portfolio-carousel-numberofrows' => '',
			'portfolio-carousel-autoplay' => '',
			'portfolio-carousel-slidesperview' => 1,
			'portfolio-carousel-loopmode' => '',
			'portfolio-carousel-mousewheelcontrol' => '',
			'portfolio-carousel-centermode' => '',
			'portfolio-carousel-verticaldirection' => '',
			'portfolio-carousel-paginationtype' => '',
			'portfolio-carousel-thumbnailpagination' => '',
			'portfolio-carousel-arrowpagination' => '',
			'portfolio-carousel-arrowpagination_type' => '',
			'portfolio-carousel-scrollbar' => '',
			'portfolio-carousel-arrowformousepointer' => '',
			'portfolio-carousel-paginationcolorscheme' => '',
			'portfolio-carousel-playpausebutton' => '',
			'portfolio-carousel-spacebetween' => '',
			'portfolio-carousel-pagination_designtype' => '',

			'related-portfolio-id' => '',

		), $attrs, 'dtportfolio_portfolios' );

		$attrs = (is_array($attrs) && !empty($attrs)) ?array_filter($attrs) : array();

		$tpl_default_settings = array_filter($attrs);
		$tpl_default_settings['portfolio-carousel-content-over-slider'] = $content;

		global $post;
		$portfolio_shortcode_pageid = $post->ID;

		$show_sidebar = dtportfolio_shortcode_page_details($portfolio_shortcode_pageid);

		wp_enqueue_style ( 'dtportfolio-custom', dtportfolio_instance()->plugin_url('css/custom.css'), array (), false, 'all' );

		return dtportfolio_portfolio_lists($portfolio_shortcode_pageid, $tpl_default_settings, $show_sidebar);

	}

	add_shortcode( 'dtportfolio_portfolios', 'dtportfolio_portfolios_html' );

}


if(!function_exists('dtportfolio_ajax_infinite_portfolios')) {

	function dtportfolio_ajax_infinite_portfolios() {

		$completedata_array = json_decode(html_entity_decode(stripslashes($_REQUEST['completedata_json'])), true);

		$sc = '[dtportfolio_portfolios ajax-call="1"';
			foreach($completedata_array as $cda_key => $cda_val) {
				if($cda_key != 'ajax-call') {
					if($cda_key == 'paged') {
						$sc .= ' '.$cda_key.'="'.($cda_val+1).'"';
					} else if($cda_key == 'dtportfolio-categories') {
						if(is_array($cda_val)) {
							$sc .= ' '.$cda_key.'="'.implode(',',$cda_val).'"';
						} else {
							$sc .= ' '.$cda_key.'="'.$cda_val.'"';
						}				
					} else {
						$sc .= ' '.$cda_key.'="'.$cda_val.'"';
					}
				}
			}
		$sc .= ' /]';

		echo do_shortcode($sc);

		wp_die();

	}

	add_action( 'wp_ajax_dtportfolio_ajax_infinite_portfolios', 'dtportfolio_ajax_infinite_portfolios' );
	add_action( 'wp_ajax_nopriv_dtportfolio_ajax_infinite_portfolios', 'dtportfolio_ajax_infinite_portfolios' );

}


if(!function_exists('dtportfolio_single_images_slider')) {

	function dtportfolio_single_images_slider($settings) {

		$output = '';

		if($settings['portfolio_id'] == '' && is_singular('dt_portfolios')) {
			global $post;
			$settings['portfolio_id'] = $post->ID;
		}

		if($settings['portfolio_id'] != '') {

			$media_carousel_attributes = array ();

			$carousel_effect = isset($settings['carousel_effect']) ? $settings['carousel_effect'] : '';
			$carousel_autoplay = isset($settings['carousel_autoplay']) ? $settings['carousel_autoplay'] : '';
			$carousel_slidesperview = isset($settings['carousel_slidesperview']) ? $settings['carousel_slidesperview'] : '';
			$carousel_loopmode = isset($settings['carousel_loopmode']) ? $settings['carousel_loopmode'] : '';
			$carousel_mousewheelcontrol = isset($settings['carousel_mousewheelcontrol']) ? $settings['carousel_mousewheelcontrol'] : '';
			$carousel_verticaldirection = isset($settings['carousel_verticaldirection']) ? $settings['carousel_verticaldirection'] : '';
			$carousel_paginationtype = isset($settings['carousel_paginationtype']) ? $settings['carousel_paginationtype'] : '';
			$carousel_thumbnailpagination = isset($settings['carousel_thumbnailpagination']) ? $settings['carousel_thumbnailpagination'] : '';
			$carousel_arrowpagination = isset($settings['carousel_arrowpagination']) ? $settings['carousel_arrowpagination'] : '';
			$carousel_scrollbar = isset($settings['carousel_scrollbar']) ? $settings['carousel_scrollbar'] : '';
			$carousel_arrowformousepointer = isset($settings['carousel_arrowformousepointer']) ? $settings['carousel_arrowformousepointer'] : '';
			$carousel_playpausebutton = isset($settings['carousel_playpausebutton']) ? $settings['carousel_playpausebutton'] : '';
			$carousel_spacebetween = isset($settings['carousel_spacebetween']) ? $settings['carousel_spacebetween'] : '';

			$carousel_paginationcolorscheme = isset($settings['carousel_paginationcolorscheme']) ? $settings['carousel_paginationcolorscheme'] : '';
			$carousel_pagination_designtype = isset($settings['carousel_pagination_designtype']) ? $settings['carousel_pagination_designtype'] : '';
			$carousel_arrowpagination_type = isset($settings['carousel_arrowpagination_type']) ? $settings['carousel_arrowpagination_type'] : '';

			$background_image = isset($settings['background_image']) ? $settings['background_image'] : '';


			array_push($media_carousel_attributes, 'data-enablecarousel="true"');
			array_push($media_carousel_attributes, 'data-carouseleffect="'.esc_attr($carousel_effect).'"');
			array_push($media_carousel_attributes, 'data-carouselautoplay="'.esc_attr($carousel_autoplay).'"');
			array_push($media_carousel_attributes, 'data-carouselslidesperview="'.esc_attr($carousel_slidesperview).'"');
			array_push($media_carousel_attributes, 'data-carouselloopmode="'.esc_attr($carousel_loopmode).'"');
			array_push($media_carousel_attributes, 'data-carouselmousewheelcontrol="'.esc_attr($carousel_mousewheelcontrol).'"');
			array_push($media_carousel_attributes, 'data-carouselverticaldirection="'.esc_attr($carousel_verticaldirection).'"');
			array_push($media_carousel_attributes, 'data-carouselpaginationtype="'.esc_attr($carousel_paginationtype).'"');
			array_push($media_carousel_attributes, 'data-carouselthumbnailpagination="'.esc_attr($carousel_thumbnailpagination).'"');
			array_push($media_carousel_attributes, 'data-carouselarrowpagination="'.esc_attr($carousel_arrowpagination).'"');
			array_push($media_carousel_attributes, 'data-carouselscrollbar="'.esc_attr($carousel_scrollbar).'"');
			array_push($media_carousel_attributes, 'data-carouselarrowformousepointer="'.esc_attr($carousel_arrowformousepointer).'"');
			array_push($media_carousel_attributes, 'data-carouselplaypausebutton="'.esc_attr($carousel_playpausebutton).'"');
			array_push($media_carousel_attributes, 'data-carouselspacebetween="'.esc_attr($carousel_spacebetween).'"');

			if(!empty($media_carousel_attributes)) {
				$media_carousel_attributes_string = implode(' ', $media_carousel_attributes);
			}

			$portfolio_settings = get_post_meta($settings['portfolio_id'], '_portfolio_settings', true);
			$portfolio_settings = is_array($portfolio_settings) ? $portfolio_settings : array ();

			$portfolio_galleries = explode(',', $portfolio_settings['portfolio-gallery']);

			if(isset($settings['gallery_ids']) && $settings['gallery_ids'] != '') {
				$filter_gallery = true;
				$gallery_ids = explode(',', $settings['gallery_ids']);
			} else {
				$filter_gallery = false;
			}


		    $featured_image_id = get_post_thumbnail_id($settings['portfolio_id']);	
		    $featured_image_id = ($featured_image_id != '') ? $featured_image_id : -1;

			$output .= '<div class="dtportfolio-image-gallery-holder '.$settings['class'].'">';

				// Gallery Images
				$output .= '<div class="dtportfolio-image-gallery-container swiper-container">';
				    $output .= '<div class="dtportfolio-image-gallery swiper-wrapper" '.$media_carousel_attributes_string.'>';

				    				$gallery_thumb = array ();

				    				if($settings['include_featured_image'] == 'true') {

										$image_details = wp_get_attachment_image_src($featured_image_id, 'full');
										
			                           	$output .= '<div class="swiper-slide">';

				                           	if($background_image == 'true') {
				                           		$output .= '<div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div>';
				                           	} else {
				                           		$output .= '<img src="'.esc_url($image_details[0]).'" title="'.esc_html__('Featured Image', 'dtportfolio').'" alt="'.esc_html__('Featured Image', 'dtportfolio').'" />';
				                           	}

			                           	$output .= '</div>';

										array_push($gallery_thumb, '<div class="swiper-slide"><div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div></div>');

									}

				                    if(is_array($portfolio_galleries) && !empty($portfolio_galleries)) {
				                        foreach($portfolio_galleries as $portfolio_gallery) {

											if($filter_gallery) {

												if(in_array($portfolio_gallery, $gallery_ids)) {

					                                $image_details = wp_get_attachment_image_src($portfolio_gallery, 'full');
					                               	$output .= '<div class="swiper-slide">';
						                           		if($background_image == 'true') {
							                           		$output .= '<div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div>';
							                           	} else {
							                           		$output .= '<img src="'.esc_url($image_details[0]).'" title="'.esc_html__('Featured Image', 'dtportfolio').'" alt="'.esc_html__('Featured Image', 'dtportfolio').'" />';
							                           	}
					                               	$output .= '</div>';

					                               	array_push($gallery_thumb, '<div class="swiper-slide"><div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div></div>');

												}

											} else {

					                            $image_details = wp_get_attachment_image_src($portfolio_gallery, 'full');
					                           	$output .= '<div class="swiper-slide">';
					                           		if($background_image == 'true') {
						                           		$output .= '<div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div>';
						                           	} else {
						                           		$output .= '<img src="'.esc_url($image_details[0]).'" title="'.esc_html__('Featured Image', 'dtportfolio').'" alt="'.esc_html__('Featured Image', 'dtportfolio').'" />';
						                           	}
					                           	$output .= '</div>';

					                           	array_push($gallery_thumb, '<div class="swiper-slide"><div class="dtportfolio-single-image-holder" style="background-image:url('.esc_url($image_details[0]).');"></div></div>');

							    			}

				                        }
				                    }

		    		$output .= '</div>';

					$output .= '<div class="dtportfolio-swiper-pagination-holder '.$carousel_paginationcolorscheme.' '.$carousel_pagination_designtype.'">';

						if($carousel_arrowformousepointer == 'true') {

							$output .= '<div class="dtportfolio-swiper-arrow-mouse-pointer">
											<div class="dtportfolio-swiper-arrow-left">
												<div class="dtportfolio-swiper-arrow-click left">
													<div class="dtportfolio-swiper-arrow"></div>
												</div>
											</div>
											<div class="dtportfolio-swiper-arrow-middle">
												<div class="dtportfolio-swiper-arrow-click middle">
													<div class="dtportfolio-swiper-arrow"></div>
												</div>
											</div>
											<div class="dtportfolio-swiper-arrow-right">
												<div class="dtportfolio-swiper-arrow-click right">
													<div class="dtportfolio-swiper-arrow"></div>
												</div>
											</div>
										</div>';

						}

						if($carousel_paginationtype == 'bullets') {
							$output .= '<div class="dtportfolio-swiper-bullet-pagination"></div>';	
						}

						if($carousel_paginationtype == 'progressbar') {
							$output .= '<div class="dtportfolio-swiper-progress-pagination"></div>';	
						}	

						if($carousel_scrollbar == 'true') {
							$output .= '<div class="dtportfolio-swiper-scrollbar"></div>';	
						}						

						if(in_array($carousel_pagination_designtype, array ('type2', 'type3'))) {
							$output .= '<div class="dtportfolio-swiper-pagination-wrapper">';
						}

							if($carousel_paginationtype == 'fraction') {
								$output .= '<div class="dtportfolio-swiper-fraction-pagination"></div>';
							}							

							if($carousel_arrowpagination == 'true') {
								$output .= '<div class="dtportfolio-swiper-arrow-pagination '.$carousel_arrowpagination_type.'">';
									$output .= '<a href="#" class="dtportfolio-swiper-arrow-prev">'.esc_html__('Prev', 'dtportfolio').'</a>';
									$output .= '<a href="#" class="dtportfolio-swiper-arrow-next">'.esc_html__('Next', 'dtportfolio').'</a>';
								$output .= '</div>';
							}

							if($carousel_playpausebutton == 'true') {
								if($carousel_autoplay != '' && $carousel_autoplay > 0) {
									$output .= '<a href="#" class="dtportfolio-swiper-playpause pause"><span class="fa fa-pause"></span></a>';
								} else {
									$output .= '<a href="#" class="dtportfolio-swiper-playpause play"><span class="fa fa-play"></span></a>';
								}
							}

						if(in_array($carousel_pagination_designtype, array ('type2', 'type3'))) {
							$output .= '</div>';
						}
					
					$output .= '</div>';

		   		$output .= '</div>';

		   		if($carousel_thumbnailpagination == 'true') {

			   		// Gallery Thumb
					$output .= '<div class="dtportfolio-image-gallery-thumb-container swiper-container">';
					    $output .= '<div class="dtportfolio-image-gallery-thumb swiper-wrapper">';

					    	$output .= implode('', $gallery_thumb);

			    		$output .= '</div>';
			    	$output .= '</div>';

			    }

		   	$output .= '</div>';
			
		}

		return $output;

	}

}