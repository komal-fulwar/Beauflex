<?php
namespace DTElementor\widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DTPortfolioElementorWidgets {

	/**
	 * A Reference to an instance of this class
	 */
	private static $_instance = null;

	/**
	 * Instance
	 * 
	 * Ensures only one instance of the class is loaded or can be loaded.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		add_action( 'elementor/widgets/widgets_registered', array( $this, 'dtportfolio_register_widgets' ) );

		add_action( 'elementor/frontend/after_register_styles', array( $this, 'dtportfolio_register_widget_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'dtportfolio_register_widget_scripts' ) );

		add_action( 'elementor/preview/enqueue_styles', array( $this, 'dtportfolio_preview_styles') );

	}

	/**
	 * Register designthemes widgets
	 */
	public function dtportfolio_register_widgets( $widgets_manager ) {

		# Portfolio - Listing
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-listing.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Listing() );

		# Portfolio - Listing Widget
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-listing-widget.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Listing_Widget() );			

		# Portfolio Single - Onepage Navigation Title Holder
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-onepage-navigation-title-holder.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_One_Page_Navigation() );

		# Portfolio Single - Comment Form
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-comment-form.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Comment_Form() );

		# Portfolio Single - Comment List
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-comment-list.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Comment_List() );

		# Portfolio Single - Custom Details
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-custom-details.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Custom_Details() );	

		# Portfolio Single - Featured Image
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-featured-image.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Featured_Image() );	

		# Portfolio Single - Featured Video
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-featured-video.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Featured_Video() );	

		# Portfolio Single - Gallery Listings
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-gallery-listings.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Gallery_Listings() );	

		# Portfolio Single - Navigation Links
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-navigation-links.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Navigation_Links() );

		# Portfolio Single - Related Portfolios
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-related-portfolios.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Related_Portfolios() );

		# Portfolio Single - Sliders
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-sliders.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Sliders() );

		# Portfolio Single - Terms
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-terms.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Terms() );

		# Portfolio Single - Title
			require dtportfolio_instance()->plugin_path( 'elementor/widgets/class-widget-portfolio-single-title.php' );
			$widgets_manager->register_widget_type( new Elementor_Portfolio_Single_Title() );

	}

	/**
	 * Register designthemes widgets styles
	 */
	public function dtportfolio_register_widget_styles() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries

			wp_register_style( 'custom-font-awesome',
				dtportfolio_instance()->plugin_url('css/all.min.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'dtportfolio-animation',
				dtportfolio_instance()->plugin_url('css/animations.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'fullPage',
				dtportfolio_instance()->plugin_url('css/jquery.fullPage.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'ilightbox',
				dtportfolio_instance()->plugin_url('css/ilightbox.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'multiscroll',
				dtportfolio_instance()->plugin_url('css/jquery.multiscroll.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'swiper',
				dtportfolio_instance()->plugin_url('css/swiper.min.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'dtportfolio-frontend',
				dtportfolio_instance()->plugin_url('css/frontend.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

			wp_register_style( 'dtportfolio-responsive',
				dtportfolio_instance()->plugin_url('css/responsive.css'),
				array(),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION
			);

	}

	/**
	 * Register designthemes widgets scripts
	 */
	public function dtportfolio_register_widget_scripts() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries

			wp_register_script( 'isotope-pkgd',
				dtportfolio_instance()->plugin_url('js/isotope.pkgd.min.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.fullPage',
				dtportfolio_instance()->plugin_url('js/jquery.fullPage.min.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.jarallax',
				dtportfolio_instance()->plugin_url('js/jarallax.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.multiscroll',
				dtportfolio_instance()->plugin_url('js/jquery.multiscroll.min.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.swiper',
				dtportfolio_instance()->plugin_url('js/swiper.min.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery.ilightbox',
				dtportfolio_instance()->plugin_url('js/ilightbox.min.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery-inview',
				dtportfolio_instance()->plugin_url('js/jquery.inview.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'jquery-nicescroll',
				dtportfolio_instance()->plugin_url('js/jquery.nicescroll.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );

			wp_register_script( 'dtportfolio-frontend',
				dtportfolio_instance()->plugin_url('js/frontend.js'),
				array( 'jquery' ),
				dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
				true );


			# One Page Navigation Holder

				wp_register_script( 'jquery.onepage.navigation',
					dtportfolio_instance()->plugin_url('js/onepage-navigation.js'),
					array( 'jquery' ),
					dtportfolio_instance()::DTPORTFOLIO_ELEMENTOR_VERSION,
					true );

	}
	
	/**
	 * Editor Preview Style
	 */
	public function dtportfolio_preview_styles() {

		# Libraries
			wp_enqueue_style( 'fullPage' );
			wp_enqueue_style( 'ilightbox' );
			wp_enqueue_style( 'multiscroll' );
			wp_enqueue_style( 'swiper' );

	}

}

DTPortfolioElementorWidgets::instance();