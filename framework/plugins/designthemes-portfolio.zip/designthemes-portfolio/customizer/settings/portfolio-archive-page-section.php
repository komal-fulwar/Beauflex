<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Page Layout
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-archives-page-layout]', array(
			'default'           => dtportfolio_get_option( 'portfolio-archives-page-layout' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-archives-page-layout]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Layout', 'dtportfolio'),
				'section'  => 'portfolio-archive-page-section',
				'choices'  => apply_filters( 'dtportfolio_archive_page_layout_options', dtportfolio_customizer_instance()->dtportfolio_page_layout_options() )
			)
		)
	);

/**
* Option : Show Standard Sidebar
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-archives-page-show-standard-sidebar]', array(
			'default'           => dtportfolio_get_option( 'portfolio-archives-page-show-standard-sidebar' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-archives-page-show-standard-sidebar]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Show Standard Sidebar', 'dtportfolio'),
				'section' => 'portfolio-archive-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtportfolio' ),
					'off' => esc_attr__( 'No', 'dtportfolio' )
				),
				'dependency' => array( 'portfolio-archives-page-layout', 'any', 'with-left-sidebar,with-right-sidebar' )
			)
		)
	);


/**
 * Option : Pportfolio Layout
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-archives-post-layout]', array(
			'default'           => dtportfolio_get_option( 'portfolio-archives-post-layout' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Radio_Image(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-archives-post-layout]', array(
				'type'     => 'dt-radio-image',
				'label'    => esc_html__( 'Post Layout', 'dtportfolio'),
				'section'  => 'portfolio-archive-page-section',
				'choices'  => apply_filters( 'dtportfolio_archives_post_layout_options', dtportfolio_customizer_instance()->dtportfolio_post_column_options(true) )
			)
		)
	);

/**
 * Option : Hover Style
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-hover-style]', array(
			'default'           => dtportfolio_get_option( 'portfolio-hover-style' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-hover-style]', array (
				'type'     => 'select',
				'label'    => esc_html__( 'Hover Style', 'dtportfolio'),
				'section'  => 'portfolio-archive-page-section',
				'choices'  => apply_filters( 'dtportfolio_hover_styles', array (
					''                    => esc_html__('Default','dtportfolio'), 
					'modern-title'        => esc_html__('Modern Title','dtportfolio'), 
					'title-icons-overlay' => esc_html__('Title & Icons Overlay','dtportfolio'), 
					'title-overlay'       => esc_html__('Title Overlay','dtportfolio'),
					'icons-only'          => esc_html__('Icons Only','dtportfolio'), 
					'classic'             => esc_html__('Classic','dtportfolio'), 
					'minimal-icons'       => esc_html__('Minimal Icons','dtportfolio'),
					'presentation'        => esc_html__('Presentation','dtportfolio'), 
					'girly'               => esc_html__('Girly','dtportfolio'), 
					'art'                 => esc_html__('Art','dtportfolio'), 
					'extended'            => esc_html__('Extended','dtportfolio'), 
					'boxed'               => esc_html__('Boxed','dtportfolio'), 
					'centered-box'        => esc_html__('Centered Box','dtportfolio'),
					'with-gallery-thumb'  => esc_html__('With Gallery Thumb','dtportfolio'), 
					'with-gallery-list'   => esc_html__('With Gallery List','dtportfolio'), 
					'grayscale'           => esc_html__('Grayscale','dtportfolio'), 
					'highlighter'         => esc_html__('Highlighter','dtportfolio'), 
					'with-details'        => esc_html__('With Details','dtportfolio'), 
					'bottom-border'       => esc_html__('Bottom Border','dtportfolio'),
					'with-intro'          => esc_html__('With Intro','dtportfolio')
				) )
			)
		)
	);

/**
 * Option : Cursor Hover Style
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-cursor-hover-style]', array(
			'default'           => dtportfolio_get_option( 'portfolio-cursor-hover-style' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-cursor-hover-style]', array (
				'type'     => 'select',
				'label'    => esc_html__( 'Cursor Hover Style', 'dtportfolio'),
				'section'  => 'portfolio-archive-page-section',
				'choices'  => apply_filters( 'dtportfolio_cursor_hover_styles', array (
					''                    => esc_html__('Default', 'dtportfolio'), 
					'cursor-hover-style1' => esc_html__('Style 1', 'dtportfolio'), 
					'cursor-hover-style2' => esc_html__('Style 2', 'dtportfolio') ,
					'cursor-hover-style3' => esc_html__('Style 3', 'dtportfolio'),
					'cursor-hover-style4' => esc_html__('Style 4', 'dtportfolio'),
					'cursor-hover-style5' => esc_html__('Style 5', 'dtportfolio'),
					'cursor-hover-style6' => esc_html__('Style 6', 'dtportfolio'), 
				) )
			)
		)
	);

/**
 * Option : Allow Grid Space
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-grid-space]', array(
			'default'           => dtportfolio_get_option( 'portfolio-grid-space' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-grid-space]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Allow Grid Space', 'dtportfolio'),
				'section' => 'portfolio-archive-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtportfolio' ),
					'off' => esc_attr__( 'No', 'dtportfolio' )
				)
			)
		)
	);

/**
 * Option : Allow Full Width
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-allow-full-width]', array(
			'default'           => dtportfolio_get_option( 'portfolio-allow-full-width' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-allow-full-width]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Allow Full Width', 'dtportfolio'),
				'section' => 'portfolio-archive-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtportfolio' ),
					'off' => esc_attr__( 'No', 'dtportfolio' )
				)
			)
		)
	);

/**
 * Option : Disable Individual Portfolio Item Options
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[portfolio-disable-item-options]', array(
			'default'           => dtportfolio_get_option( 'portfolio-disable-item-options' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[portfolio-disable-item-options]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Disable Individual Portfolio Item Options', 'dtportfolio'),
				'section' => 'portfolio-archive-page-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'dtportfolio' ),
					'off' => esc_attr__( 'No', 'dtportfolio' )
				)
			)
		)
	);