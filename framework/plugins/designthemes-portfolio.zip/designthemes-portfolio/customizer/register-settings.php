<?php
if( !class_exists('DTPortfolioCustomizerSettings') ) {

	class DTPortfolioCustomizerSettings {

		private static $instance;

		public static function instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action( 'customize_register',array( $this, 'dtportfolio_register_settings' ), 20 );
			add_filter( 'dttheme_default_settings', array( $this, 'dtportfolio_default_settings' ) );
		}

		public function dtportfolio_register_settings( $wp_customize ) {

			require dtportfolio_instance()->plugin_path( 'customizer/settings/index.php' );

		}

		public function dtportfolio_default_settings( $defaults ) {

			$modified_defaults = array_merge (

						$defaults,

						array (

							// Archive Pages 
								'portfolio-archives-page-layout'                => 'content-full-width',
								'portfolio-archives-page-show-standard-sidebar' => '',
								'portfolio-archives-post-layout'                => 'dtportfolio-one-fourth-column',
								'portfolio-hover-style'                         => '',
								'portfolio-cursor-hover-style'                  => '',
								'portfolio-grid-space'                          => '',
								'portfolio-allow-full-width'                    => '',
								'portfolio-disable-item-options'                => '',

							// Permalinks
								'single-portfolio-slug'   => '',
								'portfolio-category-slug' => '',
								'portfolio-tag-slug' => '',

							// Custom Fields
								'dt-portfolio-custom-field-1'   => esc_html__('Website', 'dtportfolio')

						)

					);

			return $modified_defaults;

		}

		public function dtportfolio_page_layout_options() {

			$layout_options = array (
				'content-full-width'  => array ( 
					'label' => esc_html__( 'Without Sidebar', 'dtportfolio' ), 
					'path' => dtportfolio_instance()->plugin_url( 'images/customizer/without-sidebar.png' ) 
				),
				'with-left-sidebar' => array ( 
					'label' => esc_html__( 'Left Sidebar', 'dtportfolio' ),
					'path' => dtportfolio_instance()->plugin_url( 'images/customizer/left-sidebar.png' )
				),
				'with-right-sidebar' => array ( 
					'label' => esc_html__( 'Right Sidebar', 'dtportfolio' ),
					'path' => dtportfolio_instance()->plugin_url( 'images/customizer/right-sidebar.png' ) 
				),
			);

			return $layout_options;

		}

		public function dtportfolio_post_column_options($one_column = true) {

			$column_options = array ();

			if($one_column) {

				$column_options['dtportfolio-one-column'] = array ( 
										'label' => esc_html__( 'One Column', 'dtportfolio' ), 
										'path' => dtportfolio_instance()->plugin_url( 'images/customizer/one-column.png' )
									);

			}

			$column_options['dtportfolio-one-half-column'] = array ( 
									'label' => esc_html__( 'One Half Column', 'dtportfolio' ), 
									'path' => dtportfolio_instance()->plugin_url( 'images/customizer/one-half-column.png' )
								);

			$column_options['dtportfolio-one-third-column'] = array ( 
									'label' => esc_html__( 'One Third Column', 'dtportfolio' ), 
									'path' => dtportfolio_instance()->plugin_url( 'images/customizer/one-third-column.png' )
								);

			$column_options['dtportfolio-one-fourth-column'] = array ( 
									'label' => esc_html__( 'One Fourth Column', 'dtportfolio' ), 
									'path' => dtportfolio_instance()->plugin_url( 'images/customizer/one-fourth-column.png' )
								);

			return $column_options;

		}

	}
}

if( !function_exists('dtportfolio_customizer_instance') ) {
	function dtportfolio_customizer_instance() {
		return DTPortfolioCustomizerSettings::instance();
	}
}

dtportfolio_customizer_instance();