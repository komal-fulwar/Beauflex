<?php
/*
 * Plugin Name:	DesignThemes Portfolio
 * URI: 		http://wedesignthemes.com/plugins/designthemes-portfolio
 * Description: A simple wordpress plugin designed to implement <strong>Portfolios</strong> by designthemes
 * Version: 	1.2
 * Author: 		DesignThemes
 * Text Domain: dtportfolio
 * Author URI:	http://themeforest.net/user/designthemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * The main class that initiates and runs the plugin.
 */
final class DTPortfolio {

	/**
	 * Plugin Name
	 */
	private $plugin_name = null;

	/**
	 * Theme Name
	 */
	private $theme_name = null;

	/**
	 * Plugin Version
	 */
	const DTPORTFOLIO_ELEMENTOR_VERSION = '1.0';

	/**
	 * Minimum PHP Version
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Minimum Elementor version
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.6.8';

	/**
	 * Instance variable
	 */
	private static $_instance = null;

	/**
	 * Base Plugin URL
	 */
	private $plugin_url = null;	

	/**
	 * Base Plugin Path
	 */
	private $plugin_path = null;

	/**
	 * Preview Mode
	 */
	private $preview_mode = null;

	/**
	 * Instance
	 * 
	 * Ensures only one instance of the class is loaded or can be loaded.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		
		add_action( 'init', array( $this, 'i18n' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Load Textdomain
	 */
	public function i18n() {
		load_plugin_textdomain( 'dtportfolio', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Initialize the plugin
	 */
	public function init() {

		// Check for required PHP version
			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', array( $this, 'dtportfolio_minimum_php_version' ) );
				return;
			}

		// Check if Elementor installed and activated
			if ( ! did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', array( $this, 'dtportfolio_missing_elementor_plugin' ) );
				return;
			}

		// Check for required Elementor version
			if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', array( $this, 'dtportfolio_minimum_elementor_version' ) );
				return;
			}

		// Enqueue CSS and JS Files
			add_action ( 'admin_enqueue_scripts', array ( $this, 'dtportfolio_admin_enqueue_scripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'dtportfolio_enqueue_scripts' ) );
			require_once $this->plugin_path( 'css/custom-colors.php' ); // Theme Custom Colors Script

		// Include Functions
			require_once $this->plugin_path( 'includes/class-designthemes.php' );
			require_once $this->plugin_path( 'includes/functions-singlepage.php' );
			require_once $this->plugin_path( 'includes/functions-templatepage.php' );
			require_once $this->plugin_path( 'includes/theme-related-functions.php' );

		// Elementor Widgets
			add_action( 'elementor/elements/categories_registered', array( $this, 'dtportfolio_register_category' ) );
			require_once $this->plugin_path( 'elementor/widget-functions.php' );
			require_once $this->plugin_path( 'elementor/register-widgets.php' );

		// Customizer Settings
			require_once $this->plugin_path( 'customizer/register-settings.php' );

		// Post Type & Metaboxes
			require_once dtportfolio_instance()->plugin_path( 'post-types/register-posttypes.php' );

		// Widgets
			require_once dtportfolio_instance()->plugin_path( 'widgets/widget-recent-portfolios.php' );
			add_action( 'widgets_init', array( $this, 'dtportfolio_register_widget' ) );	

	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required PHP version.
	 */
	public function dtportfolio_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'dtportfolio' ),
			'<strong>' . esc_html__( 'DesignThemes Portfolio', 'dtportfolio' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'dtportfolio' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have Elementor installed or activated.
	 */
	public function dtportfolio_missing_elementor_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'dtportfolio' ),
			'<strong>' . esc_html__( 'DesignThemes Portfolio', 'dtportfolio' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'dtportfolio' ) . '</strong>'			
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required Elementor version.
	 */
	public function dtportfolio_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'dtportfolio' ),
			'<strong>' . esc_html__( 'DesignThemes Portfolio', 'dtportfolio' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'dtportfolio' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );		
	}

	/**
	 * Returns path to file or dir inside plugin folder
	 */
	public function plugin_path( $path = null ) {

		if ( ! $this->plugin_path ) {
			$this->plugin_path = trailingslashit( plugin_dir_path( __FILE__ ) );
		}

		return $this->plugin_path . $path;
	}

	/**
	 * Returns url to file or dir inside plugin folder
	 */
	public function plugin_url( $path = null ) {

		if ( ! $this->plugin_url ) {
			$this->plugin_url = trailingslashit( plugin_dir_url( __FILE__ ) );
		}

		return $this->plugin_url . $path;
	}

	/**
	 * Returns plugin name
	 */
	public function plugin_name() {

		if( ! function_exists('get_plugin_data')) {
			require_once( ABSPATH . 'wp-admin/includes/plugin.php');
		}

		$plugin_data = get_plugin_data( __FILE__ );
		$this->plugin_name = $plugin_data['Name'];

		return $this->plugin_name;

	}

	/**
	 * Enqueue styles for backend
	 */
	public function dtportfolio_admin_enqueue_scripts() {
		wp_enqueue_style ( 'dtportfolio-backend', $this->plugin_url() . 'css/backend.css', array (), false, 'all' );
	}
	
	/**
	 * Enqueue styles for frontend
	 */
	public function dtportfolio_enqueue_scripts() {

		$this->preview_mode = 'false';
		if(did_action('elementor/loaded') && \Elementor\Plugin::$instance->preview->is_preview_mode()) {
			$this->preview_mode = 'true';
		}

		if(is_singular('dt_portfolios') || is_tax ('portfolio_entries') || is_tax ( 'portfolio_tags' ) || is_post_type_archive ( 'dt_portfolios' )) {

			// CSS files

				wp_enqueue_style ( 'custom-font-awesome', $this->plugin_url() . 'css/all.min.css', array (), false, 'all' );
				wp_enqueue_style ( 'dtportfolio-animation', $this->plugin_url() . 'css/animations.css', array (), false, 'all' );
				wp_enqueue_style ( 'fullPage', $this->plugin_url() . 'css/jquery.fullPage.css', array (), false, 'all' );
				wp_enqueue_style ( 'ilightbox', $this->plugin_url() . 'css/ilightbox.css', array (), false, 'all' );
				wp_enqueue_style ( 'multiscroll', $this->plugin_url() . 'css/jquery.multiscroll.css', array (), false, 'all' );
				wp_enqueue_style ( 'swiper', $this->plugin_url() . 'css/swiper.min.css', array (), false, 'all' );
				wp_enqueue_style ( 'dtportfolio-frontend', $this->plugin_url() . 'css/frontend.css', array (), false, 'all' );	
				wp_enqueue_style ( 'dtportfolio-responsive', $this->plugin_url() . 'css/responsive.css', array (), false, 'all' );


			// JS files

				wp_enqueue_script ( 'isotope-pkgd', $this->plugin_url() . 'js/isotope.pkgd.min.js', array ('jquery'), false, true);
				wp_enqueue_script ( 'jquery.fullPage', $this->plugin_url() . 'js/jquery.fullPage.min.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'jquery.jarallax', $this->plugin_url() . 'js/jarallax.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'jquery.multiscroll', $this->plugin_url() . 'js/jquery.multiscroll.min.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'jquery.swiper', $this->plugin_url() . 'js/swiper.min.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'jquery.ilightbox', $this->plugin_url() . 'js/ilightbox.min.js', array ('jquery'), false, true );

				wp_enqueue_script ( 'jquery-inview', $this->plugin_url() . 'js/jquery.inview.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'jquery-nicescroll', $this->plugin_url() . 'js/jquery.nicescroll.js', array ('jquery'), false, true );
				wp_enqueue_script ( 'dtportfolio-frontend', $this->plugin_url() . 'js/frontend.js', array ('jquery'), false, true );

		}

		wp_localize_script ( 'dtportfolio-frontend', 'dtportfoliofrontendobject', array (
			'ajaxurl' => esc_url( admin_url('admin-ajax.php') ),
			'elementor_preview_mode' => $this->preview_mode
		));

	}

	/**
	 * Register category
	 * Add plugin category in elementor 
	 */
	public function dtportfolio_register_category( $elements_manager ) {

		$elements_manager->add_category(
			'dtportfolio-widgets',array(
				'title' => $this->plugin_name(),
				'icon'  => 'font'
			)
		);

	}

	/**
	 * Register Widget
	 */
	public function dtportfolio_register_widget() {
		register_widget('DTPortfolio_Widget');
	}

}

if( !function_exists('dtportfolio_instance') ) {
	function dtportfolio_instance() {
		return DTPortfolio::instance();
	}
}

dtportfolio_instance();