<?php
add_filter( 'wpsl_templates', 'iva_wpsl_custom_templates' );
function iva_wpsl_custom_templates( $templates ) {

	$obj = new DTElementorCore;

    $templates[] = array (
        'id'   => 'custom',
        'name' => esc_html__('Custom template', 'dt-elementor' ),
        'path' => $obj->plugin_path('wpsl/wpsl-templates/custom.php'),
    );

    return $templates;
}

add_filter( 'wpsl_listing_template', 'iva_custom_listing_template' );
function iva_custom_listing_template(){

    global $wpsl_settings;

    $listing_template = '<li data-store-id="<%= id %>">' . "\r\n";
    $listing_template .= "\t\t" . '<div>' . "\r\n";
    $listing_template .= "\t\t\t" . '<p><%= thumb %>' . "\r\n";
    $listing_template .= "\t\t\t\t" . wpsl_store_header_template( 'listing' ) . "\r\n";
    $listing_template .= "\t\t\t\t" . '<span class="wpsl-street"><%= address %></span>' . "\r\n";
    $listing_template .= "\t\t\t\t" . '<% if ( address2 ) { %>' . "\r\n";
    $listing_template .= "\t\t\t\t" . '<span class="wpsl-street"><%= address2 %></span>' . "\r\n";
    $listing_template .= "\t\t\t\t" . '<% } %>' . "\r\n";
    $listing_template .= "\t\t\t\t" . '<span>' . wpsl_address_format_placeholders() . '</span>' . "\r\n";
    $listing_template .= "\t\t\t\t" . '<span class="wpsl-country"><%= country %></span>' . "\r\n";
    $listing_template .= "\t\t\t" . '</p>' . "\r\n";
    $listing_template .= "\t\t" . '</div>' . "\r\n";

    if ( !$wpsl_settings['hide_distance'] ) {
        $listing_template .= "\t\t" . '<p><span><%= distance %> ' . esc_html( $wpsl_settings['distance_unit'] ) . '</span></p>' . "\r\n";
    }

	$appointment_pageurl = iva_get_page_permalink_by_its_template('tpl-reservation.php');
	if($appointment_pageurl != '' && $appointment_pageurl != '#' && class_exists( 'DTElementorCore' )) {
		$listing_template .= "\t\t\t" . '<a href="'.$appointment_pageurl.'?storeid=<%= id %>" target="_blank" class="dt-appointment-fix dt-sc-button filled medium">' . esc_html__( 'Fix an Appointment', 'dt-elementor' ) . '</a>' . "\r\n";
	}

    $listing_template .= "\t\t" . '<%= createDirectionUrl() %>' . "\r\n"; 

    $listing_template .= "\t" . '</li>' . "\r\n"; 

    return $listing_template;
	
}

add_filter( 'wpsl_thumb_size', 'iva_wpsl_custom_thumb_size' );
function iva_wpsl_custom_thumb_size(){    
    $size = array( 90, 90 );
    return $size;	
}

add_filter ('theme_page_templates', 'iva_wpsl_add_page_template');
function iva_wpsl_add_page_template( $templates ){

    $templates['tpl-wpsl_stores.php'] = esc_html__('Store Locator Template', 'dt-elementor');

    return $templates;
}

add_filter ('page_template', 'iva_wpsl_redirect_page_template');
function iva_wpsl_redirect_page_template( $template ) {

    if ( is_page_template( 'tpl-wpsl_stores.php' ) ) {
    	$obj = new DTElementorCore;
        $template = $obj->plugin_path('wpsl/tpl-wpsl_stores.php');
    }

    return $template;
}

add_filter( 'single_template', 'iva_wpsl_single_template', 10 );
function iva_wpsl_single_template( $single_template ) {
     global $post;

     if ( $post->post_type == 'wpsl_stores' ) {
     	$obj = new DTElementorCore;
        $single_template = $obj->plugin_path('wpsl/single-wpsl_stores.php');
     }

     return $single_template;
}