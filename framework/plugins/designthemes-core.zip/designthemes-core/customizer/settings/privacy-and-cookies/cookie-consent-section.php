<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Option : Enable Cookie Consent
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[enable-cookie-consent]', array (
			'default'           => iva_get_option( 'enable-cookie-consent' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[enable-cookie-consent]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Cookie Message Bar', 'dt-elementor'),
				'description'   => esc_html__('Enable cookie consent message bar', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				)
			)
		)
	);

/**
* Option : Cookie Consent Message
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[cookie-consent-msg]', array (
			'default'           => iva_get_option( 'cookie-consent-msg' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[cookie-consent-msg]', array (
				'type'    => 'textarea',
				'label'   => esc_html__( 'Message', 'dt-elementor'),
				'description'   => esc_html__('Provide a message which indicates that your site uses cookies.', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
 * Option : Message Bar Position
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[cookie-bar-position]', array(
			'default'           => iva_get_option( 'cookie-bar-position' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[cookie-bar-position]', array(
				'type'     => 'select',
				'label'    => esc_html__( 'Message Bar Position', 'dt-elementor'),
				'section'  => 'cookie-consent-section',
				'choices'  => array(
								'top' 	        => esc_html__('Top', 'dt-elementor'),
								'bottom'       => esc_html__('Bottom', 'dt-elementor'),
								'top-left' 	   => esc_html__('Top Left Corner', 'dt-elementor'),
								'top-right' 	  => esc_html__('Top Right Corner', 'dt-elementor'),
								'bottom-left'	 => esc_html__('Bottom Left Corner', 'dt-elementor'),
								'bottom-right' => esc_html__('Bottom Right Corner', 'dt-elementor')
							),
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
 * Option : Enable Dismiss the notification
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[enable-dismiss-the-notification]', array (
			'default'           => iva_get_option( 'enable-dismiss-the-notification' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[enable-dismiss-the-notification]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Dismiss the notification', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				),
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
 * Option : Dismiss the notification label
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[dismiss-the-notification-label]', array(
			'default'           => iva_get_option( 'dismiss-the-notification-label' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[dismiss-the-notification-label]', array(
				'type'       => 'text',
				'section' 	 => 'cookie-consent-section',
				'label'      => esc_html__( 'Dismiss the notification label', 'dt-elementor' ),
				'dependency' => array ( 'enable-cookie-consent|enable-dismiss-the-notification', '==|==', '1|1' )
			)
		)
	);

/**
 * Option : Enable Link to another page
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[enable-link-to-another-page]', array (
			'default'           => iva_get_option( 'enable-link-to-another-page' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[enable-link-to-another-page]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Link to another page', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				),
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
 * Option : Link to another page label
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[link-to-another-page-label]', array(
			'default'           => iva_get_option( 'link-to-another-page-label' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[link-to-another-page-label]', array(
				'type'       => 'text',
				'section' 	 => 'cookie-consent-section',
				'label'      => esc_html__( 'Link to another page label', 'dt-elementor' ),
				'dependency' => array ( 'enable-cookie-consent|enable-link-to-another-page', '==|==', '1|1' )
			)
		)
	);

/**
 * Option : Link to another page link
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[link-to-another-page-link]', array(
			'default'           => iva_get_option( 'link-to-another-page-link' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[link-to-another-page-link]', array(
				'type'       => 'text',
				'section' 	 => 'cookie-consent-section',
				'label'      => esc_html__( 'Link to another page link', 'dt-elementor' ),
				'dependency' => array ( 'enable-cookie-consent|enable-link-to-another-page', '==|==', '1|1' )
			)
		)
	);

/**
 * Option : Enable Open info modal on privacy and cookies
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[enable-open-infomodal-on-privacy-and-cookies]', array (
			'default'           => iva_get_option( 'enable-dismiss-the-notification' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[enable-open-infomodal-on-privacy-and-cookies]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Open info modal on privacy and cookies', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				),
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
* Option : Open info modal on privacy and cookies label
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[open-infomodal-on-privacy-and-cookies-label]', array(
			'default'           => iva_get_option( 'open-infomodal-on-privacy-and-cookies-label' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[open-infomodal-on-privacy-and-cookies-label]', array(
				'type'       => 'text',
				'section' 	 => 'cookie-consent-section',
				'label'      => esc_html__( 'Open info modal on privacy and cookies label', 'dt-elementor' ),
				'dependency' => array ( 'enable-cookie-consent|enable-open-infomodal-on-privacy-and-cookies', '==|==', '1|1' )
			)
		)
	);


/**
 * Option : Model Window Custom Content
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[enable-custom-model-content]', array (
			'default'           => iva_get_option( 'enable-custom-model-content' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[enable-custom-model-content]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Model Window Custom Content', 'dt-elementor'),
				'description'   => esc_html__('Instead of displaying the default content set custom content yourself', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				),
				'dependency' => array ( 'enable-cookie-consent', '==', '1' )
			)
		)
	);

/**
 * Option : Main Heading
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[custom-model-heading]', array(
			'default'           => iva_get_option( 'custom-model-heading' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[custom-model-heading]', array(
				'type'        => 'text',
				'section'     => 'cookie-consent-section',
				'label'       => esc_html__( 'Main Heading', 'dt-elementor' ),
				'description' => esc_html__('Cookie and Privacy Settings', 'dt-elementor'),
				'dependency'  => array ( 'enable-cookie-consent|enable-custom-model-content', '==|==', '1|1' )
			)
		)
	);

/**
* Option : Model Window Custom Content
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[custom-model-content]', array (
			'default'           => iva_get_option( 'custom-model-content' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[custom-model-content]', array (
				'type'    => 'textarea',
				'label'   => esc_html__( 'Model Window Custom Content', 'dt-elementor'),
				'section' => 'cookie-consent-section',
				'dependency'  => array ( 'enable-cookie-consent|enable-custom-model-content', '==|==', '1|1' )
			)
		)
	);