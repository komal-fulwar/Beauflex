<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Privacy Comment Form
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-commentform]', array (
			'default'           => iva_get_option( 'privacy-commentform' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-commentform]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Append a privacy policy message to your comment form?', 'dt-elementor'),
				'description'   => esc_html__( 'Check to append a message to the comment form for unregistered users. Commenting without consent is no longer possible', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				)
			)
		)
	);

/**
 * Option : Message below comment form
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-commentform-msg]', array (
			'default'           => iva_get_option( 'privacy-commentform-msg' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-commentform-msg]', array (
				'type'    => 'textarea',
				'label'   => esc_html__( 'Message below comment form', 'dt-elementor'),
				'description'   => esc_html__( 'A short message that can be displayed below forms, along with a checkbox, that lets the user know that he has to agree to your privacy policy in order to send the form.', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'dependency' => array ( 'privacy-commentform', '==', '1' )
			)
		)
	);	


/**
 * Option : Privacy Subscribe Form
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-subscribeform]', array (
			'default'           => iva_get_option( 'privacy-subscribeform' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-subscribeform]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__('Append a privacy policy message to mailchimp contact forms?', 'dt-elementor'),
				'description'   => esc_html__('Check to append a message to all of your mailchimp forms.', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				)
			)
		)
	);

/**
* Option : Privacy Subscribe Form Message
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-subscribeform-msg]', array (
			'default'           => iva_get_option( 'privacy-subscribeform-msg' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-subscribeform-msg]', array (
				'type'    => 'textarea',
				'label'   => esc_html__('Message below mailchimp subscription forms', 'dt-elementor'),
				'description'   => esc_html__('A short message that can be displayed below forms, along with a checkbox, that lets the user know that he has to agree to your privacy policy in order to send the form.', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'dependency' => array ( 'privacy-subscribeform', '==', '1' )
			)
		)
	);


/**
 * Option : Privacy Login Form
 */
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-loginform]', array (
			'default'           => iva_get_option( 'privacy-loginform' ),
			'type'              => 'option',
			'sanitize_callback' => array ( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control_Switch(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-loginform]', array (
				'type'    => 'dt-switch',
				'label'   => esc_html__('Append a privacy policy message to your login forms?', 'dt-elementor'),
				'description'   => esc_html__('Check to append a message to the default login and registrations forms.', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'choices' => array (
					'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
					'off' => esc_attr__( 'No', 'dt-elementor' )
				)
			)
		)
	);

/**
* Option : Privacy Login Form Message
*/
	$wp_customize->add_setting(
		IVA_THEME_SETTINGS . '[privacy-loginform-msg]', array (
			'default'           => iva_get_option( 'privacy-loginform-msg' ),
			'type'              => 'option',
			'sanitize_callback' => 'wp_filter_nohtml_kses',
		)
	);

	$wp_customize->add_control(
		new IVA_Customize_Control(
			$wp_customize, IVA_THEME_SETTINGS . '[privacy-loginform-msg]', array (
				'type'    => 'textarea',
				'label'   => esc_html__('Message below login forms', 'dt-elementor'),
				'description'   => esc_html__('A short message that can be displayed below forms, along with a checkbox, that lets the user know that he has to agree to your privacy policy in order to send the form.', 'dt-elementor'),
				'section' => 'privacy-policy-section',
				'dependency' => array ( 'privacy-loginform', '==', '1' )
			)
		)
	);