<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('DTCorePrivacyCookies') ) {

	class DTCorePrivacyCookies {

		private static $instance;

		public static function get_instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action( 'customize_register', array( $this, 'register_privacy_cookies_panel' ), 15 );
			add_filter( 'dttheme_default_settings', array( $this, 'set_defaults' ) );

			add_action( 'wp_enqueue_scripts', array( $this, 'privacy_cookies_enqueue_scripts' ), 98 );
		}

		public function register_privacy_cookies_panel( $wp_customize ) {
			/**
			 * Privacy & Cookies Main Panel
			 */
			$wp_customize->add_panel( 
				new IVA_WP_Customize_Panel(
					$wp_customize,
					'privacycookies-main-panel',
					array(
						'title'    => esc_html__('Privacy & Cookies', 'dt-elementor'),
						'priority' => 130
					)
				)
			);

			/**
			 * Privacy Policy Section 
			 */
			$wp_customize->add_section( 
				new IVA_WP_Customize_Section(
					$wp_customize,
					'privacy-policy-section',
					array(
						'title'    => esc_html__('Privacy Policy', 'dt-elementor'),
						'panel'    => 'privacycookies-main-panel',
						'priority' => 5,
					)
				)
			);

			require_once 'privacy-policy-section.php';

			/**
			 * Cookie Consent Message Section 
			 */
			$wp_customize->add_section( 
				new IVA_WP_Customize_Section(
					$wp_customize,
					'cookie-consent-section',
					array(
						'title'    => esc_html__('Cookie Consent Message', 'dt-elementor'),
						'panel'    => 'privacycookies-main-panel',
						'priority' => 10,
					)
				)
			);

			require_once 'cookie-consent-section.php';
		}

		public function set_defaults( $defaults ) {

			$defaults['privacy-commentform']       			= '';
			$defaults['privacy-commentform-msg']   			= esc_html__('I agree to the terms and conditions laid out in the [dt_sc_privacy_link]Privacy Policy[/dt_sc_privacy_link]', 'dt-elementor');
			$defaults['privacy-subscribeform']     			= '';
			$defaults['privacy-subscribeform-msg'] 			= esc_html__('I agree to the terms and conditions laid out in the [dt_sc_privacy_link]Privacy Policy[/dt_sc_privacy_link]', 'dt-elementor');
			$defaults['privacy-loginform']         			= '';
			$defaults['privacy-loginform-msg']     			= esc_html__('I agree to the terms and conditions laid out in the [dt_sc_privacy_link]Privacy Policy[/dt_sc_privacy_link]', 'dt-elementor');

			$defaults['enable-cookie-consent']     			= '';
			$defaults['cookie-consent-msg']        			= '';
			$defaults['cookie-bar-position']       			= 'bottom';
			$defaults['enable-dismiss-the-notification']    = '';
			$defaults['dismiss-the-notification-label']     = '';
			$defaults['enable-link-to-another-page']        = '';
			$defaults['link-to-another-page-label']         = '';
			$defaults['link-to-another-page-link']          = '';
			$defaults['enable-open-infomodal-on-privacy-and-cookies']  = '';
			$defaults['open-infomodal-on-privacy-and-cookies-label']   = '';
			$defaults['enable-custom-model-content']		= '';
			$defaults['custom-model-heading']               = esc_html__('Cookie and Privacy Settings', 'dt-elementor');
			$defaults['custom-model-tabs']                  = '';

			return $defaults;
		}

		public function privacy_cookies_enqueue_scripts() {

			// privacy and cookies css
			if( iva_get_option('enable-cookie-consent') == "true" ) {
				wp_enqueue_style( 'dtcore-cookieconsent', plugins_url('/designthemes-core/customizer/css/cookieconsent.css'), false, IVA_THEME_VERSION, 'all');
				wp_enqueue_script('dtcore-cookieconsent', plugins_url('/designthemes-core/customizer/js/cookieconsent.js'), array(), false, true);				
			}
		}
	}
}

DTCorePrivacyCookies::get_instance();