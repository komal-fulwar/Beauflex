<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('DTCoreComingsoon') ) {

	class DTCoreComingsoon {

		private static $instance;

		public static function get_instance() {

			if ( ! isset( self::$instance ) ) {

				self::$instance = new self;
			}

			return self::$instance;
		}

		public function __construct() {

			add_action( 'init', array( $this, 'dt_init' ) );

			add_action( 'customize_register', array( $this, 'register_comingsoon_panel' ), 15 );
			add_filter( 'dttheme_default_settings', array( $this, 'set_defaults' ) );

			add_action( 'wp_enqueue_scripts', array( $this, 'comingsoon_enqueue_scripts' ), 98 );
		}

		public function dt_init() {
			/* ---------------------------------------------------------------------------
			 *	Under Construction
			 * --------------------------------------------------------------------------- */
			if( ! function_exists('iva_under_construction') ){
				function iva_under_construction(){
					if( ! is_user_logged_in() && ! is_admin() && ! is_404() ) {
						$obj = new DTElementorCore;
						require_once $obj->plugin_path( 'customizer/templates/tpl-comingsoon.php' );
						exit();
					}
				}
			}

			if( iva_get_option( 'enable-comingsoon' ) ):
				add_action('template_redirect', 'iva_under_construction', 30);
			endif;
		}

		public function register_comingsoon_panel( $wp_customize ) {
			/**
			 * Coming Soon Section
			 */
			$wp_customize->add_section( 
				new IVA_WP_Customize_Section(
					$wp_customize,
					'site-comingsoon-page-section',
					array(
						'title'    => esc_html__('Under Construction Page', 'dt-elementor'),
						'panel'    => 'site-page-settings-main-panel',
						'priority' => 10,
					)
				)
			);

			/**
			 * Option : Enable Coming Soon
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[enable-comingsoon]', array(
						'default'           => iva_get_option( 'enable-comingsoon' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control_Switch(
						$wp_customize, IVA_THEME_SETTINGS . '[enable-comingsoon]', array(
							'type'    => 'dt-switch',
							'label'   => esc_html__( 'Enable Coming Soon', 'dt-elementor'),
							'description' => esc_html__('YES! to check under construction page of your website.', 'dt-elementor'),
							'section' => 'site-comingsoon-page-section',
							'choices' => array(
								'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
								'off' => esc_attr__( 'No', 'dt-elementor' )
							)
						)
					)
				);

			/**
			 * Option : Template Style
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon-style]', array(
						'default'           => iva_get_option( 'comingsoon-style' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
					)
				);

				$wp_customize->add_control( new IVA_Customize_Control(
					$wp_customize, IVA_THEME_SETTINGS . '[comingsoon-style]', array(
						'type'    => 'select',
						'section' => 'site-comingsoon-page-section',
						'label'   => esc_html__( 'Template Style', 'dt-elementor' ),
						'choices' => array(
							'type1'  => esc_html__('Diamond', 'dt-elementor'),
							'type2'  => esc_html__('Teaser', 'dt-elementor'),
							'type3'  => esc_html__('Minimal', 'dt-elementor'),
							'type4'  => esc_html__('Counter Only', 'dt-elementor'),
							'type5'  => esc_html__('Belt', 'dt-elementor'),
							'type6'  => esc_html__('Classic', 'dt-elementor'),
							'type7'  => esc_html__('Boxed', 'dt-elementor')
						),
						'description' => esc_html__('Choose the style of coming soon template.', 'dt-elementor'),
					)
				));

			/**
			 * Option : Comingsoon Dark BG
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[uc-darkbg]', array(
						'default'           => iva_get_option( 'uc-darkbg' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control_Switch(
						$wp_customize, IVA_THEME_SETTINGS . '[uc-darkbg]', array(
							'type'    => 'dt-switch',
							'label'   => esc_html__( 'Coming Soon Dark BG', 'dt-elementor'),
							'description' => esc_html__('YES! to use dark bg coming soon page for this site.', 'dt-elementor'),
							'section' => 'site-comingsoon-page-section',
							'choices' => array(
								'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
								'off' => esc_attr__( 'No', 'dt-elementor' )
							)
						)
					)
				);

			/**
			 * Option : Custom Page
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon-pageid]', array(
						'default'           => iva_get_option( 'comingsoon-pageid' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
					)
				);

				$wp_customize->add_control( new IVA_Customize_Control(
					$wp_customize, IVA_THEME_SETTINGS . '[comingsoon-pageid]', array(
						'type'    => 'select',
						'section' => 'site-comingsoon-page-section',
						'label'   => esc_html__( 'Custom Page', 'dt-elementor' ),
						'choices' => iva_get_customizer_pages(),
						'description' => esc_html__('Choose the page for comingsoon content.', 'dt-elementor'),
					)
				));

			/**
			 * Option : Show Launch Date
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[show-launchdate]', array(
						'default'           => iva_get_option( 'show-launchdate' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_tweek' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control_Switch(
						$wp_customize, IVA_THEME_SETTINGS . '[show-launchdate]', array(
							'type'    => 'dt-switch',
							'label'   => esc_html__( 'Show Launch Date', 'dt-elementor'),
							'description' => esc_html__('YES! to show launch date text.', 'dt-elementor'),
							'section' => 'site-comingsoon-page-section',
							'choices' => array(
								'on'  => esc_attr__( 'Yes', 'dt-elementor' ),
								'off' => esc_attr__( 'No', 'dt-elementor' )
							)
						)
					)
				);

			/**
			 * Option : Launch Date
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon-launchdate]', array(
						'default'           => iva_get_option( 'comingsoon-launchdate' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_html' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control(
						$wp_customize, IVA_THEME_SETTINGS . '[comingsoon-launchdate]', array(
							'type'    	  => 'text',
							'section'     => 'site-comingsoon-page-section',
							'label'       => esc_html__( 'Launch Date', 'dt-elementor' ),
							'input_attrs' => array(
								'placeholder' => '10/30/2016 12:00:00',
							),
							'description' => esc_html__('Put Format: 12/30/2016 12:00:00 month/day/year hour:minute:second', 'dt-elementor'),
						)
					)
				);

			/**
			 * Option : Timezone
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon-timezone]', array(
						'default'           => iva_get_option( 'comingsoon-timezone' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_choices' ),
					)
				);

				$wp_customize->add_control( new IVA_Customize_Control(
					$wp_customize, IVA_THEME_SETTINGS . '[comingsoon-timezone]', array(
						'type'    => 'select',
						'section' => 'site-comingsoon-page-section',
						'label'   => esc_html__( 'UTC Timezone', 'dt-elementor' ),
						'choices' => array(
							'-12' => '-12', '-11' => '-11', '-10' => '-10', '-9' => '-9', '-8' => '-8', '-7' => '-7', '-6' => '-6', '-5' => '-5', 
							'-4' => '-4', '-3' => '-3', '-2' => '-2', '-1' => '-1', '0' => '0', '+1' => '+1', '+2' => '+2', '+3' => '+3', '+4' => '+4',
							'+5' => '+5', '+6' => '+6', '+7' => '+7', '+8' => '+8', '+9' => '+9', '+10' => '+10', '+11' => '+11', '+12' => '+12'
						),
						'description' => esc_html__('Choose utc timezone, by default UTC:00:00', 'dt-elementor'),
					)
				));

			/**
			 * Option : Comingsoon Background
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon_background]', array(
						'default'           =>  '',
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_background_obj' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control_Background(
						$wp_customize, IVA_THEME_SETTINGS . '[comingsoon_background]', array(
							'type'    => 'dt-background',
							'section' => 'site-comingsoon-page-section',
							'label'   => esc_html__( 'Background', 'dt-elementor' ),
						)
					)		
				);

			/**
			 * Option : Custom Styles
			 */
				$wp_customize->add_setting(
					IVA_THEME_SETTINGS . '[comingsoon-bg-style]', array(
						'default'           => iva_get_option( 'comingsoon-bg-style' ),
						'type'              => 'option',
						'sanitize_callback' => array( 'IVA_Customizer_Sanitizes', 'sanitize_html' ),
					)
				);

				$wp_customize->add_control(
					new IVA_Customize_Control(
						$wp_customize, IVA_THEME_SETTINGS . '[comingsoon-bg-style]', array(
							'type'    	  => 'textarea',
							'section'     => 'site-comingsoon-page-section',
							'label'       => esc_html__( 'Custom Inline Styles', 'dt-elementor' ),
							'description' => esc_html__('Paste custom CSS styles for under construction page.', 'dt-elementor'),
							'input_attrs' => array(
								'placeholder' => esc_html__( 'color:#ff00bb; text-align:left;', 'dt-elementor' ),
							),
						)
					)
				);
		}

		public function set_defaults( $defaults ) {

			$defaults['enable-comingsoon']  	= '0';
			$defaults['comingsoon-style']		= 'type1';
			$defaults['uc-darkbg']				= '0';
			$defaults['comingsoon-pageid']		= '';
			$defaults['show-launchdate']		= '0';
			$defaults['comingsoon-launchdate']	= date( 'm/d/Y h:i:s' );
			$defaults['comingsoon-timezone']	= '0';
			$defaults['comingsoon_background']	= '';
			$defaults['comingsoon-bg-style']	= '';

			return $defaults;
		}

		public function comingsoon_enqueue_scripts() {

			// comingsoon css
			if( iva_get_option( 'enable-comingsoon' ) )
				wp_enqueue_style("dtcore-comingsoon",  plugins_url('/designthemes-core/customizer/css/comingsoon.css'), false, IVA_THEME_VERSION, 'all' );

			wp_enqueue_script('jquery-downcount', plugins_url('/designthemes-core/customizer/js/jquery.downcount.js'), array(), false, true);
		}
	}
}

DTCoreComingsoon::get_instance();