<?php
namespace DTElementor\widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class DTElementorWidgets {

	/**
	 * A Reference to an instance of this class
	 */
	private static $_instance = null;

	/**
	 * Instance
	 * 
	 * Ensures only one instance of the class is loaded or can be loaded.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'register_admin_scripts' ) );

		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_widget_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_widget_scripts' ) );

		add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_styles') );

		add_filter( 'elementor/editor/localize_settings', array( $this, 'localize_settings' )  );
	}

	/**
	 * Register designthemes widgets
	 */
	public function register_widgets( $widgets_manager ) {

		require dt_elementor()->plugin_path( 'widgets/class-common-widget-base.php' );

		#Logo
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-logo.php');
		$widgets_manager->register_widget_type( new \Elementor_Logo() );				

		#Button
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-button.php');
		$widgets_manager->register_widget_type( new \Elementor_Button() );		

		#Advanced Carousel
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-advanced-carousel.php');
		$widgets_manager->register_widget_type( new \Elementor_Advanced_Carousel() );		

		#Counter
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-counter.php');
		$widgets_manager->register_widget_type( new \Elementor_Counter() );		

		#Carousel
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-carousel.php');
		$widgets_manager->register_widget_type( new \Elementor_AnyCarousel() );

		#Header Icons
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-header-icons.php');
		$widgets_manager->register_widget_type( new \Elementor_Header_Icons() );

		# Ordered List
		require dt_elementor()->plugin_path( 'widgets/modules/class-widget-ordered-list.php');
		$widgets_manager->register_widget_type( new \Elementor_OrderedList() );

		#Blog Posts
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-blog-posts.php');
		$widgets_manager->register_widget_type( new \Elementor_Blog_Posts() );

		#Meta Group
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-meta-group.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Meta_Group() );

		#Feature Image
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-feature-image.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Feature_Image() );

		#Title
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-title.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Title() );

		#Author
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-author.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Author() );

		#Date
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-date.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Date() );

		#Comments
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-comments.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Comments() );

		#Categories
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-categories.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Categories() );

		#Tags
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-tags.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Tags() );

		#Socials
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-socials.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Socials() );

		#Likes & Views
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-likes-views.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Likes_Views() );

		#Related Article
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-related-article.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Related_Article() );

		#Navigation
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-navigation.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Navigation() );

		#Author Bio
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-author-bio.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Author_Bio() );

		#Comment Box
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-comment-box.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Comment_Box() );

		#Related Posts
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-post-related-posts.php');
		$widgets_manager->register_widget_type( new \Elementor_Post_Related_Posts() );

		#LightBox
		require dt_elementor()->plugin_path( 'widgets/modules/blog/class-widget-lightbox.php');
		$widgets_manager->register_widget_type( new \Elementor_Lightbox() );

		# Header Menu
		require dt_elementor()->plugin_path( 'widgets/modules/header/class-widget-header-menu.php');
		$widgets_manager->register_widget_type( new \Elementor_Header_Menu() );
	}

	/**
	 * Register designthemes widgets styles
	 */
	public function register_widget_styles() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries
		wp_register_style( 'slick',
			dt_elementor()->plugin_url('css/slick.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);

		wp_register_style( 'swiper',
			dt_elementor()->plugin_url('css/swiper.min.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);

		wp_register_style( 'dt-button',
			dt_elementor()->plugin_url('css/dt-button.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);		

		wp_register_style( 'dt-advanced-carousel',
			dt_elementor()->plugin_url('css/dt-advanced-carousel.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);		

		wp_register_style( 'dt-counter',
			dt_elementor()->plugin_url('css/counter.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);		

		wp_register_style( 'dt-anycarousel',
			dt_elementor()->plugin_url('css/anycarousel.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);		

		wp_register_style( 'dt-header-icons',
			dt_elementor()->plugin_url('css/header-icons.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);		

		wp_register_style( 'dt-ordered-list',
			dt_elementor()->plugin_url('css/dt-ordered-list.css'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION
		);
	}

	/**
	 * Register designthemes widgets scripts
	 */
	public function register_widget_scripts() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '';

		# Libraries
		wp_register_script( 'slick',
			dt_elementor()->plugin_url('js/slick.min.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'jquery.swiper',
			dt_elementor()->plugin_url('js/swiper.min.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'jquery-animateNumber',
			dt_elementor()->plugin_url('js/jquery.animateNumber.min.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'dt-advanced-carousel',
			dt_elementor()->plugin_url('js/dt-advanced-carousel.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'dt-counter',
			dt_elementor()->plugin_url('js/dt-counter.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'dt-anycarousel',
			dt_elementor()->plugin_url('js/dt-anycarousel.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );

		wp_register_script( 'dt-header-icons',
			dt_elementor()->plugin_url('js/dt-header-icons.js'),
			array( 'jquery' ),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );
	}
	
	/**
	 *  Editor Preview Style
	 */
	public function preview_styles() {

		# Libraries
		wp_enqueue_style( 'slick' );
		wp_enqueue_style( 'swiper' );
		wp_enqueue_style( 'dt-button' );
		wp_enqueue_style( 'dt-anycarousel' );
		wp_enqueue_style( 'dt-counter' );
		wp_enqueue_style( 'dt-advanced-carousel' );
		wp_enqueue_style( 'dt-header-icons' );
		wp_enqueue_style( 'dt-ordered-list' );
	}

	/**
	 * Enqueue localized texts
	 */
	public function localize_settings( $settings ) {

		$settings['DTHotspots'] = array(
			'text'  => __( 'Text', 'dt-elementor' ),
			'icon'  => __( 'Icon', 'dt-elementor' ),
			'blank' => __( 'Blank', 'dt-elementor' ),
		);

		$settings['DTTeamSocial'] = array(
			'fa fa-dribbble'     => esc_html__( 'Dribble', 'dt-elementor'),
			'fa fa-flickr'       => esc_html__( 'Flickr', 'dt-elementor'),
			'fa fa-github'       => esc_html__( 'Github', 'dt-elementor'),
			'fa fa-pinterest'    => esc_html__( 'Pinterest', 'dt-elementor'),
			'fa fa-twitter'      => esc_html__( 'Twitter', 'dt-elementor'),
			'fa fa-youtube'      => esc_html__( 'Youtube', 'dt-elementor'),
			'fa fa-android'      => esc_html__( 'Android', 'dt-elementor'),
			'fa fa-dropbox'      => esc_html__( 'Dropbox', 'dt-elementor'),
			'fa fa-instagram'    => esc_html__( 'Instagram', 'dt-elementor'),
			'fa fa-windows'      => esc_html__( 'Windows', 'dt-elementor'),
			'fa fa-apple'        => esc_html__( 'Apple', 'dt-elementor'),
			'fa fa-facebook-f'   => esc_html__( 'Facebook', 'dt-elementor'),
			'fa fa-google-plus'  => esc_html__( 'Google Plus', 'dt-elementor'),
			'fa fa-linkedin'     => esc_html__( 'Linkedin', 'dt-elementor'),
			'fa fa-skype'        => esc_html__( 'Skype', 'dt-elementor'),
			'fa fa-tumblr'       => esc_html__( 'Tumblr', 'dt-elementor'),
			'fa fa-vimeo-square' => esc_html__( 'Vimeo','dt-elementor'),
		);		

		return $settings;
	}

	public function register_admin_scripts() {	

		wp_enqueue_script( 'dt-elementor-admin',
			dt_elementor()->plugin_url('js/admin.js'),
			array(),
			dt_elementor()::DT_ELEMENTOR_VERSION,
			true );
	}
}

DTElementorWidgets::instance();